<?php

declare(strict_types=1);

namespace Ehaic\VsModManager\Services;

use App\Models\Server;
use Ehaic\VsModManager\Support\Version;

/** Adds ModDB update status, warnings and "failed to load" information to the installed-mods list. */
class ModStatusService
{
    /** Mods that ship inside the game itself (top-level Mods/); dependencies on them are always met. */
    private const BUILTIN = ['game', 'survival', 'creative', 'essentials'];

    /**
     * @param  array<int, array<string, mixed>>  $installed  rows from ServerModsService::list()
     * @return array<int, array<string, mixed>> same rows plus moddbStatus, moddbUrl (null if not on ModDB), latest, warnings
     */
    public function annotate(Server $server, array $installed, ?string $gameVersion): array
    {
        $client = app(ModDbClient::class);
        $selector = app(ReleaseSelector::class);
        $allowPre = (bool) config('vs-mod-manager.allow_prereleases', false);

        // modid → rows, and modid → highest enabled version (for dependency checks)
        $byModid = [];
        $enabled = [];
        foreach ($installed as $row) {
            $id = strtolower((string) ($row['modid'] ?? ''));
            if ($id === '' || $row['kind'] === 'ignored') {
                continue;
            }
            $byModid[$id][] = $row;
            if (empty($row['disabled'])) {
                $v = (string) ($row['version'] ?? '');
                if (!isset($enabled[$id]) || Version::compare($v, $enabled[$id]) > 0) {
                    $enabled[$id] = $v;
                }
            }
        }

        // Which modinfo modids ModDB knows (from the cached catalogue). Null if the catalogue is unavailable.
        $catalogueIndex = null;
        $cataloguePages = []; // modinfo modid → ModDB page URL
        $catalogueCard = [];  // modinfo modid → logo/author/summary for the Installed cards
        try {
            $catalogueIndex = [];
            foreach ($client->catalogue() as $m) {
                foreach ($m['modidstrs'] ?? [] as $s) {
                    $catalogueIndex[strtolower((string) $s)] ??= (int) $m['modid'];
                    $cataloguePages[strtolower((string) $s)] ??= $client->modPageUrl($m);
                    $catalogueCard[strtolower((string) $s)] ??= [
                        'logo' => $m['logo'] ?? null,
                        'moddbAuthor' => $m['author'] ?? null,
                        'moddbSummary' => $m['summary'] ?? null,
                        'moddbDownloads' => (int) ($m['downloads'] ?? 0),
                    ];
                }
            }
            if ($catalogueIndex === [] && $client->hadFailure()) {
                $catalogueIndex = null; // ModDB unreachable: "not on ModDB" would be a guess
            }
        } catch (\Throwable $e) {
            report($e);
            $catalogueIndex = null;
        }

        try {
            $log = $this->logStatus($server);
        } catch (\Throwable) {
            $log = ['loaded' => [], 'errors' => [], 'found' => null];
        }

        // One round of parallel requests instead of one blocking /api/mod call per installed mod.
        if ($gameVersion !== null) {
            $lookups = [];
            foreach ($installed as $row) {
                $id = strtolower((string) ($row['modid'] ?? ''));
                if ($id !== '' && $row['kind'] !== 'ignored' && !empty($row['version']) && (!empty($row['moddb']) || isset($catalogueIndex[$id]))) {
                    $lookups[] = $id;
                }
            }
            try {
                $client->prefetchMods($lookups);
            } catch (\Throwable $e) {
                report($e);
            }
        }

        $out = [];
        foreach ($installed as $row) {
            $row['warnings'] = [];
            $row['latest'] = null;
            $row['moddbStatus'] = 'unknown';
            $id = strtolower((string) ($row['modid'] ?? ''));

            if ($row['kind'] === 'ignored' || $id === '') {
                $out[] = $row;
                continue;
            }

            // ---- ModDB status
            // /api/mod/{x} accepts the modinfo modid string directly (case-insensitive).
            if (isset($cataloguePages[$id])) {
                $row['moddbUrl'] = $cataloguePages[$id];
            }
            if (isset($catalogueCard[$id])) {
                $row = array_merge($row, $catalogueCard[$id]);
            }
            if (!empty($row['moddb']) || isset($catalogueIndex[$id])) {
                $row = $this->moddbStatus($row, (string) $row['modid'], $gameVersion, $client, $selector, $allowPre);
            } elseif ($catalogueIndex !== null) {
                $row['moddbStatus'] = 'not_on_moddb';
            }

            // ---- warnings
            if (count($byModid[$id] ?? []) > 1) {
                $row['warnings'][] = 'duplicate';
            }
            if (empty($row['disabled'])) {
                foreach ((array) $row['dependencies'] as $dep => $min) {
                    $depId = strtolower((string) $dep);
                    if (in_array($depId, self::BUILTIN, true)) {
                        continue;
                    }
                    if (!isset($enabled[$depId])) {
                        $row['warnings'][] = 'missing_dependency:' . $dep . '@' . $min;
                    } elseif (!Version::satisfiesMin((string) $min, $enabled[$depId])) {
                        $row['warnings'][] = 'dependency_too_old:' . $dep;
                    }
                }
            }
            if (!empty($row['gameMin']) && $gameVersion !== null && !Version::satisfiesMin((string) $row['gameMin'], $gameVersion)) {
                $row['warnings'][] = 'needs_game:' . $row['gameMin'];
            }
            if (strtolower((string) ($row['side'] ?? '')) === 'client') {
                $row['warnings'][] = 'client_only';
            }
            $errors = $log['errors'][$row['modid']] ?? $log['errors'][$row['filename']] ?? null;
            if ($errors) {
                // The game often splits one problem over two lines ("Could not resolve some dependencies:" + the list).
                $row['warnings'][] = 'failed_to_load:' . implode(' ', array_slice($errors, 0, 2));
            }

            $out[] = $row;
        }

        return $out;
    }

    /** @return array<string, mixed> the row with moddbStatus and latest filled in */
    private function moddbStatus(array $row, string|int $ident, ?string $gameVersion, ModDbClient $client, ReleaseSelector $selector, bool $allowPre): array
    {
        if ($gameVersion === null || empty($row['version'])) {
            return $row;
        }
        try {
            $mod = $client->mod($ident);
        } catch (\Throwable $e) {
            report($e);

            return $row;
        }
        if ($mod === null) {
            $row['moddbStatus'] = $client->hadFailure() ? 'unknown' : 'not_on_moddb';

            return $row;
        }

        $row['moddbUrl'] = $client->modPageUrl($mod);

        // Only releases of this modid (one ModDB page can host several).
        $releases = $selector->forModid($mod['releases'] ?? [], (string) $row['modid']);
        $known = array_filter($releases, fn ($r) => Version::compare((string) $r['modversion'], (string) $row['version']) === 0);
        if ($known === []) {
            $row['moddbStatus'] = 'version_not_on_moddb';

            return $row;
        }

        $upgrade = $selector->upgradeFor($releases, $gameVersion, (string) $row['version'], $allowPre);
        $row['moddbStatus'] = $upgrade === null ? 'up_to_date' : 'update';
        $row['latest'] = $upgrade;

        return $row;
    }

    /**
     * Parsed from the newest run in data/Logs/server-main.log.
     *
     * @return array{loaded: string[], errors: array<string, string[]>, found: ?string}
     */
    public function logStatus(Server $server): array
    {
        $log = app(ServerModsService::class)->forServer($server)->readServerLog();

        return $log === null ? ['loaded' => [], 'errors' => [], 'found' => null] : self::parseLog($log);
    }

    /**
     * Pure log parser. Uses only the last run in the file (the log can hold several).
     *
     * @return array{loaded: string[], errors: array<string, string[]>, found: ?string}
     */
    public static function parseLog(string $log): array
    {
        $start = strrpos($log, 'Server logger started.');
        if ($start !== false) {
            $log = substr($log, $start);
        }

        $loaded = [];
        $errors = [];
        $found = null;
        foreach (preg_split('/\R/', $log) ?: [] as $line) {
            if (preg_match('/\[Notification\] Found (\d+) mods \((\d+) disabled\)/', $line, $m)) {
                $found = "Found {$m[1]} mods ({$m[2]} disabled)";
            } elseif (preg_match('/\[Notification\] Mods, sorted by dependency: (.*)$/', $line, $m)) {
                $loaded = array_values(array_filter(array_map('trim', explode(',', $m[1])), fn ($s) => $s !== ''));
            } elseif (preg_match('/^\S+ \S+ \[(?:Error|Fatal)\] \[([^\]]+)\] (.*)$/', $line, $m)) {
                $msg = trim($m[2]);
                if ($msg !== '' && count($errors[$m[1]] ?? []) < 10) {
                    $errors[$m[1]][] = $msg;
                }
            }
        }

        return ['loaded' => $loaded, 'errors' => $errors, 'found' => $found];
    }
}
