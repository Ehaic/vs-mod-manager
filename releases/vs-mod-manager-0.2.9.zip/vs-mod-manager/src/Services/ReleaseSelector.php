<?php

declare(strict_types=1);

namespace Ehaic\VsModManager\Services;

use Ehaic\VsModManager\Support\Version;

/**
 * Picks the right ModDB release for a server's game version (DESIGN.md, "Choosing a release").
 *
 * A release's `tags` are the game versions it is marked compatible with. Authors don't tick every patch
 * (e.g. no Expanded Foods release is tagged 1.20.12), so besides exact matches we accept the same
 * major.minor. We never cross a major.minor boundary automatically.
 */
final class ReleaseSelector
{
    public const EXACT = 'exact';
    public const SAME_MINOR = 'same_minor';
    public const NEWER_PATCH = 'newer_patch';
    public const OTHER = 'other';

    /** Tiers in order of preference. */
    private const TIERS = [self::EXACT, self::SAME_MINOR, self::NEWER_PATCH];

    /**
     * Highest mod version first (stable > rc > pre > dev). Ties: newest upload first.
     * The API returns releases by upload date, so we always sort ourselves.
     *
     * @param  array<int, array<string, mixed>>  $releases
     * @return array<int, array<string, mixed>>
     */
    public function sort(array $releases): array
    {
        $releases = array_values($releases);
        // usort is stable in PHP 8+, but be explicit about the tie-break.
        usort($releases, function (array $a, array $b): int {
            $c = Version::compare((string) ($b['modversion'] ?? ''), (string) ($a['modversion'] ?? ''));

            return $c !== 0 ? $c : strcmp((string) ($b['created'] ?? ''), (string) ($a['created'] ?? ''));
        });

        return $releases;
    }

    /**
     * A ModDB page can host several modids; keep only the releases of one modid (case-insensitive).
     *
     * @param  array<int, array<string, mixed>>  $releases
     * @return array<int, array<string, mixed>>
     */
    public function forModid(array $releases, string $modid): array
    {
        return array_values(array_filter(
            $releases,
            fn (array $r) => strcasecmp((string) ($r['modidstr'] ?? ''), $modid) === 0,
        ));
    }

    /** Best tier among the release's tags: EXACT, SAME_MINOR, NEWER_PATCH or OTHER. */
    public function compatibility(array $release, string $gameVersion): string
    {
        $g = Version::parse($gameVersion);
        if ($g === null) {
            return self::OTHER;
        }
        $gMinor = $g['major'] . '.' . $g['minor'];

        $best = self::OTHER;
        foreach ((array) ($release['tags'] ?? []) as $tag) {
            $tag = (string) $tag;
            $t = Version::parse($tag);
            if ($t === null) {
                continue;
            }
            if (Version::compare($tag, $gameVersion) === 0) {
                return self::EXACT;
            }
            // Other game pre-releases (1.22.0-rc.3 for a stable server) say nothing about this server.
            if ($t['pre'] !== null || $t['major'] . '.' . $t['minor'] !== $gMinor) {
                continue;
            }
            if (Version::compare($tag, $gameVersion) < 0) {
                $best = self::SAME_MINOR;
            } elseif ($best === self::OTHER) {
                $best = self::NEWER_PATCH;
            }
        }

        return $best;
    }

    /**
     * Recommended release or null. Walks the tiers (exact, same minor older patch, same minor newer patch)
     * and returns the highest mod version of the first tier that has an acceptable release.
     * Stable releases only, unless $allowPre or the installed version is itself a pre-release.
     *
     * @param  array<int, array<string, mixed>>  $releases
     * @return array<string, mixed>|null
     */
    public function recommend(array $releases, string $gameVersion, bool $allowPre = false, ?string $installedVersion = null): ?array
    {
        $usePre = $allowPre || ($installedVersion !== null && Version::isPrerelease($installedVersion));

        $byTier = array_fill_keys(self::TIERS, []);
        foreach ($releases as $r) {
            // A release without a file can't be installed.
            if (empty($r['fileid']) || empty($r['filename'])) {
                continue;
            }
            if (! $usePre && Version::isPrerelease((string) ($r['modversion'] ?? ''))) {
                continue;
            }
            $tier = $this->compatibility($r, $gameVersion);
            if ($tier !== self::OTHER) {
                $byTier[$tier][] = $r;
            }
        }

        foreach (self::TIERS as $tier) {
            if ($byTier[$tier] !== []) {
                return $this->sort($byTier[$tier])[0];
            }
        }

        return null;
    }

    /**
     * Recommendation for a NEW install: stable-first like recommend(), but when no compatible stable release
     * exists, fall back to the best compatible pre-release (same tiers; stable > rc > pre > dev, newest).
     * Callers check Version::isPrerelease() on the result to tell the user. Never use this for updates.
     *
     * @param  array<int, array<string, mixed>>  $releases
     * @return array<string, mixed>|null
     */
    public function recommendForInstall(array $releases, string $gameVersion, bool $allowPre = false): ?array
    {
        return $this->recommend($releases, $gameVersion, $allowPre)
            ?? $this->recommend($releases, $gameVersion, true);
    }

    /**
     * The recommended release, only if strictly newer than what's installed (never a downgrade).
     * An installed version that doesn't parse gets no suggestion: we can't tell what "newer" means.
     *
     * @param  array<int, array<string, mixed>>  $releases
     * @return array<string, mixed>|null
     */
    public function upgradeFor(array $releases, string $gameVersion, string $installedVersion, bool $allowPre = false): ?array
    {
        if (Version::parse($installedVersion) === null) {
            return null;
        }

        $rec = $this->recommend($releases, $gameVersion, $allowPre, $installedVersion);
        if ($rec === null || Version::compare((string) $rec['modversion'], $installedVersion) <= 0) {
            return null;
        }

        return $rec;
    }

    /**
     * The release that matches an installed version (for preselecting it in a version menu), or null.
     * $modid limits it to that mod's releases on ModDB pages that ship several mods.
     *
     * @param  array<int, array<string, mixed>>  $releases
     * @return array<string, mixed>|null
     */
    public function installedRelease(array $releases, string $installedVersion, ?string $modid = null): ?array
    {
        foreach ($releases as $r) {
            if ((string) ($r['modversion'] ?? '') !== $installedVersion) {
                continue;
            }
            if ($modid !== null && $modid !== '' && !empty($r['modidstr']) && strtolower((string) $r['modidstr']) !== strtolower($modid)) {
                continue;
            }

            return $r;
        }

        return null;
    }
}
