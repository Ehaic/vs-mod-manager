<?php

declare(strict_types=1);

return [
    'nav' => 'Mods',
    'title' => 'Vintage Story Mods',

    'tabs' => ['browse' => 'Browse', 'installed' => 'Installed', 'modpack' => 'Modpack'],

    'state' => [
        'running' => 'running', 'starting' => 'starting', 'stopping' => 'stopping',
        'offline' => 'offline', 'unknown' => 'unknown', 'missing' => 'unreachable',
    ],

    'banner' => [
        'stopped' => 'The server is stopped: mods can be changed',
        'stopped_body' => 'Changes take effect the next time the server starts.',
        'not_stopped' => 'The server must be stopped to change mods (current state: :state)',
        'not_stopped_body' => 'The game reads its mods only at start-up. Browsing, details, update checks and export still work.',
    ],

    'power' => [
        'start' => 'Start', 'stop' => 'Stop', 'restart' => 'Restart',
        'sent_start' => 'Start signal sent', 'sent_stop' => 'Stop signal sent', 'sent_restart' => 'Restart signal sent',
        'failed' => 'Could not send the power action',
    ],

    'tooltip' => ['stop_first' => 'The server must be stopped first (current state: :state)'],

    'gameversion' => [
        'heading' => 'Game version :version',
        'unknown' => 'Game version unknown',
        'source_override' => 'Set manually for this server.',
        'source_log' => 'Read from the server log.',
        'source_variable' => 'From the server\'s version variable.',
        'source_latest' => 'Assumed: the latest stable release (the server has not been started yet).',
        'source_unknown' => 'Could not be detected. Set it manually so compatible releases can be chosen.',
        'override' => 'Override',
        'override_heading' => 'Override the game version',
        'override_hint' => 'Use this for servers that have never been started, or if detection is wrong.',
        'override_field' => 'Game version',
        'override_clear' => 'Leave empty to detect the version automatically.',
        'invalid' => 'That is not a valid version (example: 1.20.12).',
        'saved' => 'Game version saved',
    ],

    'hint' => [
        'restart' => 'Mods changed',
        'restart_body' => 'Start the server to load the changes.',
    ],

    'deps' => [
        'heading' => 'Missing dependencies',
        'install' => 'Install dependencies',
        'dismiss' => 'Dismiss',
        'done' => 'Dependencies installed',
        'partial' => 'Some dependencies could not be installed',
        'installed_list' => 'Installed: :list',
        'not_found' => ':modid was not found on the ModDB.',
        'too_old' => ':modid needs version :min or newer, but the newest compatible release is :version.',
    ],

    'col' => [
        'name' => 'Name', 'author' => 'Author', 'downloads' => 'Downloads', 'follows' => 'Follows', 'trending' => 'Trending',
        'updated' => 'Updated', 'side' => 'Side', 'tags' => 'Tags', 'status' => 'Status', 'modid' => 'Mod id',
        'version' => 'Version', 'moddb' => 'ModDB', 'state' => 'State', 'pinned' => 'Pinned', 'warnings' => 'Warnings',
        'action' => 'Action', 'from' => 'From', 'to' => 'To',
    ],

    // ModDB says both/client/server; modinfo.json says Universal/Client/Server.
    'side' => ['both' => 'Client & server', 'universal' => 'Client & server', 'client' => 'Client', 'server' => 'Server', '' => ''],

    'moddb_down' => [
        'title' => 'The ModDB could not be reached',
        'browse' => 'The mod list could not be loaded. Try again in a few minutes.',
        'preview' => 'Some mods could not be looked up and are shown as not found. Try the preview again later.',
        'check' => 'Update information could not be refreshed. Try again in a few minutes.',
    ],

    'browse' => [
        'search' => 'Search name, author, mod id…',
        'installed' => 'Installed',
        'update' => 'Update available',
    ],

    'compat' => [
        'exact' => 'Compatible',
        'same_minor' => 'Same minor version',
        'newer_patch' => 'Newer game patch only',
        'other' => 'Other game version',
    ],

    'detail' => [
        'unavailable' => 'The mod details could not be loaded from the ModDB.',
        'moddb_page' => 'ModDB page',
        'description' => 'Description',
        'compat' => 'Compatibility',
        'game_versions' => 'Game versions',
        'released' => 'Released',
        'changelog' => 'Changelog',
        'older_hidden' => ':count more releases (for other game versions or older) are not shown. Open the ModDB page to see them.',
    ],

    'actions' => [
        'open_folder' => 'Open mods folder',
        'manage' => 'Manage',
        'details' => 'Details',
        'close' => 'Close',
        'install' => 'Install',
        'install_recommended' => 'Install the recommended version',
        'install_heading' => 'Install :name',
        'change_version' => 'Change version',
        'change_version_hint' => 'Server game version: :version. The installed version is preselected; the chosen release replaces it (the old file is kept in backups).',
        'install_body' => 'Install :name :version?',
        'version' => 'Version',
        'version_hint' => 'Server game version: :version. The recommended release is preselected.',
        'check_updates' => 'Check for updates',
        'update_all' => 'Update all',
        'update_all_body' => 'Updates every mod that has an update. Pinned mods are skipped.',
        'update' => 'Update',
        'update_body' => 'Update :name from :from to :to?',
        'choose_version' => 'Choose version',
        'choose_version_heading' => 'Choose a version of :name',
        'choose_version_hint' => 'Releases for other game versions may not work on this server.',
        'enable' => 'Enable',
        'disable' => 'Disable',
        'pin' => 'Pin version',
        'pin_hint' => 'Pinned mods are skipped by "Update all"',
        'unpin' => 'Unpin',
        'rollback' => 'Roll back',
        'rollback_body' => 'Restore the previous version of this mod from the backups.',
        'restore_removed' => 'Restore removed mod',
        'restore_removed_body' => 'Put back a mod that was removed with a backup (its newest backup).',
        'restore_removed_mod' => 'Mod',
        'open_moddb' => 'Open on ModDB',
        'remove' => 'Remove',
        'remove_heading' => 'Remove :name',
        'keep_backup' => 'Keep a backup so it can be rolled back',
        'disable_selected' => 'Disable selected',
        'enable_selected' => 'Enable selected',
        'remove_selected' => 'Remove selected',
        'remove_selected_body' => 'The files are moved to the backups.',
    ],

    'installed' => [
        'search' => 'Search installed mods…',
        'empty' => 'No mods found in data/Mods',
        'list_failed' => 'The mods folder could not be read',
        'list_failed_body' => 'The node (Wings) did not answer. Check that the node is online, then reload the page.',
        'unverified' => 'unverified',
        'no_modid' => 'the mod id is unknown',
    ],

    'status' => [
        'up_to_date' => 'Up to date',
        'update' => 'Update → :version',
        'update_to' => 'Update → :version',
        'not_on_moddb' => 'Not on ModDB',
        'version_not_on_moddb' => 'Version not on ModDB',
        'unknown' => 'Unknown',
    ],

    'state_mod' => ['enabled' => 'Enabled', 'disabled' => 'Disabled', 'ignored' => 'Ignored by the game', 'pinned' => 'Pinned'],

    'warning' => [
        'duplicate' => 'Duplicate mod id',
        'missing_dependency' => 'Missing dependency :arg',
        'dependency_too_old' => 'Dependency too old: :arg',
        'needs_game' => 'Needs game :arg',
        'client_only' => 'Client-only mod (no effect on a server)',
        'failed_to_load' => 'Failed to load: :arg',
    ],

    'modpack' => [
        'export_heading' => 'Export',
        'export_hint' => 'One mod per line as modid@version. Mods that are not on the ModDB are listed as comments.',
        'download' => 'Download list',
        'import' => 'Import list',
        'import_heading' => 'Import a mod list',
        'import_hint' => 'Paste modid, modid@version or ModDB links, one per line. You see a preview before anything changes.',
        'import_field' => 'Mod list',
        'preview' => 'Preview',
        'preview_heading' => 'Import preview',
        'preview_empty' => 'No import in progress',
        'preview_empty_body' => 'Use "Import list" to paste a list and preview what would change.',
        'apply' => 'Apply import',
        'apply_body' => 'Installs and updates the mods marked install/update in the preview.',
        'applied' => 'Import applied',
        'clear' => 'Clear preview',
        'empty' => 'No mods found in that text',
    ],

    'preview' => [
        'install' => 'Install',
        'update' => 'Update',
        'downgrade' => 'Older version',
        'same' => 'Already installed',
        'not_found' => 'Not found',
        'incompatible' => 'Not compatible',
    ],

    'notify' => [
        'failed' => 'Could not complete the action',
        'failed_unexpected' => 'Something went wrong. Check the panel log.',
        'no_permission' => 'You need permission to create, edit and delete files on this server.',
        'installed' => 'Installed :name :version',
        'no_compatible' => 'No compatible release',
        'no_compatible_body' => 'No release of :name fits game version :version. Choose a version yourself.',
        'prerelease_note' => '(pre-release: no stable release is compatible with this game version)',
        'updated' => 'Updated :name',
        'removed' => 'Removed :name',
        'disabled' => 'Disabled :name',
        'enabled' => 'Enabled :name',
        'rolled_back' => 'Rolled back :name',
        'pinned' => 'Pinned :name',
        'unpinned' => 'Unpinned :name',
        'checked' => 'Update information refreshed',
        'nothing_to_do' => 'Nothing to do',
        'update_all_done' => 'Update finished',
        'bulk_disabled' => 'Mods disabled',
        'bulk_enabled' => 'Mods enabled',
        'bulk_removed' => 'Mods removed',
        'count_done' => ':count changed.',
        'skipped_pinned' => ':count pinned mod(s) skipped.',
    ],

    'settings' => [
        'saved' => 'Settings saved',
        'minutes' => 'minutes',
        'catalogue_ttl' => 'Catalogue cache',
        'catalogue_ttl_hint' => 'How long the list of all ModDB mods is kept before it is fetched again.',
        'detail_ttl' => 'Mod detail cache',
        'detail_ttl_hint' => 'How long a mod\'s releases are kept before they are fetched again.',
        'allow_prereleases' => 'Allow pre-release mod versions',
        'allow_prereleases_hint' => 'Offer -rc, -pre and -dev versions as recommendations and updates.',
        'backups_per_mod' => 'Backups kept per mod',
        'backups_per_mod_hint' => 'Replaced or removed files kept for rollback.',
        'debug' => 'Debug logging',
        'debug_hint' => 'Write extra detail to the panel log (storage/logs, search for "vs-mod-manager:"). Failures and every change are always logged.',
    ],
];
