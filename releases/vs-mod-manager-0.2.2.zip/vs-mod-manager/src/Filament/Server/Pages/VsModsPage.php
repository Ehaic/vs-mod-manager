<?php

declare(strict_types=1);

namespace Ehaic\VsModManager\Filament\Server\Pages;

use App\Enums\SubuserPermission;
use App\Models\Server;
use App\Repositories\Daemon\DaemonServerRepository;
use App\Traits\Filament\BlockAccessInConflict;
use Ehaic\VsModManager\Exceptions\ModManagerException;
use Ehaic\VsModManager\Services\GameVersionService;
use Ehaic\VsModManager\Services\ModDbClient;
use Ehaic\VsModManager\Services\ModpackService;
use Ehaic\VsModManager\Services\ModStatusService;
use Ehaic\VsModManager\Services\ReleaseSelector;
use Ehaic\VsModManager\Services\ServerModsService;
use Ehaic\VsModManager\Support\Version;
use Filament\Actions\Action;
use Filament\Actions\ActionGroup;
use Filament\Actions\BulkAction;
use Filament\Actions\BulkActionGroup;
use Filament\Facades\Filament;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\Textarea;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\Toggle;
use Filament\Infolists\Components\TextEntry;
use Filament\Notifications\Notification;
use Filament\Pages\Page;
use Filament\Resources\Concerns\HasTabs;
use Filament\Schemas\Components\Callout;
use Filament\Schemas\Components\EmbeddedTable;
use Filament\Schemas\Components\Grid;
use Filament\Schemas\Components\Section;
use Filament\Schemas\Components\Tabs\Tab;
use Filament\Schemas\Schema;
use Filament\Tables\Columns\ImageColumn;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Concerns\InteractsWithTable;
use Filament\Tables\Contracts\HasTable;
use Filament\Tables\Filters\SelectFilter;
use Filament\Tables\Table;
use Illuminate\Pagination\LengthAwarePaginator;
use Illuminate\Support\Carbon;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\HtmlString;
use Livewire\Attributes\Locked;
use Throwable;

/**
 * The "Mods" page of a Vintage Story server: Browse (ModDB), Installed (data/Mods) and Modpack (export/import).
 *
 * Every change to the mods needs a stopped server. Buttons are hidden without permission, disabled with a
 * tooltip while the server is not offline, and the services re-check the state when the action runs.
 */
class VsModsPage extends Page implements HasTable
{
    use BlockAccessInConflict;
    use HasTabs;
    use InteractsWithTable;

    protected static string|\BackedEnum|null $navigationIcon = 'tabler-puzzle';

    protected static ?string $slug = 'vs-mods';

    protected static ?int $navigationSort = 30;

    /** Mod ids that belong to the game itself and are never installed from the ModDB. */
    private const BUILTIN_IDS = ['game', 'survival', 'creative', 'essentials'];

    /** Key of the cached import preview (rows hold whole ModDB releases, too big for a Livewire property). */
    #[Locked]
    public ?string $importToken = null;

    /** @var array<string, array{modid: string, min: string, needed_by: string}> dependencies offered after an install */
    #[Locked]
    public array $pendingDeps = [];

    /** Set after a successful change, to show the "start the server" hint. */
    #[Locked]
    public bool $changed = false;

    /** Server state at the last full render; the poll re-renders the whole page only when it changes. */
    #[Locked]
    public ?string $knownState = null;

    // Per-request memos (protected properties are not kept between Livewire requests).
    protected ?string $stateMemo = null;

    /** @var array{version: ?string, source: string}|null */
    protected ?array $gameVersionMemo = null;

    /** @var array<int, array<string, mixed>>|null */
    protected ?array $listMemo = null;

    /** @var array<int, array<string, mixed>>|null */
    protected ?array $annotatedMemo = null;

    /** @var array<int, array<string, mixed>>|null */
    protected ?array $catalogueMemo = null;

    protected ?ServerModsService $modsMemo = null;

    /** @var array<int, string>|null */
    protected ?array $backupIdsMemo = null;

    /** The mods folder could not be listed in this request (Wings unreachable or an error). */
    protected bool $listFailed = false;

    // ------------------------------------------------------------------------------------------------
    // Access, navigation, tabs
    // ------------------------------------------------------------------------------------------------

    public static function canAccess(): bool
    {
        $server = Filament::getTenant();
        if (!$server instanceof Server) {
            return false;
        }

        // Our own canAccess() replaces BlockAccessInConflict's, so the conflict check has to be repeated here.
        return parent::canAccess()
            && !$server->isInConflictState()
            && static::isVintageStory($server)
            && (bool) user()?->can(SubuserPermission::FileRead, $server);
    }

    /** Egg feature/tag, else egg name, else the startup command (egg #18 has no tags or features). */
    protected static function isVintageStory(Server $server): bool
    {
        $server->loadMissing('egg');
        $egg = $server->egg;

        if (array_intersect(['vs_mods', 'vintagestory'], $egg->features ?? []) !== []) {
            return true;
        }

        if (array_intersect(['vintagestory', 'vintage-story'], array_map('strtolower', $egg->tags ?? [])) !== []) {
            return true;
        }

        $name = strtolower((string) $egg->name);
        if (str_contains($name, 'vintage story') || str_contains($name, 'vintagestory')) {
            return true;
        }

        return str_contains((string) $server->startup, 'VintagestoryServer');
    }

    public static function getNavigationLabel(): string
    {
        return static::t('nav');
    }

    public function getTitle(): string
    {
        return static::t('title');
    }

    public function mount(): void
    {
        $this->loadDefaultActiveTab();
        $this->knownState = $this->serverState();
    }

    /**
     * Polled from the state banner. A partial render of the banner alone would leave every row action
     * disabled/enabled for the old state, so re-render the whole page when the state changed, else nothing.
     */
    public function pollServerState(): void
    {
        $state = $this->serverState();
        if ($state === $this->knownState) {
            $this->skipRender();

            return;
        }
        $this->knownState = $state;
        $this->flushCachedTableRecords();
    }

    /**
     * Each tab has its own table (records, columns, filters, actions). The table is built once while the
     * component boots, i.e. before the new activeTab is applied, so rebuild it after a switch.
     */
    public function updatedActiveTab(): void
    {
        $this->tableSearch = '';
        $this->tableSort = null;
        $this->tableFilters = null;
        $this->resetTable();
        $this->cachedDefaultTableColumnState = null;
        $this->applyTableColumnManager();
    }

    /** @return array<string, Tab> */
    public function getTabs(): array
    {
        return [
            'browse' => Tab::make(static::t('tabs.browse'))->icon('tabler-search'),
            'installed' => Tab::make(static::t('tabs.installed'))->icon('tabler-package'),
            'modpack' => Tab::make(static::t('tabs.modpack'))->icon('tabler-list-details'),
        ];
    }

    protected static function t(string $key, array $replace = []): string
    {
        return trans('vs-mod-manager::strings.' . $key, $replace);
    }

    // ------------------------------------------------------------------------------------------------
    // Service access (memoised for the current request)
    // ------------------------------------------------------------------------------------------------

    protected function server(): Server
    {
        /** @var Server $server */
        $server = Filament::getTenant();

        return $server;
    }

    protected function mods(): ServerModsService
    {
        return $this->modsMemo ??= app(ServerModsService::class)->forServer($this->server());
    }

    protected function moddb(): ModDbClient
    {
        return app(ModDbClient::class);
    }

    protected function selector(): ReleaseSelector
    {
        return app(ReleaseSelector::class);
    }

    /** Wings state: running|starting|stopping|offline, or "unknown" when the daemon can't be reached. */
    protected function serverState(): string
    {
        if ($this->stateMemo === null) {
            // Wings unreachable: remember it for a few seconds so the 5 s poll and every other request on the page
            // don't each wait for their own connect timeout. (Changes never use this: they ask Wings themselves.)
            $downKey = 'vsmm.wingsdown.' . $this->server()->uuid;
            if (Cache::has($downKey)) {
                return $this->stateMemo = 'missing';
            }
            try {
                $this->stateMemo = $this->mods()->state();
            } catch (Throwable $e) {
                report($e);
                $this->stateMemo = 'unknown';
            }
            if (in_array($this->stateMemo, ['missing', 'unknown'], true)) {
                Cache::put($downKey, 1, 10);
            }
        }

        return $this->stateMemo;
    }

    /** The state check could not reach Wings (or got an error). */
    protected function wingsUnreachable(): bool
    {
        return in_array($this->serverState(), ['missing', 'unknown'], true);
    }

    protected function isStopped(): bool
    {
        return $this->serverState() === 'offline';
    }

    protected function canMutate(): bool
    {
        $server = $this->server();
        $user = user();

        return $user !== null
            && $user->can(SubuserPermission::FileCreate, $server)
            && $user->can(SubuserPermission::FileUpdate, $server)
            && $user->can(SubuserPermission::FileDelete, $server);
    }

    protected function can(SubuserPermission $permission): bool
    {
        return (bool) user()?->can($permission, $this->server());
    }

    /** @return array{version: ?string, source: string} */
    protected function gameVersionInfo(): array
    {
        if ($this->gameVersionMemo === null) {
            if ($this->wingsUnreachable()) {
                return $this->gameVersionMemo = ['version' => null, 'source' => 'unknown'];
            }
            try {
                $this->gameVersionMemo = app(GameVersionService::class)->detect($this->server());
            } catch (Throwable $e) {
                report($e);
                $this->gameVersionMemo = ['version' => null, 'source' => 'unknown'];
            }
        }

        return $this->gameVersionMemo;
    }

    protected function gameVersion(): ?string
    {
        return $this->gameVersionInfo()['version'] ?: null;
    }

    /** Raw InstalledMod rows (no ModDB lookups). Empty when the daemon can't be read. */
    protected function installedList(): array
    {
        if ($this->listMemo === null) {
            if ($this->wingsUnreachable()) {
                // Every further Wings call would wait for its own timeout: one failed state check is enough.
                $this->listFailed = true;

                return $this->listMemo = [];
            }
            try {
                $this->listFailed = false;
                $this->listMemo = array_values($this->mods()->list());
            } catch (Throwable $e) {
                report($e);
                $this->listFailed = true;
                $this->listMemo = [];
            }
        }

        return $this->listMemo;
    }

    /** @return array<int, string> lower-case mod ids that have a backup */
    protected function backupIds(): array
    {
        if ($this->backupIdsMemo === null) {
            if ($this->wingsUnreachable()) {
                return $this->backupIdsMemo = [];
            }
            try {
                $this->backupIdsMemo = $this->mods()->backupModids();
            } catch (Throwable $e) {
                report($e);
                $this->backupIdsMemo = [];
            }
        }

        return $this->backupIdsMemo;
    }

    /** @return array<string, string> backups of mods that are no longer installed (removed with a backup) */
    protected function removedWithBackup(): array
    {
        $installed = array_map(fn (array $row) => strtolower((string) ($row['modid'] ?? '')), $this->installedList());
        $out = [];
        foreach (array_diff($this->backupIds(), $installed) as $id) {
            $out[$id] = $id;
        }

        return $out;
    }

    /**
     * Cache key of the annotated list: changes whenever a file, its enabled/pinned state, the game version or
     * the server state changes (a start writes a new server log, whose load errors are part of the warnings).
     */
    protected function annotateCacheKey(): string
    {
        return 'vsmm:annotated:' . $this->server()->id . ':' . md5(json_encode(array_map(
            static fn (array $m) => [$m['filename'] ?? '', $m['size'] ?? 0, $m['modified'] ?? 0, $m['disabled'] ?? false, $m['pinned'] ?? false],
            $this->installedList()
        )) . '|' . $this->gameVersion() . '|' . $this->serverState());
    }

    /** InstalledMod rows plus ModDB status and warnings. Cached for a minute so paging/sorting stays cheap. */
    protected function installedAnnotated(): array
    {
        if ($this->annotatedMemo === null) {
            try {
                $list = $this->installedList();
                $this->annotatedMemo = Cache::remember(
                    $this->annotateCacheKey(),
                    60,
                    fn () => array_values(app(ModStatusService::class)->annotate($this->server(), $list, $this->gameVersion()))
                );
            } catch (Throwable $e) {
                report($e);
                $this->annotatedMemo = array_map(static fn (array $m) => $m + ['moddbStatus' => 'unknown', 'latest' => null, 'warnings' => []], $this->installedList());
            }
        }

        return $this->annotatedMemo;
    }

    /** @return array<int, array<string, mixed>> */
    protected function catalogue(): array
    {
        // Entries without a mod id string can't be installed, so they are not listed.
        return $this->catalogueMemo ??= array_values(array_filter(
            $this->moddb()->catalogue(),
            static fn (array $row) => !empty($row['modidstrs'])
        ));
    }

    /** Installed modid (lower case) => InstalledMod row, for the "Installed" badge on the Browse tab. */
    protected function installedByModid(): array
    {
        $map = [];
        foreach ($this->installedList() as $mod) {
            if (!empty($mod['modid'])) {
                $map[strtolower((string) $mod['modid'])] = $mod;
            }
        }

        return $map;
    }

    /** Is there a newer release for this installed mod? Only known when the Installed tab already annotated it. */
    protected function updateFor(string $modid): ?string
    {
        foreach ($this->cachedAnnotated() as $mod) {
            if (strtolower((string) ($mod['modid'] ?? '')) === strtolower($modid) && ($mod['moddbStatus'] ?? '') === 'update') {
                return (string) ($mod['latest']['modversion'] ?? '');
            }
        }

        return null;
    }

    /** Annotated rows if they are already known (memo or cache); never triggers ModDB lookups. */
    protected function cachedAnnotated(): array
    {
        if ($this->annotatedMemo !== null) {
            return $this->annotatedMemo;
        }

        try {
            return (array) Cache::get($this->annotateCacheKey(), []);
        } catch (Throwable) {
            return [];
        }
    }

    /** Forget everything read from the server so the next render shows what is really on disk. */
    protected function forgetState(): void
    {
        $this->stateMemo = null;
        $this->gameVersionMemo = null;
        $this->listMemo = null;
        $this->backupIdsMemo = null;
        $this->annotatedMemo = null;
        $this->flushCachedTableRecords();
    }

    // ------------------------------------------------------------------------------------------------
    // Action plumbing
    // ------------------------------------------------------------------------------------------------

    /**
     * Make an action a "change": hidden without file create/update/delete, disabled (with a tooltip) unless
     * the server is offline. The service re-checks the state itself when the action runs.
     */
    protected function guarded(Action $action, string $label, ?\Closure $visible = null): Action
    {
        return $action
            ->visible(fn () => $this->canMutate() && ($visible === null || (bool) $visible()))
            ->disabled(fn () => !$this->isStopped())
            ->tooltip(fn () => $this->isStopped() ? $label : static::t('tooltip.stop_first', ['state' => $this->stateLabel()]));
    }

    protected function stateLabel(): string
    {
        $state = $this->serverState();
        $key = 'state.' . $state;
        $label = static::t($key);

        return $label === 'vs-mod-manager::strings.' . $key ? $state : $label;
    }

    /** Run a change, turning failures into notifications. $work returns a message or a service result array. */
    protected function attempt(string $title, \Closure $work): bool
    {
        if (!$this->denyUnlessCanMutate()) {
            return false;
        }

        try {
            $result = $work();
            $this->changed = true;
            $this->forgetState();

            Notification::make()->title($title)->body($this->messageOf($result))->success()->send();

            return true;
        } catch (ModManagerException $e) {
            $this->forgetState();
            Notification::make()->title(static::t('notify.failed'))->body($e->getMessage())->danger()->send();
        } catch (Throwable $e) {
            report($e);
            $this->forgetState();
            Notification::make()->title(static::t('notify.failed'))->body(static::t('notify.failed_unexpected'))->danger()->send();
        }

        return false;
    }

    /**
     * Permission check inside every change handler (Filament also refuses hidden actions, but don't rely on
     * visibility alone). Sends a notification and returns false when the user may not change files.
     */
    protected function denyUnlessCanMutate(): bool
    {
        if ($this->canMutate()) {
            return true;
        }

        Notification::make()->title(static::t('notify.failed'))->body(static::t('notify.no_permission'))->danger()->send();

        return false;
    }

    /** Notification body from several lines (bodies are rendered as sanitised HTML, so \n would be lost). */
    protected static function lines(array $lines): ?string
    {
        $lines = array_filter($lines, static fn ($l) => $l !== null && $l !== '');

        return $lines === [] ? null : implode('<br>', array_map(static fn ($l) => e((string) $l), $lines));
    }

    protected function messageOf(mixed $result): ?string
    {
        if (is_string($result)) {
            return $result;
        }

        if (is_array($result)) {
            return (string) ($result['message'] ?? $result['msg'] ?? '') ?: null;
        }

        return null;
    }

    // ------------------------------------------------------------------------------------------------
    // Power (same repository call as the console page)
    // ------------------------------------------------------------------------------------------------

    protected function sendPower(string $signal, SubuserPermission $permission): void
    {
        $server = $this->server();

        if (!$this->can($permission)) {
            return;
        }

        try {
            app(DaemonServerRepository::class)->setServer($server)->power($signal)->throw();
            cache()->forget("servers.$server->uuid.status");
            Notification::make()->title(static::t('power.sent_' . $signal))->success()->send();
        } catch (Throwable $e) {
            report($e);
            Notification::make()->title(static::t('power.failed'))->danger()->send();
        }

        $this->stateMemo = null;
    }

    /** @return array<int, Action> */
    protected function powerActions(): array
    {
        return [
            Action::make('power_start')
                ->label(static::t('power.start'))->button()->icon('tabler-player-play-filled')->color('primary')
                // Only the buttons that apply are shown: a disabled coloured button still looks clickable.
                ->visible(fn () => $this->can(SubuserPermission::ControlStart) && $this->serverState() === 'offline')
                ->action(fn () => $this->sendPower('start', SubuserPermission::ControlStart)),
            Action::make('power_restart')
                ->label(static::t('power.restart'))->button()->icon('tabler-reload')->color('gray')
                ->visible(fn () => $this->can(SubuserPermission::ControlRestart) && in_array($this->serverState(), ['running', 'starting'], true))
                ->action(fn () => $this->sendPower('restart', SubuserPermission::ControlRestart)),
            Action::make('power_stop')
                ->label(static::t('power.stop'))->button()->icon('tabler-player-stop-filled')->color('danger')
                ->visible(fn () => $this->can(SubuserPermission::ControlStop) && in_array($this->serverState(), ['running', 'starting'], true))
                ->action(fn () => $this->sendPower('stop', SubuserPermission::ControlStop)),
        ];
    }

    // ------------------------------------------------------------------------------------------------
    // Page content: banner, game version, hints, tab content
    // ------------------------------------------------------------------------------------------------

    public function content(Schema $schema): Schema
    {
        $components = [
            Callout::make(fn () => $this->bannerHeading())
                ->key('vsmm-state-banner')
                ->extraAttributes(['wire:poll.5s' => 'pollServerState'])
                ->status(fn () => $this->isStopped() ? 'success' : 'warning')
                ->description(fn () => $this->bannerText())
                ->actions($this->powerActions()),
            Callout::make(fn () => $this->gameVersionHeading())
                ->key('vsmm-game-version')
                ->status(fn () => in_array($this->gameVersionInfo()['source'], ['override', 'log'], true) ? 'info' : 'warning')
                ->description(fn () => static::t('gameversion.source_' . $this->gameVersionInfo()['source']))
                ->actions([$this->overrideAction()]),
        ];

        // Conditional parts use visible() closures: the schema can be cached earlier in the request (e.g. while
        // resolving one of its actions), before that action changes $changed / $pendingDeps.
        $components[] = Callout::make(static::t('hint.restart'))
            ->visible(fn () => $this->changed)
            ->info()
            ->description(static::t('hint.restart_body'));

        $components[] = Callout::make(static::t('deps.heading'))
            ->visible(fn () => $this->pendingDeps !== [])
            ->warning()
            ->description(fn () => implode(', ', array_map(
                static fn (array $d) => $d['modid'] . (($d['min'] ?? '') !== '' && $d['min'] !== '*' ? ' ≥ ' . $d['min'] : ''),
                $this->pendingDeps
            )))
            ->actions([$this->installDepsAction(), $this->dismissDepsAction()]);

        $components[] = $this->getTabsContentComponent();

        // Always part of the schema (visibility decided at render), so a tab switch can't leave it stale.
        $components[] = Section::make(static::t('modpack.export_heading'))
            ->visible(fn () => $this->activeTab === 'modpack')
            ->description(static::t('modpack.export_hint'))
            ->collapsible()
            ->schema([
                TextEntry::make('modpack_export')
                    ->hiddenLabel()
                    ->state(fn () => new HtmlString('<pre style="white-space:pre-wrap;font-family:monospace">' . e($this->exportText()) . '</pre>'))
                    ->copyable(fn () => true)
                    ->copyableState(fn () => $this->exportText()),
            ]);

        $components[] = EmbeddedTable::make();

        return $schema->components($components);
    }

    protected function bannerHeading(): string
    {
        return $this->isStopped()
            ? static::t('banner.stopped')
            : static::t('banner.not_stopped', ['state' => $this->stateLabel()]);
    }

    protected function bannerText(): string
    {
        return $this->isStopped() ? static::t('banner.stopped_body') : static::t('banner.not_stopped_body');
    }

    protected function gameVersionHeading(): string
    {
        $v = $this->gameVersion();

        return $v === null
            ? static::t('gameversion.unknown')
            : static::t('gameversion.heading', ['version' => $v]);
    }

    protected function overrideAction(): Action
    {
        return Action::make('override_game_version')
            ->label(static::t('gameversion.override'))->button()
            ->icon('tabler-pencil')
            ->color('gray')
            ->visible(fn () => $this->can(SubuserPermission::FileUpdate))
            ->modalHeading(static::t('gameversion.override_heading'))
            ->modalDescription(static::t('gameversion.override_hint'))
            ->fillForm(fn () => ['version' => $this->gameVersionInfo()['source'] === 'override' ? $this->gameVersion() : ''])
            ->schema([
                TextInput::make('version')
                    ->label(static::t('gameversion.override_field'))
                    ->placeholder('1.20.12')
                    ->helperText(static::t('gameversion.override_clear')),
            ])
            ->action(function (array $data) {
                if (!$this->can(SubuserPermission::FileUpdate)) {
                    return;
                }
                $version = trim((string) ($data['version'] ?? ''));

                if ($version !== '' && Version::parse($version) === null) {
                    Notification::make()->title(static::t('gameversion.invalid'))->danger()->send();

                    return;
                }

                try {
                    $this->mods()->setGameVersionOverride($version === '' ? null : $version);
                    $this->forgetState();
                    Notification::make()->title(static::t('gameversion.saved'))->success()->send();
                } catch (Throwable $e) {
                    report($e);
                    Notification::make()->title(static::t('notify.failed'))->body($e instanceof ModManagerException ? $e->getMessage() : static::t('notify.failed_unexpected'))->danger()->send();
                }
            });
    }

    // ------------------------------------------------------------------------------------------------
    // Header actions (per tab)
    // ------------------------------------------------------------------------------------------------

    /**
     * @return array<int, Action>
     *
     * Header actions are cached while the component boots (before a tab switch is applied), so every tab's
     * actions are always registered and only their visibility depends on the active tab.
     */
    protected function getHeaderActions(): array
    {
        $on = fn (string $tab) => fn () => $this->activeTab === $tab;

        return [
            Action::make('open_folder')
                ->label(static::t('actions.open_folder'))
                ->icon('tabler-folder-open')
                ->color('gray')
                ->url(fn () => \App\Filament\Server\Resources\Files\Pages\ListFiles::getUrl(['path' => 'data/Mods']), true),
            Action::make('check_updates')
                ->label(static::t('actions.check_updates'))
                ->icon('tabler-refresh')
                ->color('gray')
                ->visible($on('installed'))
                ->action(fn () => $this->checkForUpdates()),
            $this->guarded(
                Action::make('update_all')
                    ->label(static::t('actions.update_all'))
                    ->icon('tabler-arrow-up-circle')
                    ->color('warning')
                    ->requiresConfirmation()
                    ->modalHeading(static::t('actions.update_all'))
                    ->modalDescription(static::t('actions.update_all_body'))
                    ->action(fn () => $this->updateAll()),
                static::t('actions.update_all'),
                $on('installed')
            ),
            $this->guarded(
                Action::make('restore_removed')
                    ->label(static::t('actions.restore_removed'))
                    ->icon('tabler-arrow-back-up')
                    ->color('gray')
                    ->modalHeading(static::t('actions.restore_removed'))
                    ->modalDescription(static::t('actions.restore_removed_body'))
                    ->schema([
                        Select::make('modid')->label(static::t('actions.restore_removed_mod'))
                            ->options(fn () => $this->removedWithBackup())->required(),
                    ])
                    ->action(fn (array $data) => $this->attempt(
                        static::t('notify.rolled_back', ['name' => (string) $data['modid']]),
                        fn () => $this->mods()->rollback((string) $data['modid'])
                    )),
                static::t('actions.restore_removed'),
                fn () => $this->activeTab === 'installed' && $this->removedWithBackup() !== []
            ),
            Action::make('download_export')
                ->label(static::t('modpack.download'))
                ->icon('tabler-download')
                ->color('gray')
                ->visible($on('modpack'))
                ->action(fn () => $this->downloadExport()),
            // The preview only reads, so it works while the server runs; applying it is a guarded change.
            Action::make('import_modpack')
                ->label(static::t('modpack.import'))
                ->icon('tabler-file-import')
                ->color('primary')
                ->visible(fn () => $this->activeTab === 'modpack' && $this->canMutate())
                ->modalHeading(static::t('modpack.import_heading'))
                ->modalDescription(static::t('modpack.import_hint'))
                ->modalSubmitActionLabel(static::t('modpack.preview'))
                ->schema([
                    Textarea::make('text')
                        ->label(static::t('modpack.import_field'))
                        ->placeholder("carryon@1.8.0\nprimitivesurvival\nhttps://mods.vintagestory.at/expandedfoods")
                        ->rows(12)
                        ->maxLength(20000)
                        ->required(),
                ])
                ->action(fn (array $data) => $this->previewImport((string) $data['text'])),
            $this->guarded(
                Action::make('apply_import')
                    ->label(static::t('modpack.apply'))
                    ->icon('tabler-check')
                    ->color('success')
                    ->requiresConfirmation()
                    ->modalDescription(static::t('modpack.apply_body'))
                    ->action(fn () => $this->applyImport()),
                static::t('modpack.apply'),
                fn () => $this->activeTab === 'modpack' && $this->importToken !== null
            ),
            Action::make('clear_import')
                ->label(static::t('modpack.clear'))
                ->icon('tabler-x')
                ->color('gray')
                ->visible(fn () => $this->activeTab === 'modpack' && $this->importToken !== null)
                ->action(function () {
                    $this->importToken = null;
                    $this->flushCachedTableRecords();
                }),
        ];
    }

    /** Re-ask the ModDB about every installed mod (drops the cached answers) and re-annotate the list. */
    protected function checkForUpdates(): void
    {
        try {
            Cache::forget($this->annotateCacheKey());
            foreach ($this->installedList() as $row) {
                foreach ([$row['modid'] ?? null, $row['moddb']['moddbid'] ?? null] as $key) {
                    if ($key !== null && $key !== '') {
                        $this->moddb()->forgetMod($key);
                    }
                }
            }
        } catch (Throwable $e) {
            report($e);
        }
        $this->forgetState();
        $this->installedAnnotated(); // ask now, so a failure can be reported
        if ($this->moddb()->hadFailure()) {
            Cache::forget($this->annotateCacheKey()); // don't keep the half answer for a minute
            Notification::make()->title(static::t('moddb_down.title'))->body(static::t('moddb_down.check'))->warning()->send();

            return;
        }
        Notification::make()->title(static::t('notify.checked'))->success()->send();
    }

    /** Stream the export as a text file download. */
    protected function downloadExport(): \Symfony\Component\HttpFoundation\StreamedResponse
    {
        $text = $this->exportText();

        return response()->streamDownload(static function () use ($text) {
            echo $text;
        }, 'vs-modpack-' . $this->server()->uuid_short . '.txt', ['Content-Type' => 'text/plain; charset=utf-8']);
    }

    // ------------------------------------------------------------------------------------------------
    // Table
    // ------------------------------------------------------------------------------------------------

    public function table(Table $table): Table
    {
        return match ($this->activeTab) {
            'installed' => $this->installedTable($table),
            'modpack' => $this->modpackTable($table),
            default => $this->browseTable($table),
        };
    }

    // ---- Browse -----------------------------------------------------------------------------------

    protected function browseTable(Table $table): Table
    {
        return $table
            ->records(function (?string $search, int|string $page, int|string $recordsPerPage, ?array $filters, ?string $sortColumn, ?string $sortDirection) {
                $perPage = max(1, (int) $recordsPerPage ?: 20);
                $page = max(1, (int) $page);

                $rows = $this->filterCatalogue($this->catalogue(), (string) $search, $filters ?? []);
                $rows = $this->sortCatalogue($rows, $sortColumn ?: 'downloads', ($sortDirection ?: 'desc') === 'asc' ? 'asc' : 'desc');

                $slice = [];
                foreach (array_slice($rows, ($page - 1) * $perPage, $perPage) as $row) {
                    $slice['m' . $row['modid']] = $row;
                }

                return new LengthAwarePaginator($slice, count($rows), $perPage, $page);
            })
            ->paginated([20])
            ->defaultSort('downloads', 'desc')
            ->emptyStateHeading(fn () => $this->moddb()->hadFailure() ? static::t('moddb_down.title') : null)
            ->emptyStateDescription(fn () => $this->moddb()->hadFailure() ? static::t('moddb_down.browse') : null)
            ->searchPlaceholder(static::t('browse.search'))
            ->columns([
                ImageColumn::make('logo')->label('')->imageSize(40),
                TextColumn::make('name')
                    ->label(static::t('col.name'))
                    ->searchable()
                    ->sortable()
                    ->wrap()
                    ->extraAttributes(['style' => 'overflow-wrap:anywhere;min-width:0'])
                    ->url(fn (array $record) => $this->moddb()->modPageUrl($record), true)
                    ->description(fn (array $record) => mb_strimwidth((string) ($record['summary'] ?? ''), 0, 140, '…')),
                TextColumn::make('author')->label(static::t('col.author'))->toggleable()->visibleFrom('md'),
                TextColumn::make('downloads')->label(static::t('col.downloads'))->icon('tabler-download')->numeric()->sortable()->visibleFrom('md'),
                TextColumn::make('follows')->label(static::t('col.follows'))->icon('tabler-heart')->numeric()->sortable()->toggleable()->visibleFrom('md'),
                TextColumn::make('trendingpoints')->label(static::t('col.trending'))->icon('tabler-flame')->numeric()->sortable()->toggleable(isToggledHiddenByDefault: true)->visibleFrom('md'),
                TextColumn::make('lastreleased')
                    ->label(static::t('col.updated'))
                    ->icon('tabler-calendar')
                    ->visibleFrom('md')
                    ->sortable()
                    ->formatStateUsing(fn ($state) => ($c = $this->toCarbon($state)) ? $c->diffForHumans() : '')
                    ->toggleable(),
                TextColumn::make('side')
                    ->label(static::t('col.side'))
                    ->badge()
                    ->color('gray')
                    ->visibleFrom('md')
                    ->formatStateUsing(fn ($state) => static::t('side.' . strtolower((string) $state)))
                    ->toggleable(),
                TextColumn::make('tags')->label(static::t('col.tags'))->badge()->color('gray')->limitList(3)->toggleable(isToggledHiddenByDefault: true),
                TextColumn::make('install_state')
                    ->label(static::t('col.status'))
                    ->badge()
                    ->state(fn (array $record) => $this->browseStatus($record))
                    ->color(fn ($state) => match ($state) {
                        'update' => 'warning',
                        'installed' => 'success',
                        default => 'gray',
                    })
                    ->formatStateUsing(fn ($state) => $state ? static::t('browse.' . $state) : ''),
            ])
            ->filters([
                SelectFilter::make('side')
                    ->label(static::t('col.side'))
                    ->options([
                        'both' => static::t('side.both'),
                        'client' => static::t('side.client'),
                        'server' => static::t('side.server'),
                    ]),
                SelectFilter::make('tag')
                    ->label(static::t('col.tags'))
                    ->multiple()
                    ->searchable()
                    ->options(fn () => $this->tagOptions()),
            ])
            ->recordActions([
                Action::make('details')
                    ->iconButton()
                    ->icon('tabler-info-circle')
                    ->color('info')
                    ->tooltip(static::t('actions.details'))
                    ->slideOver()
                    ->modalHeading(fn (array $record) => (string) $record['name'])
                    ->modalSubmitAction(false)
                    ->modalCancelActionLabel(static::t('actions.close'))
                    ->schema(fn (array $record) => $this->detailSchema($record)),
                $this->guarded(
                    Action::make('install')
                        ->iconButton()
                        ->icon('tabler-download')
                        ->color('success')
                        ->modalHeading(fn (array $record) => static::t('actions.install_heading', ['name' => $record['name']]))
                        ->modalSubmitActionLabel(static::t('actions.install'))
                        ->schema(fn (array $record) => [
                            Select::make('releaseid')
                                ->label(static::t('actions.version'))
                                ->options(fn () => $this->releaseOptions($record['modid']))
                                ->default(fn () => $this->recommendedReleaseId($record['modid']))
                                ->helperText(fn () => static::t('actions.version_hint', ['version' => $this->gameVersion() ?? '?']))
                                ->required()
                                ->searchable(),
                        ])
                        ->action(fn (array $data, array $record) => $this->installFromBrowse($record, (int) $data['releaseid'])),
                    static::t('actions.install'),
                    fn () => true
                ),
            ])
            ->toolbarActions([]);
    }

    /** @return array<string, string> */
    protected function tagOptions(): array
    {
        try {
            $names = array_values(array_unique(array_map('strval', array_values($this->moddb()->tags()))));
            sort($names, SORT_NATURAL | SORT_FLAG_CASE);

            return array_combine($names, $names) ?: [];
        } catch (Throwable $e) {
            report($e);

            return [];
        }
    }

    /**
     * @param  array<int, array<string, mixed>>  $rows
     * @param  array<string, mixed>  $filters
     * @return array<int, array<string, mixed>>
     */
    protected function filterCatalogue(array $rows, string $search, array $filters): array
    {
        $needle = mb_strtolower(trim($search));
        $side = $filters['side']['value'] ?? null;
        $tags = array_map('strtolower', array_filter((array) ($filters['tag']['values'] ?? [])));

        return array_values(array_filter($rows, function (array $row) use ($needle, $side, $tags) {
            if ($side && strtolower((string) ($row['side'] ?? '')) !== $side) {
                return false;
            }

            if ($tags !== [] && array_diff($tags, array_map('strtolower', (array) ($row['tags'] ?? []))) !== []) {
                return false;
            }

            if ($needle === '') {
                return true;
            }

            $haystack = mb_strtolower(implode(' ', [
                $row['name'] ?? '', $row['summary'] ?? '', $row['author'] ?? '',
                implode(' ', (array) ($row['modidstrs'] ?? [])),
            ]));

            return str_contains($haystack, $needle);
        }));
    }

    /**
     * @param  array<int, array<string, mixed>>  $rows
     * @return array<int, array<string, mixed>>
     */
    protected function sortCatalogue(array $rows, string $column, string $direction): array
    {
        $value = fn (array $r) => match ($column) {
            'name' => mb_strtolower((string) ($r['name'] ?? '')),
            'lastreleased' => $this->toCarbon($r['lastreleased'] ?? null)?->getTimestamp() ?? 0,
            default => (float) ($r[$column] ?? 0),
        };

        usort($rows, fn (array $a, array $b) => $direction === 'asc' ? $value($a) <=> $value($b) : $value($b) <=> $value($a));

        return $rows;
    }

    protected function toCarbon(mixed $value): ?Carbon
    {
        if ($value === null || $value === '') {
            return null;
        }

        try {
            return is_numeric($value) ? Carbon::createFromTimestamp((int) $value) : Carbon::parse((string) $value);
        } catch (Throwable) {
            return null;
        }
    }

    /** 'installed' | 'update' | null for a catalogue row. */
    protected function browseStatus(array $record): ?string
    {
        $installed = $this->installedByModid();

        foreach ((array) ($record['modidstrs'] ?? []) as $modid) {
            if (isset($installed[strtolower((string) $modid)])) {
                return $this->updateFor((string) $modid) ? 'update' : 'installed';
            }
        }

        return null;
    }

    /** @return array<string, mixed>|null the ModDB mod, or null when it can't be loaded */
    protected function loadMod(string|int $idOrModid): ?array
    {
        try {
            return $this->moddb()->mod($idOrModid);
        } catch (Throwable $e) {
            report($e);

            return null;
        }
    }

    /** @return array<int, array<string, mixed>> releases, highest mod version first */
    protected function sortedReleases(?array $mod): array
    {
        return $mod ? array_values($this->selector()->sort($mod['releases'] ?? [])) : [];
    }

    /** @return array<int, string> releaseid => label, with a compatibility hint */
    protected function releaseOptions(string|int|null $idOrModid, ?string $forModid = null): array
    {
        if ($idOrModid === null) {
            return [];
        }
        $releases = $this->sortedReleases($this->loadMod($idOrModid));
        if ($forModid !== null && ($own = $this->selector()->forModid($releases, $forModid)) !== []) {
            $releases = $own;
        }
        $options = [];
        foreach (array_slice($this->compatibleFirst($releases), 0, 60) as $release) {
            $options[(int) $release['releaseid']] = $this->releaseLabel($release);
        }

        return $options;
    }

    /**
     * Releases for this server's game version first (exact, same minor, newer patch), then the rest, each
     * group highest version first. Lists are cut off, and a mod with many releases for newer games would
     * otherwise push every installable release out of the list.
     *
     * @param  array<int, array<string, mixed>>  $releases  sorted, highest version first
     * @return array<int, array<string, mixed>>
     */
    protected function compatibleFirst(array $releases): array
    {
        $gv = $this->gameVersion();
        if ($gv === null) {
            return $releases;
        }
        $rank = [ReleaseSelector::EXACT => 0, ReleaseSelector::SAME_MINOR => 1, ReleaseSelector::NEWER_PATCH => 2];
        $keyed = [];
        foreach (array_values($releases) as $i => $release) {
            $keyed[] = [$rank[$this->selector()->compatibility($release, $gv)] ?? 3, $i, $release];
        }
        usort($keyed, static fn (array $a, array $b) => [$a[0], $a[1]] <=> [$b[0], $b[1]]);

        return array_column($keyed, 2);
    }

    protected function releaseLabel(array $release): string
    {
        return trim(($release['modversion'] ?? '?') . ' — ' . $this->compatLabel($release) . ' (' . implode(', ', (array) ($release['tags'] ?? [])) . ')');
    }

    protected function compatLabel(array $release): string
    {
        $gv = $this->gameVersion();
        $tier = $gv ? $this->selector()->compatibility($release, $gv) : ReleaseSelector::OTHER;

        return static::t('compat.' . $tier);
    }

    protected function compatColor(array $release): string
    {
        $gv = $this->gameVersion();

        return match ($gv ? $this->selector()->compatibility($release, $gv) : ReleaseSelector::OTHER) {
            ReleaseSelector::EXACT => 'success',
            ReleaseSelector::SAME_MINOR => 'info',
            ReleaseSelector::NEWER_PATCH => 'warning',
            default => 'gray',
        };
    }

    /** $forModid: on ModDB pages that ship several mods, only consider the releases of this mod id. */
    protected function recommendedRelease(?array $mod, ?string $installedVersion = null, ?string $forModid = null): ?array
    {
        $releases = $this->sortedReleases($mod);
        if ($forModid !== null && ($own = $this->selector()->forModid($releases, $forModid)) !== []) {
            $releases = $own;
        }
        $gv = $this->gameVersion();

        if ($gv === null) {
            return $releases[0] ?? null;
        }

        return $this->selector()->recommend($releases, $gv, (bool) config('vs-mod-manager.allow_prereleases'), $installedVersion);
    }

    protected function recommendedReleaseId(string|int $idOrModid): ?int
    {
        $release = $this->recommendedRelease($this->loadMod($idOrModid));

        return $release ? (int) $release['releaseid'] : null;
    }

    /** @param array<int, array<string, mixed>> $releases */
    protected function findRelease(array $releases, int $releaseId): ?array
    {
        foreach ($releases as $release) {
            if ((int) ($release['releaseid'] ?? 0) === $releaseId) {
                return $release;
            }
        }

        return null;
    }

    // ---- Detail slide-over ------------------------------------------------------------------------

    /** @return array<int, mixed> */
    protected function detailSchema(array $record): array
    {
        $mod = $this->loadMod($record['modid']);

        if ($mod === null) {
            return [TextEntry::make('detail_error')->hiddenLabel()->state(static::t('detail.unavailable'))->color('danger')];
        }

        $url = $this->moddb()->modPageUrl($mod);

        $components = [
            Grid::make(['default' => 2, 'md' => 4])->schema([
                TextEntry::make('d_author')->label(static::t('col.author'))->state($mod['author'] ?? ''),
                TextEntry::make('d_downloads')->label(static::t('col.downloads'))->state((int) ($mod['downloads'] ?? 0))->numeric(),
                TextEntry::make('d_side')->label(static::t('col.side'))->state(static::t('side.' . strtolower((string) ($mod['side'] ?? 'both'))))->badge()->color('gray'),
                TextEntry::make('d_tags')->label(static::t('col.tags'))->state(array_values((array) ($mod['tags'] ?? [])))->badge()->color('gray'),
            ]),
            TextEntry::make('d_link')->label(static::t('detail.moddb_page'))->state($url)->url($url, true)->icon('tabler-external-link'),
            Section::make(static::t('detail.description'))
                ->collapsible()
                ->schema([
                    // ->html() runs the text through Str::sanitizeHtml(), so the author's HTML is safe to show.
                    TextEntry::make('d_text')->hiddenLabel()->state((string) ($mod['text'] ?? ''))->html()->prose(),
                ]),
        ];

        $releases = $this->sortedReleases($mod);
        $installed = $this->installedByModid();
        $installedVersions = [];
        // ModDbClient::mod() has no modidstrs; the mod ids of a ModDB entry are those of its releases.
        $modids = array_unique(array_filter(array_map(static fn (array $r) => strtolower((string) ($r['modidstr'] ?? '')), $releases)));
        foreach ($modids as $id) {
            if (isset($installed[strtolower((string) $id)])) {
                $installedVersions[] = (string) ($installed[strtolower((string) $id)]['version'] ?? '');
            }
        }

        foreach (array_slice($this->compatibleFirst($releases), 0, 25) as $i => $release) {
            $isInstalled = in_array((string) ($release['modversion'] ?? ''), $installedVersions, true);

            $body = [
                TextEntry::make("r{$i}_compat")->label(static::t('detail.compat'))->state($this->compatLabel($release))->badge()->color($this->compatColor($release)),
                TextEntry::make("r{$i}_tags")->label(static::t('detail.game_versions'))->state(array_values((array) ($release['tags'] ?? [])))->badge()->color('gray'),
                TextEntry::make("r{$i}_date")->label(static::t('detail.released'))->state(fn () => ($c = $this->toCarbon($release['created'] ?? null)) ? $c->diffForHumans() : ''),
                TextEntry::make("r{$i}_downloads")->label(static::t('col.downloads'))->state((int) ($release['downloads'] ?? 0))->numeric(),
            ];

            if (!empty($release['changelog'])) {
                $body[] = TextEntry::make("r{$i}_changelog")->label(static::t('detail.changelog'))->state((string) $release['changelog'])->html()->prose();
            }

            $install = $isInstalled
                ? Action::make("r{$i}_installed")->label(static::t('browse.installed'))->button()->icon('tabler-check')->color('success')->disabled()
                : $this->guarded(
                    Action::make("r{$i}_install")
                        ->label(static::t('actions.install'))
                        ->button()
                        ->icon('tabler-download')
                        ->requiresConfirmation()
                        ->modalDescription(fn () => $this->compatLabel($release) . ' — ' . static::t('actions.install_body', ['name' => $mod['name'] ?? '', 'version' => $release['modversion'] ?? '']))
                        ->action(fn () => $this->doInstall($mod, $release)),
                    static::t('actions.install'),
                    fn () => true
                );

            $components[] = Section::make((string) ($release['modversion'] ?? '?'))
                ->description($this->compatLabel($release))
                ->headerActions([$install])
                ->collapsible()
                ->collapsed($i > 0)
                ->schema($body);
        }

        if (count($releases) > 25) {
            $components[] = TextEntry::make('d_more')->hiddenLabel()->state(static::t('detail.older_hidden', ['count' => count($releases) - 25]))->color('gray');
        }

        return $components;
    }

    // ---- Install (Browse) and dependencies --------------------------------------------------------

    protected function installFromBrowse(array $record, int $releaseId): void
    {
        $mod = $this->loadMod($record['modid']);
        $release = $mod ? $this->findRelease($mod['releases'] ?? [], $releaseId) : null;

        if ($mod === null || $release === null) {
            Notification::make()->title(static::t('notify.failed'))->body(static::t('detail.unavailable'))->danger()->send();

            return;
        }

        $this->doInstall($mod, $release);
    }

    protected function doInstall(array $mod, array $release): void
    {
        $ok = $this->attempt(
            static::t('notify.installed', ['name' => $mod['name'] ?? '?', 'version' => $release['modversion'] ?? '?']),
            fn () => $this->mods()->install($mod, $release)
        );

        if ($ok) {
            $this->offerDependencies([], (string) ($release['modidstr'] ?? ''));
        }
    }

    /** After an install, queue missing or too-old dependencies of the mod we just wrote. */
    protected function offerDependencies(array $modidstrs, string $modid): void
    {
        $candidates = array_filter([$modid, ...array_map('strval', $modidstrs)]);

        try {
            $installed = [];
            foreach ($this->installedList() as $row) {
                if (!empty($row['modid'])) {
                    $installed[strtolower((string) $row['modid'])] = $row;
                }
            }

            foreach ($candidates as $candidate) {
                $row = $installed[strtolower((string) $candidate)] ?? null;
                if ($row === null) {
                    continue;
                }

                foreach ((array) ($row['dependencies'] ?? []) as $depId => $min) {
                    $depId = strtolower((string) $depId);
                    $min = (string) $min;

                    if ($depId === '' || in_array($depId, self::BUILTIN_IDS, true)) {
                        continue;
                    }

                    $have = $installed[$depId]['version'] ?? null;
                    $needsMin = $min !== '' && $min !== '*';

                    if ($have === null || ($needsMin && Version::compare((string) $have, $min) < 0)) {
                        $this->pendingDeps[$depId] = ['modid' => $depId, 'min' => $min, 'needed_by' => (string) $candidate];
                    }
                }

                break;
            }
        } catch (Throwable $e) {
            report($e);
        }
    }

    protected function installDepsAction(): Action
    {
        return $this->guarded(
            Action::make('install_deps')
                ->label(static::t('deps.install'))->button()
                ->icon('tabler-download')
                ->color('warning')
                ->action(fn () => $this->installPendingDeps()),
            static::t('deps.install')
        );
    }

    protected function dismissDepsAction(): Action
    {
        return Action::make('dismiss_deps')
            ->label(static::t('deps.dismiss'))->button()
            ->color('gray')
            ->action(fn () => $this->pendingDeps = []);
    }

    protected function installPendingDeps(): void
    {
        if (!$this->denyUnlessCanMutate()) {
            return;
        }
        $done = [];
        $problems = [];
        $rounds = 0;

        // Installing a dependency can reveal more, so loop a few times.
        while ($this->pendingDeps !== [] && $rounds++ < 6) {
            $batch = $this->pendingDeps;
            $this->pendingDeps = [];

            foreach ($batch as $dep) {
                $mod = $this->loadMod($dep['modid']);
                $release = $this->recommendedRelease($mod, null, $dep['modid']);

                if ($mod === null || $release === null) {
                    $problems[] = static::t('deps.not_found', ['modid' => $dep['modid']]);

                    continue;
                }

                $min = $dep['min'];
                if ($min !== '' && $min !== '*' && Version::compare((string) $release['modversion'], $min) < 0) {
                    $problems[] = static::t('deps.too_old', ['modid' => $dep['modid'], 'min' => $min, 'version' => $release['modversion']]);

                    continue;
                }

                try {
                    $this->mods()->install($mod, $release);
                    $this->forgetState();
                    $done[] = $dep['modid'] . ' ' . $release['modversion'];
                    $this->offerDependencies([], (string) ($release['modidstr'] ?? $dep['modid']));
                } catch (ModManagerException $e) {
                    $problems[] = $dep['modid'] . ': ' . $e->getMessage();
                } catch (Throwable $e) {
                    report($e);
                    $problems[] = $dep['modid'] . ': ' . static::t('notify.failed_unexpected');
                }
            }
        }

        $this->changed = $this->changed || $done !== [];

        $notification = Notification::make()
            ->title(static::t($problems === [] ? 'deps.done' : 'deps.partial'))
            ->body(static::lines([
                $done !== [] ? static::t('deps.installed_list', ['list' => implode(', ', $done)]) : null,
                ...$problems,
            ]));

        ($problems === [] ? $notification->success() : $notification->warning())->send();
    }

    // ---- Installed --------------------------------------------------------------------------------

    protected function installedTable(Table $table): Table
    {
        return $table
            ->records(function (?string $search, int|string $page, int|string $recordsPerPage, ?string $sortColumn, ?string $sortDirection) {
                $perPage = max(1, (int) $recordsPerPage ?: 25);
                $page = max(1, (int) $page);
                $needle = mb_strtolower(trim((string) $search));

                $rows = array_values(array_filter($this->installedAnnotated(), static function (array $row) use ($needle) {
                    return $needle === '' || str_contains(mb_strtolower(implode(' ', [$row['name'] ?? '', $row['modid'] ?? '', $row['filename'] ?? ''])), $needle);
                }));

                $column = $sortColumn ?: 'name';
                $dir = ($sortDirection ?: 'asc') === 'desc' ? -1 : 1;
                usort($rows, static function (array $a, array $b) use ($column, $dir) {
                    $va = mb_strtolower((string) ($a[$column] ?? $a['filename'] ?? ''));
                    $vb = mb_strtolower((string) ($b[$column] ?? $b['filename'] ?? ''));

                    return $dir * strnatcmp($va, $vb);
                });

                $slice = [];
                foreach (array_slice($rows, ($page - 1) * $perPage, $perPage) as $row) {
                    $slice[(string) $row['filename']] = $row;
                }

                return new LengthAwarePaginator($slice, count($rows), $perPage, $page);
            })
            ->paginated([25, 50, 100])
            ->defaultSort('name')
            ->searchPlaceholder(static::t('installed.search'))
            ->emptyStateHeading(fn () => $this->listFailed ? static::t('installed.list_failed') : static::t('installed.empty'))
            ->emptyStateDescription(fn () => $this->listFailed ? static::t('installed.list_failed_body') : null)
            ->columns([
                TextColumn::make('name')
                    ->label(static::t('col.name'))
                    ->searchable()
                    ->sortable()
                    ->state(fn (array $record) => $record['name'] ?: ($record['modid'] ?: $record['filename']))
                    ->wrap()
                    ->extraAttributes(['style' => 'overflow-wrap:anywhere;min-width:0'])
                    ->url(fn (array $record) => $record['moddbUrl'] ?? null, true)
                    ->description(fn (array $record) => $record['filename'] . (($record['verified'] ?? true) ? '' : ' · ' . static::t('installed.unverified'))),
                TextColumn::make('modid')->label(static::t('col.modid'))->sortable()->toggleable()->visibleFrom('md'),
                TextColumn::make('version')->label(static::t('col.version'))->sortable()->visibleFrom('md'),
                TextColumn::make('moddbStatus')
                    ->label(static::t('col.moddb'))
                    ->badge()
                    ->visibleFrom('md')
                    ->state(fn (array $record) => $record['moddbStatus'] ?? 'unknown')
                    ->color(fn ($state) => match ($state) {
                        'up_to_date' => 'success',
                        'update' => 'warning',
                        'not_on_moddb', 'version_not_on_moddb' => 'danger',
                        default => 'gray',
                    })
                    ->formatStateUsing(fn ($state, array $record) => $state === 'update'
                        ? static::t('status.update_to', ['version' => $record['latest']['modversion'] ?? '?'])
                        : static::t('status.' . $state)),
                TextColumn::make('side')->label(static::t('col.side'))->badge()->color('gray')
                    ->formatStateUsing(fn ($state) => $state ? static::t('side.' . strtolower((string) $state)) : '')->toggleable()->visibleFrom('md'),
                TextColumn::make('state')
                    ->label(static::t('col.state'))
                    ->badge()
                    ->visibleFrom('md')
                    ->state(fn (array $record) => ($record['kind'] ?? '') === 'ignored' ? 'ignored' : (($record['disabled'] ?? false) ? 'disabled' : 'enabled'))
                    ->color(fn ($state) => match ($state) {
                        'enabled' => 'success',
                        'disabled' => 'danger',
                        default => 'gray',
                    })
                    ->formatStateUsing(fn ($state) => static::t('state_mod.' . $state)),
                TextColumn::make('pinned')
                    ->label(static::t('col.pinned'))
                    ->icon(fn ($state) => $state ? 'tabler-pin-filled' : null)
                    ->state(fn (array $record) => ($record['pinned'] ?? false) ? static::t('state_mod.pinned') : '')
                    ->toggleable()
                    ->visibleFrom('md'),
                TextColumn::make('warnings')
                    ->label(static::t('col.warnings'))
                    ->badge()
                    ->color('warning')
                    ->visibleFrom('md')
                    ->state(fn (array $record) => array_map(fn (string $w) => $this->warningLabel($w), (array) ($record['warnings'] ?? []))),
                // Phones: the wide table scrolls sideways and pushes the actions menu off screen, so the columns
                // above are hidden below the md breakpoint and this one shows the essentials as badges instead.
                TextColumn::make('summary')
                    ->label('')
                    ->hiddenFrom('md')
                    ->badge()
                    ->wrap()
                    ->extraAttributes(['style' => 'overflow-wrap:anywhere'])
                    ->state(fn (array $record) => array_values(array_filter([
                        ($record['disabled'] ?? false) ? static::t('state_mod.disabled') : null,
                        $record['version'] ?? null,
                        ($record['moddbStatus'] ?? '') === 'update' ? static::t('status.update_to', ['version' => $record['latest']['modversion'] ?? '?']) : null,
                        ($record['pinned'] ?? false) ? static::t('state_mod.pinned') : null,
                        ...array_map(fn (string $w) => $this->warningLabel($w), (array) ($record['warnings'] ?? [])),
                    ])))
                    ->color(fn ($state, array $record) => match (true) {
                        ($record['disabled'] ?? false) && $state === static::t('state_mod.disabled') => 'danger',
                        $state === ($record['version'] ?? null) => 'gray',
                        ($record['pinned'] ?? false) && $state === static::t('state_mod.pinned') => 'info',
                        default => 'warning',
                    }),
            ])
            ->recordActions([
                ActionGroup::make([
                    $this->guarded(
                        Action::make('update')
                            ->label(static::t('actions.update'))
                            ->icon('tabler-arrow-up-circle')
                            ->color('warning')
                            ->requiresConfirmation()
                            ->modalDescription(fn (array $record) => static::t('actions.update_body', ['name' => $record['name'] ?: $record['modid'], 'from' => $record['version'], 'to' => $record['latest']['modversion'] ?? '?']))
                            ->action(fn (array $record) => $this->attempt(
                                static::t('notify.updated', ['name' => $record['name'] ?: $record['modid']]),
                                fn () => $this->mods()->update($record, $record['latest'])
                            )),
                        static::t('actions.update'),
                        fn () => false
                    )->visible(fn (array $record) => $this->canMutate() && ($record['moddbStatus'] ?? '') === 'update' && !empty($record['latest'])),
                    $this->guarded(
                        Action::make('choose_version')
                            ->label(static::t('actions.choose_version'))
                            ->icon('tabler-versions')
                            ->modalHeading(fn (array $record) => static::t('actions.choose_version_heading', ['name' => $record['name'] ?: $record['modid']]))
                            ->schema(fn (array $record) => [
                                Select::make('releaseid')
                                    ->label(static::t('actions.version'))
                                    ->options(fn () => $this->releaseOptions($this->moddbKey($record), $record['modid'] ?? null))
                                    ->helperText(static::t('actions.choose_version_hint'))
                                    ->required()
                                    ->searchable(),
                            ])
                            ->action(function (array $data, array $record) {
                                $mod = $this->loadMod($this->moddbKey($record));
                                $release = $mod ? $this->findRelease($mod['releases'] ?? [], (int) $data['releaseid']) : null;

                                if ($release === null) {
                                    Notification::make()->title(static::t('notify.failed'))->body(static::t('detail.unavailable'))->danger()->send();

                                    return;
                                }

                                $this->attempt(
                                    static::t('notify.updated', ['name' => $record['name'] ?: $record['modid']]),
                                    fn () => $this->mods()->update($record, $release)
                                );
                            }),
                        static::t('actions.choose_version'),
                        fn () => false
                    )->visible(fn (array $record) => $this->canMutate() && $this->moddbKey($record) !== null),
                    $this->guarded(
                        Action::make('disable')
                            ->label(static::t('actions.disable'))
                            ->icon('tabler-player-pause')
                            ->requiresConfirmation()
                            ->action(fn (array $record) => $this->attempt(static::t('notify.disabled', ['name' => $record['name'] ?: $record['modid']]), fn () => $this->mods()->setDisabled((string) $record['modid'], true))),
                        static::t('actions.disable'),
                        fn () => false
                    )->visible(fn (array $record) => $this->canMutate() && !empty($record['modid']) && ($record['verified'] ?? false) && !($record['disabled'] ?? false)),
                    $this->guarded(
                        Action::make('enable')
                            ->label(static::t('actions.enable'))
                            ->icon('tabler-player-play')
                            ->action(fn (array $record) => $this->attempt(static::t('notify.enabled', ['name' => $record['name'] ?: $record['modid']]), fn () => $this->mods()->setDisabled((string) $record['modid'], false))),
                        static::t('actions.enable'),
                        fn () => false
                    )->visible(fn (array $record) => $this->canMutate() && !empty($record['modid']) && ($record['disabled'] ?? false)),
                    // Pin/unpin only edits the plugin's manifest, so it works while the server runs.
                    Action::make('pin')
                        ->label(static::t('actions.pin'))
                        ->icon('tabler-pin')
                        ->visible(fn (array $record) => $this->can(SubuserPermission::FileUpdate) && !empty($record['modid']) && !($record['pinned'] ?? false))
                        ->action(fn (array $record) => $this->setPinned($record, true)),
                    Action::make('unpin')
                        ->label(static::t('actions.unpin'))
                        ->icon('tabler-pin-filled')
                        ->visible(fn (array $record) => $this->can(SubuserPermission::FileUpdate) && !empty($record['modid']) && ($record['pinned'] ?? false))
                        ->action(fn (array $record) => $this->setPinned($record, false)),
                    $this->guarded(
                        Action::make('rollback')
                            ->label(static::t('actions.rollback'))
                            ->icon('tabler-arrow-back-up')
                            ->requiresConfirmation()
                            ->modalDescription(static::t('actions.rollback_body'))
                            ->action(fn (array $record) => $this->attempt(static::t('notify.rolled_back', ['name' => $record['name'] ?: $record['modid']]), fn () => $this->mods()->rollback((string) $record['modid']))),
                        static::t('actions.rollback'),
                        fn () => false
                    )->visible(fn (array $record) => $this->canMutate() && !empty($record['modid'])
                        && in_array(strtolower((string) $record['modid']), $this->backupIds(), true)),
                    Action::make('open_moddb')
                        ->label(static::t('actions.open_moddb'))
                        ->icon('tabler-external-link')
                        ->visible(fn (array $record) => !empty($record['moddb']['moddbid'])
                            || in_array($record['moddbStatus'] ?? '', ['up_to_date', 'update', 'version_not_on_moddb'], true))
                        ->url(fn (array $record) => $this->moddbPageFor($record), true),
                    $this->guarded(
                        Action::make('remove')
                            ->label(static::t('actions.remove'))
                            ->icon('tabler-trash')
                            ->color('danger')
                            ->requiresConfirmation()
                            ->modalHeading(fn (array $record) => static::t('actions.remove_heading', ['name' => $record['name'] ?: $record['filename']]))
                            ->schema([
                                Toggle::make('keep_backup')->label(static::t('actions.keep_backup'))->default(true),
                            ])
                            ->action(fn (array $data, array $record) => $this->attempt(
                                static::t('notify.removed', ['name' => $record['name'] ?: $record['filename']]),
                                fn () => $this->mods()->remove($record, (bool) ($data['keep_backup'] ?? true))
                            )),
                        static::t('actions.remove'),
                        fn () => true
                    ),
                ]),
            ])
            ->toolbarActions([
                BulkActionGroup::make([
                    $this->guarded(
                        BulkAction::make('bulk_disable')
                            ->label(static::t('actions.disable_selected'))
                            ->icon('tabler-player-pause')
                            ->requiresConfirmation()
                            ->deselectRecordsAfterCompletion()
                            ->action(fn (Collection $records) => $this->bulk($records, static::t('notify.bulk_disabled'), fn (array $r) => $this->mods()->setDisabled((string) $r['modid'], true), true)),
                        static::t('actions.disable_selected'),
                        fn () => true
                    ),
                    $this->guarded(
                        BulkAction::make('bulk_enable')
                            ->label(static::t('actions.enable_selected'))
                            ->icon('tabler-player-play')
                            ->deselectRecordsAfterCompletion()
                            ->action(fn (Collection $records) => $this->bulk($records, static::t('notify.bulk_enabled'), fn (array $r) => $this->mods()->setDisabled((string) $r['modid'], false), true)),
                        static::t('actions.enable_selected'),
                        fn () => true
                    ),
                    $this->guarded(
                        BulkAction::make('bulk_remove')
                            ->label(static::t('actions.remove_selected'))
                            ->icon('tabler-trash')
                            ->color('danger')
                            ->requiresConfirmation()
                            ->modalDescription(static::t('actions.remove_selected_body'))
                            ->deselectRecordsAfterCompletion()
                            ->action(fn (Collection $records) => $this->bulk($records, static::t('notify.bulk_removed'), fn (array $r) => $this->mods()->remove($r, true), false)),
                        static::t('actions.remove_selected'),
                        fn () => true
                    ),
                ]),
            ]);
    }

    /**
     * ModDB lookup key for an installed row: the mod id string (what /api/mod/{x} accepts), else the numeric
     * ModDB mod id from the manifest. Never the asset id: /api/mod/{assetid} is a different (or no) mod.
     */
    protected function moddbKey(array $record): string|int|null
    {
        return ($record['modid'] ?? null) ?: ($record['moddb']['moddbid'] ?? null);
    }

    protected function moddbPageFor(array $record): ?string
    {
        if (!empty($record['moddb']['moddbid'])) {
            return $this->moddb()->modPageUrl(['modid' => (int) $record['moddb']['moddbid']]);
        }
        $mod = ($key = $this->moddbKey($record)) !== null ? $this->loadMod($key) : null;

        return $mod ? $this->moddb()->modPageUrl($mod) : null;
    }

    protected function warningLabel(string $warning): string
    {
        [$type, $arg] = array_pad(explode(':', $warning, 2), 2, '');
        $key = 'warning.' . $type;
        $label = static::t($key, ['arg' => $arg]);

        return $label === 'vs-mod-manager::strings.' . $key ? $warning : $label;
    }

    protected function setPinned(array $record, bool $pinned): void
    {
        if (!$this->can(SubuserPermission::FileUpdate)) {
            return;
        }

        try {
            $this->mods()->setPinned((string) $record['modid'], $pinned);
            $this->forgetState();
            Notification::make()->title(static::t($pinned ? 'notify.pinned' : 'notify.unpinned', ['name' => $record['name'] ?: $record['modid']]))->success()->send();
        } catch (Throwable $e) {
            report($e);
            Notification::make()->title(static::t('notify.failed'))->body($e instanceof ModManagerException ? $e->getMessage() : static::t('notify.failed_unexpected'))->danger()->send();
        }
    }

    /**
     * Run one change per selected row, then report a single summary.
     *
     * @param  Collection<int|string, array<string, mixed>>  $records
     */
    protected function bulk(Collection $records, string $title, \Closure $each, bool $needsModid): void
    {
        if (!$this->denyUnlessCanMutate()) {
            return;
        }
        $ok = 0;
        $failed = [];

        foreach ($records as $record) {
            if ($needsModid && (empty($record['modid']) || !($record['verified'] ?? false))) {
                $failed[] = ($record['filename'] ?? '?') . ': ' . static::t('installed.no_modid');

                continue;
            }

            try {
                $each($record);
                $ok++;
            } catch (ModManagerException $e) {
                $failed[] = ($record['filename'] ?? '?') . ': ' . $e->getMessage();
                if ($e instanceof \Ehaic\VsModManager\Exceptions\ServerNotStoppedException) {
                    break;
                }
            } catch (Throwable $e) {
                report($e);
                $failed[] = ($record['filename'] ?? '?') . ': ' . static::t('notify.failed_unexpected');
            }
        }

        $this->summary($title, $ok, $failed);
    }

    protected function updateAll(): void
    {
        if (!$this->denyUnlessCanMutate()) {
            return;
        }
        $ok = 0;
        $skipped = 0;
        $failed = [];

        foreach ($this->installedAnnotated() as $row) {
            if (($row['moddbStatus'] ?? '') !== 'update' || empty($row['latest'])) {
                continue;
            }

            if ($row['pinned'] ?? false) {
                $skipped++;

                continue;
            }

            try {
                $this->mods()->update($row, $row['latest']);
                $ok++;
            } catch (ModManagerException $e) {
                $failed[] = ($row['name'] ?: $row['filename']) . ': ' . $e->getMessage();
                if ($e instanceof \Ehaic\VsModManager\Exceptions\ServerNotStoppedException) {
                    break;
                }
            } catch (Throwable $e) {
                report($e);
                $failed[] = ($row['name'] ?: $row['filename']) . ': ' . static::t('notify.failed_unexpected');
            }
        }

        if ($skipped > 0) {
            $failed[] = static::t('notify.skipped_pinned', ['count' => $skipped]);
        }

        $this->summary(static::t('notify.update_all_done'), $ok, $failed, $ok === 0 && $skipped === 0 && $failed === []);
    }

    /** One notification for a batch: green when all worked, orange with the problems otherwise. */
    protected function summary(string $title, int $ok, array $problems, bool $nothingToDo = false): void
    {
        $this->forgetState();

        if ($ok > 0) {
            // The annotate cache key follows the file list, so it needs no explicit forget here.
            $this->changed = true;
        }

        $notification = Notification::make()->title($nothingToDo ? static::t('notify.nothing_to_do') : $title)
            ->body(static::lines([$ok > 0 ? static::t('notify.count_done', ['count' => $ok]) : null, ...$problems]));

        match (true) {
            $problems === [] && !$nothingToDo => $notification->success(),
            $ok > 0 => $notification->warning(),
            $nothingToDo => $notification->info(),
            default => $notification->danger(),
        };

        $notification->send();
    }

    // ---- Modpack ----------------------------------------------------------------------------------

    protected function exportText(): string
    {
        try {
            // Annotated rows know which modinfo-identified mods are on the ModDB (installedList() only knows the manifest).
            return app(ModpackService::class)->export($this->installedAnnotated());
        } catch (Throwable $e) {
            report($e);

            return '';
        }
    }

    protected function importCacheKey(): string
    {
        return 'vsmm:import:' . $this->server()->id . ':' . (user()?->id ?? 0) . ':' . $this->importToken;
    }

    /** @return array<int, array<string, mixed>> */
    protected function importRows(): array
    {
        return $this->importToken ? (array) Cache::get($this->importCacheKey(), []) : [];
    }

    protected function previewImport(string $text): void
    {
        if (!$this->denyUnlessCanMutate()) {
            return;
        }

        try {
            $parsed = ModpackService::parse($text);

            if ($parsed === []) {
                Notification::make()->title(static::t('modpack.empty'))->warning()->send();

                return;
            }

            $rows = app(ModpackService::class)->preview($this->server(), $parsed, $this->installedList(), $this->gameVersion());
            if ($this->moddb()->hadFailure()) {
                Notification::make()->title(static::t('moddb_down.title'))->body(static::t('moddb_down.preview'))->warning()->send();
            }

            $this->importToken = bin2hex(random_bytes(8));
            Cache::put($this->importCacheKey(), array_values($rows), now()->addMinutes(30));
            $this->flushCachedTableRecords();
        } catch (ModManagerException $e) {
            Notification::make()->title(static::t('notify.failed'))->body($e->getMessage())->danger()->send();
        } catch (Throwable $e) {
            report($e);
            Notification::make()->title(static::t('notify.failed'))->body(static::t('notify.failed_unexpected'))->danger()->send();
        }
    }

    protected function applyImport(): void
    {
        if (!$this->denyUnlessCanMutate()) {
            return;
        }
        $rows = array_values(array_filter($this->importRows(), static fn (array $r) => in_array($r['action'] ?? '', ['install', 'update'], true)));

        if ($rows === []) {
            Notification::make()->title(static::t('notify.nothing_to_do'))->info()->send();

            return;
        }

        try {
            $results = app(ModpackService::class)->apply($this->server(), $rows);
        } catch (ModManagerException $e) {
            $this->forgetState();
            Notification::make()->title(static::t('notify.failed'))->body($e->getMessage())->danger()->send();

            return;
        } catch (Throwable $e) {
            report($e);
            $this->forgetState();
            Notification::make()->title(static::t('notify.failed'))->body(static::t('notify.failed_unexpected'))->danger()->send();

            return;
        }

        // Per-row result shape is not fixed by the contract: accept ['ok'=>bool,'error'=>?,'message'=>?] or a plain string.
        $ok = 0;
        $problems = [];
        foreach ($results as $key => $result) {
            $failed = is_array($result) && (isset($result['error']) || ($result['ok'] ?? true) === false || ($result['success'] ?? true) === false);
            $name = is_array($result) ? (string) ($result['modid'] ?? $key) : (string) $key;

            if ($failed) {
                $problems[] = $name . ': ' . ($result['error'] ?? $result['message'] ?? '?');
            } else {
                $ok++;
            }
        }

        $this->importToken = null;
        $this->summary(static::t('modpack.applied'), $ok, $problems);
    }

    protected function modpackTable(Table $table): Table
    {
        return $table
            ->records(fn () => collect($this->importRows())->mapWithKeys(fn (array $row) => [(string) $row['modid'] => $row])->all())
            ->paginated(false)
            ->heading(static::t('modpack.preview_heading'))
            ->emptyStateHeading(static::t('modpack.preview_empty'))
            ->emptyStateDescription(static::t('modpack.preview_empty_body'))
            ->columns([
                TextColumn::make('modid')->label(static::t('col.modid')),
                TextColumn::make('action')
                    ->label(static::t('col.action'))
                    ->badge()
                    ->color(fn ($state) => match ($state) {
                        'install' => 'success',
                        'update' => 'warning',
                        'same' => 'gray',
                        default => 'danger',
                    })
                    ->formatStateUsing(fn ($state, array $record) => $state === 'update' && isset($record['from'], $record['to'])
                        && Version::compare((string) $record['to'], (string) $record['from']) < 0
                            ? static::t('preview.downgrade') : static::t('preview.' . $state)),
                TextColumn::make('from')->label(static::t('col.from'))->placeholder('—'),
                TextColumn::make('to')->label(static::t('col.to'))->placeholder('—'),
            ]);
    }
}
