<?php

declare(strict_types=1);

namespace Ehaic\VsModManager\Support;

use Closure;

/**
 * Short-lived read cache for what the page reads from a server through Wings (serverconfig.json, the plugin
 * manifest, the mods folder listing). Without it every Livewire request (tab switch, search, page, poll render)
 * repeated the same ~6 Wings round trips.
 *
 * - Per server, never per user: the data is the same for everyone who may see the page (the page's own
 *   permission checks run before anything is read).
 * - Only the READ path uses it. Anything that changes files, takes the lock or checks "is it safe to write"
 *   reads fresh, and every write calls forget().
 * - forget() bumps a per-server generation number that is part of every key, so one call drops all entries.
 * - Failures (exceptions) are never cached.
 */
final class Snapshot
{
    public const TTL = 15;

    public function __construct(private readonly object $store)
    {
    }

    /**
     * @param  Closure(): mixed  $read
     */
    public function remember(string $server, string $what, Closure $read, int $ttl = self::TTL): mixed
    {
        $key = 'vsmm.snap.' . $server . '.' . $this->generation($server) . '.' . $what;
        $hit = $this->store->get($key);
        if (is_array($hit) && array_key_exists('v', $hit)) {
            return $hit['v'];
        }

        $value = $read();
        $this->store->put($key, ['v' => $value], $ttl);

        return $value;
    }

    /** Drop everything remembered for this server (call after any write, server state change or explicit refresh). */
    public function forget(string $server): void
    {
        $this->store->put('vsmm.snap.' . $server . '.gen', bin2hex(random_bytes(4)), 86400);
    }

    private function generation(string $server): string
    {
        return (string) ($this->store->get('vsmm.snap.' . $server . '.gen') ?? '0');
    }
}
