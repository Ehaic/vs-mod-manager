<?php

declare(strict_types=1);

namespace Ehaic\VsModManager\Support;

use Closure;

/**
 * Stale-while-revalidate cache over any Laravel-style store (get/put/add/forget).
 *
 * An entry has a SOFT expiry (how long it counts as fresh) and lives much longer (HARD_TTL). Within the soft
 * window it is returned as is. After it, the stale value is still returned at once and a refresh is queued to
 * run after the response was sent (the `$defer` callback; production passes app()->terminating()), so a
 * visitor never waits for the ModDB just because a cache entry aged. Only a completely cold key computes inline.
 *
 * - A compute that returns null (= the ModDB failed) never overwrites anything; a stale entry then stays
 *   usable and is retried after RETRY_AFTER seconds, so an outage costs no extra requests per page view.
 * - Empty results ([] or '') are only trusted for EMPTY_SOFT seconds.
 * - A tiny companion key (`<key>:f`, the soft expiry) answers "is this cached / fresh?" without unserialising
 *   a multi-megabyte value (the catalogue is ~5 MB).
 * - The store is plain `cache()`: every entry is global (ModDB data, no per-user or per-server content).
 */
final class SwrCache
{
    public const HARD_TTL = 7 * 86400;
    public const RETRY_AFTER = 60;
    public const EMPTY_SOFT = 300;
    private const LOCK_TTL = 180;

    /** @param Closure(Closure): void $defer runs the given refresh after the response was sent */
    public function __construct(
        private readonly object $store,
        private readonly Closure $defer,
        private readonly ?Closure $clock = null,
    ) {
    }

    /**
     * @param  Closure(): mixed  $compute  null = failed
     */
    public function get(string $key, int $softTtl, Closure $compute, mixed $onFailure = null): mixed
    {
        $entry = $this->store->get($key);
        if (is_array($entry) && array_key_exists('v', $entry)) {
            if ((int) ($entry['f'] ?? 0) <= $this->now()) {
                $this->refreshLater($key, $softTtl, $compute);
            }

            return $entry['v'];
        }

        $value = $compute();
        if ($value === null) {
            return $onFailure;
        }
        $this->put($key, $value, $softTtl);

        return $value;
    }

    /** The cached value (fresh or stale) without ever computing or refreshing; null when there is none. */
    public function peek(string $key): mixed
    {
        $entry = $this->store->get($key);

        return is_array($entry) && array_key_exists('v', $entry) ? $entry['v'] : null;
    }

    public function put(string $key, mixed $value, int $softTtl): void
    {
        $soft = $value === [] || $value === '' ? min($softTtl, self::EMPTY_SOFT) : $softTtl;
        $this->write($key, $value, $this->now() + $soft);
    }

    /** Something (fresh or stale) is cached. Reads only the tiny companion key. */
    public function has(string $key): bool
    {
        return $this->store->get($key . ':f') !== null;
    }

    public function isFresh(string $key): bool
    {
        return (int) ($this->store->get($key . ':f') ?? 0) > $this->now();
    }

    public function forget(string $key): void
    {
        $this->store->forget($key);
        $this->store->forget($key . ':f');
    }

    /** Make a stale/fresh entry stale so the next read refreshes it (the value stays usable meanwhile). */
    public function expire(string $key): void
    {
        $entry = $this->store->get($key);
        if (is_array($entry) && array_key_exists('v', $entry)) {
            $this->write($key, $entry['v'], 0);
        }
    }

    /** If this key is cached but stale, queue its refresh (after the response) without reading the value. */
    public function refreshIfStale(string $key, int $softTtl, Closure $compute): void
    {
        if ($this->has($key) && ! $this->isFresh($key)) {
            $this->refreshLater($key, $softTtl, $compute);
        }
    }

    /** Take the "someone is refreshing this key" lock (for batch refreshes). False if another refresh holds it. */
    public function claim(string $key): bool
    {
        return (bool) $this->store->add($key . ':lock', 1, self::LOCK_TTL);
    }

    public function release(string $key): void
    {
        $this->store->forget($key . ':lock');
    }

    /** A refresh of this key failed: keep the stale value, ask again in RETRY_AFTER seconds. */
    public function backoff(string $key): void
    {
        $this->retryLater($key);
    }

    private function refreshLater(string $key, int $softTtl, Closure $compute): void
    {
        // One refresh at a time across all requests.
        if (! $this->store->add($key . ':lock', 1, self::LOCK_TTL)) {
            return;
        }
        ($this->defer)(function () use ($key, $softTtl, $compute): void {
            try {
                $value = $compute();
                if ($value === null) {
                    $this->retryLater($key);
                } else {
                    $this->put($key, $value, $softTtl);
                }
            } catch (\Throwable) {
                $this->retryLater($key);
            } finally {
                $this->store->forget($key . ':lock');
            }
        });
    }

    /** Keep the stale value, but don't try again for a minute. */
    private function retryLater(string $key): void
    {
        $entry = $this->store->get($key);
        if (is_array($entry) && array_key_exists('v', $entry)) {
            $this->write($key, $entry['v'], $this->now() + self::RETRY_AFTER);
        }
    }

    private function write(string $key, mixed $value, int $freshUntil): void
    {
        $this->store->put($key, ['v' => $value, 'f' => $freshUntil], self::HARD_TTL);
        $this->store->put($key . ':f', $freshUntil, self::HARD_TTL);
    }

    private function now(): int
    {
        return $this->clock !== null ? (int) ($this->clock)() : time();
    }
}
