<?php

declare(strict_types=1);

namespace Ehaic\VsModManager\Services;

use App\Facades\Activity;
use App\Models\Server;
use App\Repositories\Daemon\DaemonFileRepository;
use App\Repositories\Daemon\DaemonServerRepository;
use Closure;
use Ehaic\VsModManager\Exceptions\ModManagerException;
use Ehaic\VsModManager\Exceptions\ServerNotStoppedException;
use Ehaic\VsModManager\Support\ModInfoReader;
use Ehaic\VsModManager\Support\Snapshot;
use Ehaic\VsModManager\Support\Trace;
use Ehaic\VsModManager\Support\Version;
use Illuminate\Contracts\Filesystem\FileNotFoundException;
use Illuminate\Http\Client\ConnectionException;
use Illuminate\Http\Client\RequestException;
use Illuminate\Support\Facades\Cache;

/**
 * Everything that touches a server's mod files through Wings.
 *
 * Layout on the server (paths relative to the server root):
 *   data/Mods/                                   the mods folder (from serverconfig ModPaths; never the top-level Mods/)
 *   data/.vs-mod-manager/manifest.json           our state (outside the mods folder: the game loads every folder in it)
 *   data/.vs-mod-manager/backups/<modid>/<stamp>__<filename>
 *
 * Every mutation: assertStopped (fresh state from Wings), per-server lock, Activity log entry.
 */
class ServerModsService
{
    public const STATE_DIR = 'data/.vs-mod-manager';
    public const MANIFEST_PATH = self::STATE_DIR . '/manifest.json';
    public const BACKUP_DIR = self::STATE_DIR . '/backups';

    /** Biggest zip we'll pull through the panel to read modinfo.json. */
    private const MAX_READ_BYTES = 30 * 1024 * 1024;
    private const MAX_LOG_BYTES = 8 * 1024 * 1024;
    /** Wall-clock seconds one request may spend reading unknown mod files through Wings; the rest is picked up on the next load. */
    private const IDENTIFY_BUDGET_SECONDS = 40;

    private ?Server $server = null;
    private ?string $modsDir = null;
    /** @var array<string, true> directories we already created/checked during this request */
    private array $ensured = [];
    /** @var array<string, string> backup stored-name => modid, for undoing moves within one request */
    private array $storedModid = [];
    private ?float $identifyDeadline = null;
    /** modsDir() worked out from the short-lived serverconfig snapshot: only for listing, never reused by a write. */
    private ?string $modsDirCached = null;

    public function forServer(Server $server): static
    {
        $new = clone $this;
        $new->server = $server;
        $new->modsDir = null;
        $new->modsDirCached = null;
        $new->ensured = [];
        $new->identifyDeadline = null;

        return $new;
    }

    // ------------------------------------------------------------------ state

    /** Fresh server state from Wings (never cached): running|starting|stopping|offline, or "missing" if unreachable. */
    public function state(): string
    {
        // getDetails() returns state "missing" when Wings can't be reached, which counts as not stopped.
        $details = app(DaemonServerRepository::class)->setServer($this->server())->getDetails(5);

        return (string) ($details['state'] ?? 'missing');
    }

    public function isStopped(): bool
    {
        return $this->state() === 'offline';
    }

    public function assertStopped(): void
    {
        // Suspended, installing, restoring a backup, transferring: Wings may still say "offline", but files must not change.
        $fresh = $this->server()->fresh();
        if ($fresh === null || $fresh->isInConflictState()) {
            throw new ModManagerException('The server is suspended, installing, restoring a backup or being transferred. Try again later.');
        }

        $state = $this->state();
        if ($state !== 'offline') {
            throw new ServerNotStoppedException($state);
        }
    }

    // ------------------------------------------------------------------ paths

    /**
     * The folder user mods live in: the first ModPaths entry that is a "Mods" folder outside the game's own
     * top-level Mods/. Without a serverconfig.json yet (server never started) the egg's default data/Mods is used.
     */
    public function modsDir(bool $cached = false): string
    {
        if ($cached && $this->modsDirCached !== null) {
            return $this->modsDirCached;
        }
        if (! $cached && $this->modsDir !== null) {
            return $this->modsDir;
        }

        $dir = $this->resolveModsDir($cached);

        return $cached ? $this->modsDirCached = $dir : $this->modsDir = $dir;
    }

    private function resolveModsDir(bool $cached): string
    {
        $paths = app(ServerConfigEditor::class)->forServer($this->server())->modPaths(cached: $cached);
        if ($paths === []) {
            return 'data/Mods';
        }

        foreach ($paths as $path) {
            $norm = $this->normalisePath($path);
            if ($norm !== null && self::isUserModsPath($norm)) {
                return $norm;
            }
        }

        throw new ModManagerException("serverconfig.json ModPaths has no mods folder besides the game's own Mods/. Add \"./data/Mods\" to ModPaths.");
    }

    /**
     * A normalised ModPaths entry we may manage: its last segment is "Mods" (so we never treat a whole data
     * folder as the mods folder) and it isn't the game's own top-level Mods/ or anything inside it. Pure.
     */
    public static function isUserModsPath(string $norm): bool
    {
        $parts = explode('/', strtolower($norm));

        return count($parts) >= 2 && $parts[0] !== 'mods' && end($parts) === 'mods';
    }

    /** "./data/Mods" → "data/Mods"; null if the path is absolute outside the server root or tries to escape it. */
    private function normalisePath(string $path): ?string
    {
        $p = str_replace('\\', '/', trim($path));
        if (str_starts_with($p, '/home/container/')) {
            $p = substr($p, strlen('/home/container/'));
        }
        $parts = array_values(array_filter(explode('/', $p), fn ($s) => $s !== '' && $s !== '.'));
        if ($parts === [] || str_starts_with($p, '/') || in_array('..', $parts, true)) {
            return null;
        }

        return implode('/', $parts);
    }

    // ------------------------------------------------------------------ listing

    /**
     * Every top-level entry of the mods folder, identified.
     *
     * @return array<int, array<string, mixed>>
     */
    public function list(): array
    {
        // Read path: Wings answers are reused for a few seconds (Snapshot); every write forgets them.
        $dir = $this->modsDir(cached: true);
        $entries = $this->dirEntries($dir, cached: true);
        $manifest = $this->manifest(cached: true);

        try {
            $disabled = app(ServerConfigEditor::class)->forServer($this->server())->disabledMods(cached: true);
        } catch (ModManagerException) {
            $disabled = [];
        }

        $rows = [];
        foreach ($entries as $entry) {
            $name = (string) ($entry['name'] ?? '');
            // Our own temporary download (see performInstall) is not a mod.
            if ($name === '' || str_ends_with($name, '.vsmm-part')) {
                continue;
            }

            $isDir = (bool) ($entry['directory'] ?? false);
            $ext = strtolower(pathinfo($name, PATHINFO_EXTENSION));
            $kind = $isDir ? 'folder' : (in_array($ext, ['zip', 'dll', 'cs'], true) ? $ext : 'ignored');
            $size = (int) ($entry['size'] ?? 0);
            $modified = (string) ($entry['modified'] ?? '');

            $row = [
                'filename' => $name, 'kind' => $kind, 'size' => $size, 'modified' => $modified,
                'modid' => null, 'name' => null, 'version' => null, 'side' => null, 'type' => null,
                'dependencies' => [], 'requiredOnClient' => null, 'gameMin' => null,
                'source' => 'filename', 'verified' => false,
                'moddb' => null, 'disabled' => false, 'pinned' => false,
            ];

            if ($kind !== 'ignored') {
                $info = null;
                $m = $manifest['mods'][$name] ?? null;
                if (is_array($m) && !empty($m['modid']) && ($kind === 'folder' || (int) ($m['size'] ?? -1) === $size)) {
                    $row['source'] = 'manifest';
                    $row['verified'] = true;
                    $info = $m;
                    $row['moddb'] = isset($m['assetid']) || isset($m['moddbid']) ? [
                        'assetid' => $m['assetid'] ?? null, 'moddbid' => $m['moddbid'] ?? null,
                        'releaseid' => $m['releaseid'] ?? null, 'fileid' => $m['fileid'] ?? null,
                    ] : null;
                } else {
                    [$info, $source] = $this->identify($dir, $name, $kind, $size, $modified);
                    $row['source'] = $source;
                    $row['verified'] = $source === 'modinfo';
                }

                foreach (['modid', 'name', 'version', 'side', 'type', 'requiredOnClient', 'gameMin'] as $k) {
                    $row[$k] = $info[$k] ?? null;
                }
                $row['dependencies'] = is_array($info['dependencies'] ?? null) ? $info['dependencies'] : [];
            }

            if ($row['modid'] !== null) {
                $id = (string) $row['modid'];
                $row['disabled'] = in_array($id, $disabled, true)
                    || ($row['version'] !== null && in_array($id . '@' . $row['version'], $disabled, true));
                $row['pinned'] = in_array($id, $manifest['pinned'], true);
            }

            $rows[] = $row;
        }

        usort($rows, fn ($a, $b) => strcasecmp((string) ($a['name'] ?? $a['filename']), (string) ($b['name'] ?? $b['filename'])));

        return $rows;
    }

    /** @return array{0: ?array<string, mixed>, 1: string} [info, 'modinfo'|'filename'] */
    private function identify(string $dir, string $name, string $kind, int $size, string $modified): array
    {
        $guess = fn () => [ModInfoReader::guessFromFilename($name), 'filename'];
        if ($kind === 'dll') {
            return $guess();
        }

        $key = 'vsmm.info.' . $this->server()->uuid . '.' . md5("$dir/$name") . ".$size.$modified";
        if (!Cache::has($key)) {
            // Cold cache: every unknown file is a download through the panel. Don't let one page load take minutes.
            $this->identifyDeadline ??= microtime(true) + self::IDENTIFY_BUDGET_SECONDS;
            if (microtime(true) > $this->identifyDeadline) {
                return $guess();
            }
        }
        try {
            // false (not null) is cached for "no readable modinfo", so such a file isn't downloaded again on every page load.
            $info = Cache::remember($key, now()->addDay(), function () use ($dir, $name, $kind, $size) {
                $repo = $this->files();
                if ($kind === 'zip') {
                    if ($size > self::MAX_READ_BYTES) {
                        return false;
                    }

                    return ModInfoReader::fromZipBytes((string) $repo->getContent("/$dir/$name", self::MAX_READ_BYTES)) ?? false;
                }
                if ($kind === 'folder') {
                    $json = (string) $repo->getContent("/$dir/$name/modinfo.json", 1024 * 1024);

                    return ModInfoReader::fromJson($json) ?? false;
                }

                return ModInfoReader::fromCsSource((string) $repo->getContent("/$dir/$name", 1024 * 1024)) ?? false;
            });
        } catch (\Throwable $e) {
            // One unreadable file must not break the whole list.
            report($e);
            $info = null;
        }

        return is_array($info) && !empty($info['modid']) ? [$info, 'modinfo'] : $guess();
    }

    // ------------------------------------------------------------------ manifest

    /** @return array{version: int, game_version_override: ?string, pinned: string[], mods: array<string, array<string, mixed>>} */
    public function manifest(bool $cached = false): array
    {
        $raw = $cached
            ? app(Snapshot::class)->remember((string) $this->server()->uuid, 'manifest', fn () => $this->manifestRaw())
            : $this->manifestRaw();
        $data = json_decode($raw, true);
        $data = is_array($data) ? $data : [];

        return [
            'version' => 1,
            'game_version_override' => is_string($data['game_version_override'] ?? null) ? $data['game_version_override'] : null,
            'pinned' => array_values(array_filter((array) ($data['pinned'] ?? []), 'is_string')),
            'mods' => is_array($data['mods'] ?? null) ? $data['mods'] : [],
        ];
    }

    private function manifestRaw(): string
    {
        try {
            return (string) $this->files()->getContent('/' . self::MANIFEST_PATH, 5 * 1024 * 1024);
        } catch (FileNotFoundException) {
            return '';
        } catch (RequestException $e) {
            if ($e->response->status() !== 404) {
                throw $e;
            }

            return '';
        }
    }

    /** Read-modify-write the manifest under a short lock. */
    private function mutateManifest(Closure $change): void
    {
        Cache::lock('vsmm.manifest.' . $this->server()->id, 15)->block(10, function () use ($change) {
            $raw = $this->manifestRaw();
            if (trim($raw) !== '' && !is_array(json_decode($raw, true))) {
                // Unreadable manifest (half-written, edited by hand): keep it instead of silently overwriting it.
                $this->ensureDir(self::STATE_DIR);
                $this->files()->putContent('/' . self::STATE_DIR . '/manifest.corrupt.json', $raw);
            }
            $m = $this->manifest();
            $change($m);
            $m['pinned'] = array_values(array_unique($m['pinned']));
            sort($m['pinned']);
            $this->ensureDir(self::STATE_DIR);
            $this->files()->putContent('/' . self::MANIFEST_PATH, json_encode(
                $m,
                JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR,
            ));
            $this->forgetSnapshot();
        });
    }

    // ------------------------------------------------------------------ mutations

    /** Download a release into the mods folder. An older file of the same modid goes to backups. */
    public function install(array $mod, array $release): array
    {
        $ids = [
            'assetid' => isset($mod['assetid']) ? (int) $mod['assetid'] : null,
            // ModDbClient::mod()['modid'] is the numeric ModDB mod id (not the modinfo modid).
            'moddbid' => isset($mod['modid']) && is_numeric($mod['modid']) ? (int) $mod['modid'] : null,
        ];

        return $this->performInstall('install', $ids, $release);
    }

    /** Same as install(); the installed file is replaced and kept in backups. */
    public function update(array $installed, array $release): array
    {
        $ids = [
            'assetid' => isset($installed['moddb']['assetid']) ? (int) $installed['moddb']['assetid'] : null,
            'moddbid' => isset($installed['moddb']['moddbid']) ? (int) $installed['moddb']['moddbid'] : null,
        ];

        return $this->performInstall('update', $ids, $release, $installed);
    }

    public function remove(array $installed, bool $keepBackup = true): array
    {
        $filename = $this->safeFilename((string) ($installed['filename'] ?? ''));
        $modid = $installed['modid'] ?? null;
        $label = (string) ($installed['name'] ?? $modid ?? $filename);

        return $this->mutate('remove', ['mod' => $label, 'file' => $filename, 'backup' => $keepBackup], function () use ($installed, $filename, $modid, $keepBackup, $label) {
            $dir = $this->modsDir();
            $this->requireExists($dir, $filename);

            $backupId = $modid !== null && self::isValidModid((string) $modid) ? (string) $modid : self::fileBackupId($filename);
            if ($keepBackup) {
                $this->moveToBackup($dir, $backupId, $filename);
            } else {
                $this->files()->deleteFiles('/', ["/$dir/$filename"]);
            }

            $this->mutateManifest(function (array &$m) use ($filename) {
                unset($m['mods'][$filename]);
            });
            if ($modid !== null && $this->rowsFor((string) $modid) === []) {
                // A removed mod shouldn't linger in the game's disabled list (unless another copy is still installed).
                // The file is already gone at this point, so a config problem must not turn the removal into a failure.
                try {
                    $editor = app(ServerConfigEditor::class)->forServer($this->server());
                    $listed = array_filter($editor->disabledMods(), fn ($e) => $e === $modid || str_starts_with($e, $modid . '@'));
                    if ($listed !== []) {
                        $editor->setDisabled((string) $modid, false);
                    }
                } catch (\Throwable $e) {
                    report($e);
                }
            }
            $this->pruneBackups($backupId);

            return ['message' => $keepBackup ? "Removed {$label} (a copy is kept for rollback)." : "Removed {$label}.", 'modid' => $modid, 'filename' => $filename];
        });
    }

    public function setDisabled(string $modid, bool $disabled): array
    {
        $modid = $this->safeModid($modid);

        return $this->mutate($disabled ? 'disable' : 'enable', ['mod' => $modid], function () use ($modid, $disabled) {
            app(ServerConfigEditor::class)->forServer($this->server())->setDisabled($modid, $disabled);

            return ['message' => ($disabled ? 'Disabled ' : 'Enabled ') . $modid . '.', 'modid' => $modid];
        });
    }

    /** Restore the newest backup of a mod; the file currently installed goes to backups. */
    public function rollback(string $modid): array
    {
        $modid = $this->safeModid($modid);

        return $this->mutate('rollback', ['mod' => $modid], function () use ($modid) {
            $dir = $this->modsDir();
            $backups = $this->backups($modid);
            if ($backups === []) {
                throw new ModManagerException("There is no backup of {$modid} to roll back to.");
            }
            $target = $backups[0];
            $filename = $this->safeFilename($target['filename']);

            $current = $this->rowsFor($modid, $filename);
            $moved = [];
            try {
                foreach ($current as $row) {
                    $moved[] = [$row['filename'], $this->moveToBackup($dir, $modid, $row['filename'])];
                }
                $this->requireAbsent($dir, $filename);
                $this->files()->renameFiles('/', [['from' => '/' . $this->backupDir($modid) . '/' . $target['name'], 'to' => "/$dir/$filename"]]);
            } catch (\Throwable $e) {
                $this->restoreMoved($dir, $moved);
                throw $e;
            }

            $this->mutateManifest(function (array &$m) use ($current) {
                foreach ($current as $row) {
                    unset($m['mods'][$row['filename']]);
                }
            });
            $this->pruneBackups($modid);

            return ['message' => "Rolled {$modid} back to {$filename}.", 'modid' => $modid, 'filename' => $filename];
        });
    }

    /**
     * Backups of a mod, newest first.
     *
     * @return array<int, array{name: string, filename: string, created: string, size: int}>
     */
    public function backups(string $modid): array
    {
        $out = [];
        foreach ($this->dirEntries($this->backupDir($modid)) as $e) {
            if (preg_match('/^(\d{8}T\d{6}(?:\d{6})?Z)-[0-9a-f]{4}__(.+)$/', (string) $e['name'], $m)) {
                $out[] = ['name' => $e['name'], 'filename' => $m[2], 'created' => $m[1], 'size' => (int) ($e['size'] ?? 0)];
            }
        }
        usort($out, fn ($a, $b) => strcmp($b['name'], $a['name']));

        return $out;
    }

    /**
     * Mod ids (lower-case backup folder names) that have at least one backup. File-only backups of
     * unidentified files ("file-…") are left out: they can't be rolled back by mod id.
     *
     * @return array<int, string>
     */
    public function backupModids(): array
    {
        $out = [];
        foreach ($this->dirEntries(self::BACKUP_DIR) as $e) {
            $name = (string) ($e['name'] ?? '');
            if (($e['file'] ?? true) === false && self::isValidModid($name) && !str_starts_with($name, 'file-')) {
                $out[] = $name;
            }
        }
        sort($out);

        return $out;
    }

    // ---- no stop required: plugin state only

    public function setPinned(string $modid, bool $pinned): void
    {
        $modid = $this->safeModid($modid);
        $this->mutateManifest(function (array &$m) use ($modid, $pinned) {
            $m['pinned'] = array_values(array_diff($m['pinned'], [$modid]));
            if ($pinned) {
                $m['pinned'][] = $modid;
            }
        });
    }

    public function setGameVersionOverride(?string $version): void
    {
        $version = $version === null ? null : trim($version);
        if ($version === '') {
            $version = null;
        }
        if ($version !== null && Version::parse($version) === null) {
            throw new ModManagerException("\"{$version}\" is not a valid game version (expected something like 1.20.12).");
        }

        $this->mutateManifest(function (array &$m) use ($version) {
            $m['game_version_override'] = $version;
        });
        Cache::forget(GameVersionService::cacheKey($this->server()));
    }

    /** Drop the short-lived Wings read cache of this server (after any write, a state change or a manual refresh). */
    public function forgetSnapshot(): void
    {
        app(Snapshot::class)->forget((string) $this->server()->uuid);
    }

    // ------------------------------------------------------------------ logs

    /** The server's data/Logs/server-main.log, or null if it's missing or too big to fetch whole. */
    public function readServerLog(): ?string
    {
        foreach ($this->dirEntries('data/Logs') as $e) {
            if (($e['name'] ?? null) === 'server-main.log') {
                if ((int) ($e['size'] ?? 0) > self::MAX_LOG_BYTES) {
                    return null;
                }
                try {
                    return (string) $this->files()->getContent('/data/Logs/server-main.log', self::MAX_LOG_BYTES);
                } catch (FileNotFoundException) {
                    return null;
                }
            }
        }

        return null;
    }

    // ------------------------------------------------------------------ internals

    /**
     * Pull → verify → move the old file(s) to backups → put the new file in place → manifest.
     * The download lands under a temporary name so an existing file of the same name is never clobbered and a
     * failed download never leaves a half file in the mods folder.
     */
    /** @param array{assetid: ?int, moddbid: ?int} $ids */
    private function performInstall(string $action, array $ids, array $release, ?array $installed = null): array
    {
        $filename = $this->safeFilename((string) ($release['filename'] ?? ''));
        if (!in_array(strtolower(pathinfo($filename, PATHINFO_EXTENSION)), ['zip', 'dll', 'cs'], true)) {
            throw new ModManagerException("Release file \"{$filename}\" is not a zip, dll or cs file.");
        }
        $modidHint = !empty($release['modidstr']) ? $this->safeModid((string) $release['modidstr']) : null;
        $version = (string) ($release['modversion'] ?? '');

        return $this->mutate($action, ['mod' => $modidHint, 'version' => $version, 'file' => $filename], function () use ($action, $ids, $release, $installed, $filename, $modidHint, $version) {
            $dir = $this->modsDir();
            $tmp = $filename . '.vsmm-part';
            $repo = $this->files();
            $uuid = $this->server()->uuid;

            $this->deleteQuietly($dir, $tmp);

            // 1. Download inside Wings (foreground: the request returns when the file is complete).
            $pullUrl = app(ModDbClient::class)->downloadUrl($release);
            Trace::info($action . '.pull', ['file' => $filename, 'fileid' => $release['fileid'] ?? null, 'url' => Trace::safeUrl($pullUrl), 'dir' => $dir]);
            $tPull = hrtime(true);
            try {
                $repo->getHttpClient()
                    ->timeout(max((int) config('panel.guzzle.timeout', 15), 120))
                    ->post("/api/servers/{$uuid}/files/pull", [
                        'url' => $pullUrl,
                        'root' => "/$dir",
                        'file_name' => $tmp,
                        'foreground' => true,
                    ]);
            } catch (\Throwable $e) {
                $this->deleteQuietly($dir, $tmp);
                throw $this->wingsError('The download failed', $e);
            }

            Trace::debug($action . '.pulled', ['ms' => (int) round((hrtime(true) - $tPull) / 1e6)]);

            // 2. Verify: the file landed, isn't empty, and (for zips) is a readable mod archive.
            $size = null;
            foreach ($this->dirEntries($dir) as $e) {
                if (($e['name'] ?? null) === $tmp) {
                    $size = (int) ($e['size'] ?? 0);
                }
            }
            if (!$size) {
                $this->deleteQuietly($dir, $tmp);
                throw new ModManagerException('The download did not produce a file (or it was empty). The old version was left in place.');
            }
            $info = null;
            if (str_ends_with(strtolower($filename), '.zip') && $size <= self::MAX_READ_BYTES) {
                try {
                    $bytes = (string) $repo->getContent("/$dir/$tmp", self::MAX_READ_BYTES);
                    $info = ModInfoReader::fromZipBytes($bytes);
                } catch (\Throwable $e) {
                    $this->deleteQuietly($dir, $tmp);
                    throw $this->wingsError('The downloaded file could not be read back', $e);
                }
                if (strlen($bytes) !== $size || $info === null) {
                    $this->deleteQuietly($dir, $tmp);
                    throw new ModManagerException('The downloaded file is not a valid mod archive (no readable modinfo.json). The old version was left in place.');
                }
            }

            Trace::debug($action . '.verified', ['size' => $size, 'modinfo_modid' => $info['modid'] ?? null, 'modinfo_version' => $info['version'] ?? null]);
            $modid = $modidHint ?? (!empty($info['modid']) ? $this->safeModid((string) $info['modid']) : null);
            if ($modid === null) {
                $this->deleteQuietly($dir, $tmp);
                throw new ModManagerException('Could not work out the mod id of the downloaded file.');
            }

            // The download can take a while: make sure nobody started the server in the meantime, before any file moves.
            try {
                $this->assertStopped();
            } catch (\Throwable $e) {
                $this->deleteQuietly($dir, $tmp);
                throw $e;
            }

            // 3. Move whatever is being replaced to backups, then 4. put the new file in place.
            $replace = $this->rowsFor($modid, $filename);
            if ($installed !== null && !empty($installed['filename'])) {
                $have = array_column($replace, 'filename');
                if (!in_array($installed['filename'], $have, true)) {
                    $replace[] = ['filename' => $this->safeFilename((string) $installed['filename']), 'modid' => $modid];
                }
            }
            $moved = [];
            Trace::debug($action . '.replace', ['replacing' => implode(',', array_column($replace, 'filename'))]);
            try {
                foreach ($replace as $row) {
                    $moved[] = [$row['filename'], $this->moveToBackup($dir, $modid, $row['filename'])];
                }
                $repo->renameFiles('/', [['from' => "/$dir/$tmp", 'to' => "/$dir/$filename"]]);
            } catch (\Throwable $e) {
                $this->restoreMoved($dir, $moved);
                $this->deleteQuietly($dir, $tmp);
                throw $this->wingsError('Could not put the new file in place', $e);
            }

            // 5. Manifest: maps the file to its exact ModDB release (and keeps what modinfo said).
            $entry = [
                'modid' => $modid,
                'name' => $info['name'] ?? ($release['name'] ?? $modid),
                'version' => $version !== '' ? $version : ($info['version'] ?? null),
                'side' => $info['side'] ?? null,
                'type' => $info['type'] ?? null,
                'dependencies' => $info['dependencies'] ?? [],
                'requiredOnClient' => $info['requiredOnClient'] ?? null,
                'gameMin' => $info['gameMin'] ?? null,
                'size' => $size,
                'assetid' => $ids['assetid'],
                'moddbid' => $ids['moddbid'],
                'releaseid' => $release['releaseid'] ?? null,
                'fileid' => $release['fileid'] ?? null,
                'installed_at' => gmdate('c'),
            ];
            $this->mutateManifest(function (array &$m) use ($replace, $filename, $entry) {
                foreach ($replace as $row) {
                    unset($m['mods'][$row['filename']]);
                }
                $m['mods'][$filename] = $entry;
            });
            $this->pruneBackups($modid);

            $label = (string) $entry['name'];
            $from = $installed['version'] ?? ($replace[0]['version'] ?? null);

            return [
                'message' => $action === 'update' && $from ? "Updated {$label} from {$from} to {$entry['version']}." : "Installed {$label} {$entry['version']}.",
                'modid' => $modid, 'filename' => $filename, 'version' => $entry['version'], 'dependencies' => $entry['dependencies'],
            ];
        });
    }

    /**
     * Common wrapper: stopped check, per-server lock, Wings errors → ModManagerException, activity log.
     *
     * @param  array<string, mixed>  $properties  logged with the activity
     */
    private function mutate(string $action, array $properties, Closure $work): array
    {
        Trace::begin((int) $this->server()->id);
        $t0 = hrtime(true);
        $ms = fn () => (int) round((hrtime(true) - $t0) / 1e6);
        Trace::info($action . '.start', $properties + ['state' => $this->state()]);

        try {
            $this->assertStopped();

            $lock = Cache::lock('vsmm.server.' . $this->server()->id, 180);
            if (!$lock->get()) {
                throw new ModManagerException('Another mod change is already running on this server. Try again in a moment.');
            }

            try {
                // Re-check now that we hold the lock (the state may have changed while waiting).
                $this->assertStopped();
                $this->forgetSnapshot(); // the next read must see what this change leaves behind
                $result = $work();
                Activity::event("server:vs-mods.{$action}")->subject($this->server())->property($properties)->log();
                Trace::info($action . '.ok', ['mod' => $result['modid'] ?? null, 'file' => $result['filename'] ?? null, 'version' => $result['version'] ?? null, 'ms' => $ms()]);

                return $result;
            } catch (RequestException|ConnectionException $e) {
                throw $this->wingsError('The server node reported an error', $e);
            } finally {
                $this->forgetSnapshot();
                $lock->release();
            }
        } catch (ModManagerException $e) {
            Trace::warning($action . '.failed', ['error' => $e->getMessage(), 'cause' => $e->getPrevious() ? get_class($e->getPrevious()) : null, 'ms' => $ms()]);
            throw $e;
        } catch (\Throwable $e) {
            Trace::error($action . '.crashed', ['exception' => get_class($e), 'error' => strtok($e->getMessage(), "\n"), 'at' => basename($e->getFile()) . ':' . $e->getLine(), 'ms' => $ms()]);
            throw $e;
        } finally {
            Trace::end();
        }
    }

    private function wingsError(string $what, \Throwable $e): ModManagerException
    {
        if ($e instanceof ModManagerException) {
            return $e;
        }
        report($e);
        $msg = $e instanceof RequestException ? 'HTTP ' . $e->response->status() : strtok($e->getMessage(), "\n");
        Trace::error('wings.error', [
            'what' => $what,
            'status' => $e instanceof RequestException ? $e->response->status() : null,
            'body' => $e instanceof RequestException ? $e->response->body() : null,
            'exception' => get_class($e),
            'message' => $e instanceof RequestException ? null : strtok($e->getMessage(), "\n"),
        ]);

        return new ModManagerException("{$what} ({$msg}).", 0, $e);
    }

    /** Installed rows (from list()) that hold this modid, or have exactly this filename. */
    private function rowsFor(string $modid, ?string $filename = null): array
    {
        return array_values(array_filter(
            $this->list(),
            fn ($r) => $r['kind'] !== 'ignored' && (
                (isset($r['modid']) && strcasecmp((string) $r['modid'], $modid) === 0)
                || ($filename !== null && $r['filename'] === $filename)
            ),
        ));
    }

    /** Moves a file/folder out of the mods folder into backups/<modid>/. Returns the stored name. */
    private function moveToBackup(string $dir, string $modid, string $filename): string
    {
        $this->ensureDir($this->backupDir($modid));
        // Microseconds in the stamp: "newest backup" must stay unambiguous when changes follow each other quickly.
        $stamp = (new \DateTimeImmutable('now', new \DateTimeZone('UTC')))->format('Ymd\THisu\Z');
        $stored = $stamp . '-' . bin2hex(random_bytes(2)) . "__{$filename}";
        $this->files()->renameFiles('/', [['from' => "/$dir/$filename", 'to' => '/' . $this->backupDir($modid) . "/$stored"]]);
        $this->storedModid[$stored] = $modid; // remembered so a failed install can move it back

        return $stored;
    }

    /** Best-effort undo of moveToBackup() calls after a failure. @param array<int, array{0: string, 1: string}> $moved */
    private function restoreMoved(string $dir, array $moved): void
    {
        foreach (array_reverse($moved) as [$original, $stored]) {
            try {
                $modid = $this->storedModid[$stored];
                $this->files()->renameFiles('/', [['from' => '/' . $this->backupDir($modid) . "/$stored", 'to' => "/$dir/$original"]]);
            } catch (\Throwable $e) {
                report($e);
            }
        }
    }

    /** Keep only the newest N backups of a mod. */
    private function pruneBackups(string $modid): void
    {
        $keep = max(1, (int) config('vs-mod-manager.backups_per_mod', 3));
        $old = array_slice($this->backups($modid), $keep);
        if ($old !== []) {
            $this->files()->deleteFiles('/', array_map(fn ($b) => '/' . $this->backupDir($modid) . '/' . $b['name'], $old));
        }
    }

    /** @return array<int, array<string, mixed>> */
    private function dirEntries(string $path, bool $cached = false): array
    {
        if ($cached) {
            return app(Snapshot::class)->remember((string) $this->server()->uuid, 'dir.' . md5($path), fn () => $this->dirEntries($path));
        }

        try {
            $list = $this->files()->getDirectory('/' . $path);
        } catch (RequestException $e) {
            if ($e->response->status() === 404) {
                return [];
            }
            throw $e;
        }

        return isset($list['error']) || !is_array($list) ? [] : array_values($list);
    }

    private function requireExists(string $dir, string $name): void
    {
        foreach ($this->dirEntries($dir) as $e) {
            if (($e['name'] ?? null) === $name) {
                return;
            }
        }
        throw new ModManagerException("{$name} is no longer in the mods folder.");
    }

    private function requireAbsent(string $dir, string $name): void
    {
        foreach ($this->dirEntries($dir) as $e) {
            if (($e['name'] ?? null) === $name) {
                throw new ModManagerException("A file named {$name} already exists in the mods folder.");
            }
        }
    }

    private function deleteQuietly(string $dir, string $name): void
    {
        try {
            $this->files()->deleteFiles('/', ["/$dir/$name"]);
        } catch (\Throwable) {
            // Nothing to delete, or the node is unreachable: the caller is already failing.
        }
    }

    /** Creates each missing directory of a relative path. */
    private function ensureDir(string $path): void
    {
        if (isset($this->ensured[$path])) {
            return;
        }
        $parent = '/';
        foreach (explode('/', $path) as $segment) {
            try {
                $this->files()->createDirectory($segment, $parent);
            } catch (\Throwable) {
                // Already exists (Wings answers 400).
            }
            $parent = rtrim($parent, '/') . '/' . $segment;
        }
        $this->ensured[$path] = true;
    }

    /** File names come from ModDB and from the page: no path tricks. */
    private function safeFilename(string $name): string
    {
        if ($name === '' || strlen($name) > 200
            || preg_match('/[\x00-\x1F\x7F\/\\\\]/', $name)
            || str_contains($name, '..') || str_starts_with($name, '.')) {
            throw new ModManagerException('Refusing a file name that is empty or contains path characters.');
        }

        return $name;
    }

    /**
     * backups/<modid>, lower-cased: modinfo and ModDB don't always agree on the case of a mod id, and the
     * backup of one mod must be found again whichever of the two the caller has.
     */
    private function backupDir(string $modid): string
    {
        return self::BACKUP_DIR . '/' . strtolower($this->safeModid($modid));
    }

    /** Backup folder name for a file without a mod id ("My Mod (1).zip" → "file-My_Mod__1_"). Pure. */
    public static function fileBackupId(string $filename): string
    {
        $stem = preg_replace('/[^A-Za-z0-9_\-]/', '_', pathinfo($filename, PATHINFO_FILENAME)) ?? '';

        return 'file-' . substr($stem !== '' ? $stem : 'unnamed', 0, 90);
    }

    /** Mod ids are used as directory names in backups. */
    public static function isValidModid(string $modid): bool
    {
        return (bool) preg_match('/^[A-Za-z0-9][A-Za-z0-9_.\-]{0,99}$/', $modid) && !str_contains($modid, '..');
    }

    private function safeModid(string $modid): string
    {
        if (!self::isValidModid($modid)) {
            throw new ModManagerException("\"{$modid}\" is not a valid mod id.");
        }

        return $modid;
    }

    private function files(): DaemonFileRepository
    {
        return (new DaemonFileRepository())->setServer($this->server());
    }

    private function server(): Server
    {
        return $this->server ?? throw new \LogicException('Call forServer() first.');
    }
}
