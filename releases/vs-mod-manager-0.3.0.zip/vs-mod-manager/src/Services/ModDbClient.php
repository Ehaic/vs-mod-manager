<?php

declare(strict_types=1);

namespace Ehaic\VsModManager\Services;

use Ehaic\VsModManager\Support\SwrCache;
use Ehaic\VsModManager\Support\Trace;
use Ehaic\VsModManager\Support\Version;
use Illuminate\Http\Client\ConnectionException;
use Illuminate\Http\Client\PendingRequest;
use Illuminate\Http\Client\Pool;
use Illuminate\Http\Client\Response;
use Illuminate\Support\Facades\Http;
use Throwable;

/**
 * Client for the Vintage Story ModDB API (https://mods.vintagestory.at/api/), see research/01-moddb-api.md.
 *
 * - v1 always answers HTTP 200 and signals errors with a string `statuscode` in the body ("404"...).
 * - v2 uses real HTTP codes.
 * - Lookups that fail return null / [] (and log a warning) instead of throwing, and failures are never cached.
 *
 * The normalise*() methods are pure and static so they can be unit-tested without Laravel.
 */
class ModDbClient
{
    public const DEFAULT_URL = 'https://mods.vintagestory.at';
    private const STABLE_URL = 'https://api.vintagestory.at/stable.json';
    private const USER_AGENT = 'pelican-vs-mod-manager/1.0 (Pelican Panel plugin; +https://github.com/Ehaic)';

    /** install-information accepts a comma list in the URL; stay well under nginx's URI limit. */
    private const INSTALL_INFO_CHUNK = 50;

    /** After a transport failure the ModDB is treated as down for this long (seconds), for every request of every user. */
    private const DOWN_TTL = 60;
    private const CONNECT_TIMEOUT = 5;
    /** Parallel requests when looking up many mods at once. */
    private const POOL_SIZE = 8;

    /** Set when a request in this PHP request failed (network/HTTP error, not "unknown mod"). */
    private bool $failed = false;

    /** True when the ModDB could not be reached during this request, so an empty/null answer means "don't know". */
    public function hadFailure(): bool
    {
        return $this->failed;
    }

    // ---- public API (see docs/INTERFACES.md) --------------------------------------------------------

    /**
     * Every public mod, normalised (see normaliseCatalogueEntry()). One 4 MB request, cached stale-while-revalidate:
     * after the soft TTL the old list is served at once and refreshed after the response (see SwrCache).
     *
     * @return array<int, array<string, mixed>>
     */
    public function catalogue(): array
    {
        return $this->remember('catalogue', $this->ttl('catalogue_ttl', 1800), fn (): ?array => $this->fetchCatalogue());
    }

    private function fetchCatalogue(): ?array
    {
        $body = $this->getV1('mods', timeout: 45, tries: 1);

        return $body === null ? null : self::normaliseCatalogue($body);
    }

    /**
     * One mod with all its releases, by numeric ModDB id or modinfo modid string (case-insensitive).
     * Null if unknown or the API failed. urlalias is NOT accepted by the API.
     *
     * @return array<string, mixed>|null
     */
    public function mod(string|int $idOrModid): ?array
    {
        $key = strtolower(trim((string) $idOrModid));
        if ($key === '') {
            return null;
        }

        return $this->remember('mod:' . $key, $this->ttl('detail_ttl', 1800), function () use ($key): ?array {
            $body = $this->getV1('mod/' . rawurlencode($key));

            return $body === null ? null : self::normaliseMod($body);
        }, null);
    }

    /** The catalogue if it is cached (fresh or stale); never goes to the network. Null when cold. */
    public function catalogueCached(): ?array
    {
        $this->swr()->refreshIfStale('vs-mod-manager:moddb:catalogue', $this->ttl('catalogue_ttl', 1800), fn (): ?array => $this->fetchCatalogue());
        $v = $this->swr()->peek('vs-mod-manager:moddb:catalogue');

        return is_array($v) ? $v : null;
    }

    /** Mod category tags if cached; never goes to the network. Null when cold. */
    public function tagsCached(): ?array
    {
        $this->swr()->refreshIfStale('vs-mod-manager:moddb:tags', 6 * 3600, fn (): ?array => $this->fetchTags());
        $v = $this->swr()->peek('vs-mod-manager:moddb:tags');

        return is_array($v) ? $v : null;
    }

    /** One mod's /api/mod answer if cached (fresh or stale); never goes to the network. */
    public function modCached(string|int $idOrModid): ?array
    {
        $v = $this->swr()->peek('vs-mod-manager:moddb:mod:' . strtolower(trim((string) $idOrModid)));

        return is_array($v) ? $v : null;
    }

    /** Browse tab can render from the cache alone (catalogue and tags are both cached, reads two tiny keys). */
    public function isBrowseWarm(): bool
    {
        return $this->swr()->has('vs-mod-manager:moddb:catalogue') && $this->swr()->has('vs-mod-manager:moddb:tags');
    }

    /** Every id in the list has a cached /api/mod answer (fresh or stale). */
    public function hasAllMods(array $idsOrModids): bool
    {
        foreach ($idsOrModids as $id) {
            if (! $this->swr()->has('vs-mod-manager:moddb:mod:' . strtolower(trim((string) $id)))) {
                return false;
            }
        }

        return true;
    }

    /**
     * Warm the /api/mod/{x} cache for many mods with a few parallel requests, instead of one blocking request per
     * mod. Mods that are missing are fetched now; mods that are only stale are refreshed after the response (one
     * pooled batch) while their old answer keeps being used. Failures are ignored here: mod() asks again (and reports).
     *
     * @param  array<int, string|int>  $idsOrModids
     * @param  bool  $fetchMissing  false = only queue the refresh of stale answers (mods without any answer stay missing)
     */
    public function prefetchMods(array $idsOrModids, bool $fetchMissing = true): void
    {
        if ($this->isDown()) {
            $this->failed = true;

            return;
        }

        $swr = $this->swr();
        $missing = [];
        $stale = [];
        foreach ($idsOrModids as $id) {
            $key = strtolower(trim((string) $id));
            if ($key === '') {
                continue;
            }
            $full = 'vs-mod-manager:moddb:mod:' . $key;
            if (! $swr->has($full)) {
                $missing[$key] = true;
            } elseif (! $swr->isFresh($full) && $swr->claim($full)) {
                $stale[$key] = true; // claimed: mod() won't queue its own refresh for it
            }
        }

        if ($missing !== [] && $fetchMissing) {
            $this->fetchMods(array_keys($missing));
        }
        if ($stale !== []) {
            $keys = array_keys($stale);
            app()->terminating(function () use ($keys, $swr): void {
                try {
                    $this->fetchMods($keys);
                } finally {
                    foreach ($keys as $key) {
                        $swr->release('vs-mod-manager:moddb:mod:' . $key);
                    }
                }
            });
        }
    }

    /** @param string[] $keys lower-case ids; parallel requests, results go straight into the cache */
    private function fetchMods(array $keys): void
    {
        $ttl = $this->ttl('detail_ttl', 1800);
        $swr = $this->swr();
        foreach (array_chunk($keys, self::POOL_SIZE) as $chunk) {
            $t0 = hrtime(true);
            try {
                $responses = Http::pool(function (Pool $pool) use ($chunk) {
                    $requests = [];
                    foreach ($chunk as $key) {
                        $requests[] = $pool->as((string) $key)
                            ->withHeaders(['User-Agent' => self::USER_AGENT])->acceptJson()
                            ->connectTimeout(self::CONNECT_TIMEOUT)->timeout(15)
                            ->get($this->baseUrl() . '/api/mod/' . rawurlencode((string) $key));
                    }

                    return $requests;
                });
            } catch (Throwable $e) {
                Trace::warning('moddb.parallel_lookup.failed', ['error' => strtok($e->getMessage(), "\n")]);
                $this->markDown();

                return;
            }
            Trace::debug('moddb.api.pool', ['mods' => count($chunk), 'ms' => (int) round((hrtime(true) - $t0) / 1e6)]);

            $broken = 0;
            foreach ($chunk as $key) {
                $res = $responses[$key] ?? null;
                if (! $res instanceof Response) {
                    $broken++;
                    $swr->backoff('vs-mod-manager:moddb:mod:' . $key);

                    continue;
                }
                $json = $res->successful() ? $res->json() : null;
                if (is_array($json) && (string) ($json['statuscode'] ?? '') === '200' && ($mod = self::normaliseMod($json)) !== null) {
                    $swr->put('vs-mod-manager:moddb:mod:' . $key, $mod, $ttl);
                } else {
                    $swr->backoff('vs-mod-manager:moddb:mod:' . $key);
                }
            }
            if ($broken === count($chunk)) {
                $this->markDown(); // nothing answered at all: stop asking for a minute

                return;
            }
        }
    }

    /** Drop the cached /api/mod/{x} answer so the next mod() call asks the ModDB again ("Check for updates"). */
    public function forgetMod(string|int $idOrModid): void
    {
        $this->swr()->forget('vs-mod-manager:moddb:mod:' . strtolower(trim((string) $idOrModid)));
    }

    /**
     * What the game client uses to check installed mods: GET /api/v2/mods/install-information.
     * $modidAtVersions: list of "modid@version" (or bare "modid") strings, or a map modid => version.
     * Returns map modid => raw result: ['fileName','fileUrl','recommendedUpgrade'] or ['errorCode' => 4041 ...].
     * Exact game-version match only (no patch tolerance): ReleaseSelector covers the rest.
     *
     * @param  array<int|string, string>  $modidAtVersions
     * @return array<string, array<string, mixed>>
     */
    public function installInformation(string $gameVersion, array $modidAtVersions): array
    {
        // gv must be full semver; the API answers 400 (or 500 on v1) otherwise.
        if (! preg_match('/^\d+\.\d+\.\d+(-(dev|pre|rc)\.\d+)?$/', $gameVersion)) {
            return [];
        }

        $ids = [];
        foreach ($modidAtVersions as $k => $v) {
            if (is_string($k)) {
                $ids[] = $v === '' ? $k : $k . '@' . $v;
            } else {
                $ids[] = (string) $v;
            }
        }
        $ids = array_values(array_unique(array_filter($ids, static fn ($i) => $i !== '')));

        $result = [];
        foreach (array_chunk($ids, self::INSTALL_INFO_CHUNK) as $chunk) {
            $data = $this->remember(
                'installinfo:' . $gameVersion . ':' . md5(implode(',', $chunk)),
                600,
                fn (): ?array => $this->fetchInstallInformation($gameVersion, $chunk),
            );
            $result += $data ?? [];
        }

        return $result;
    }

    /**
     * Mod category tags: id => name.
     *
     * @return array<int, string>
     */
    public function tags(): array
    {
        return $this->remember('tags', 6 * 3600, fn (): ?array => $this->fetchTags());
    }

    private function fetchTags(): ?array
    {
        $body = $this->getV1('tags');

        return $body === null ? null : self::normaliseTags($body);
    }

    /**
     * Game versions known to the ModDB (pre-releases included), newest first.
     *
     * @return string[]
     */
    public function gameVersions(): array
    {
        return $this->remember('gameversions', 6 * 3600, function (): ?array {
            $body = $this->getV1('gameversions');

            return $body === null ? null : self::normaliseGameVersions($body);
        });
    }

    /** Newest stable Vintage Story release from the official version feed, cached 1 h. Null if unreachable. */
    public function latestStableGameVersion(): ?string
    {
        return $this->remember('stable', 3600, function (): ?string {
            try {
                $res = $this->http()->timeout(15)->get(self::STABLE_URL);
                $json = $res->successful() ? $res->json() : null;
            } catch (Throwable $e) {
                Trace::warning('moddb.stable_json.failed', ['error' => strtok($e->getMessage(), "\n")]);

                return null;
            }

            return is_array($json) ? self::latestStableFrom($json) : null;
        }, null);
    }

    /**
     * Download URL to hand to Wings. ModDB's tracking URL (counts the download for the author) answers
     * 302 to the CDN with the filename RAW in `?dl=` (spaces, parentheses). Wings' Go HTTP client
     * forwards the spaces unescaped and the CDN replies 400, so resolve that one redirect here and
     * percent-encode the Location. Falls back to the tracking URL if it can't be resolved
     * (retracted release -> 410, network error) so the existing error handling still applies.
     */
    public function downloadUrl(array $release): string
    {
        $tracking = self::buildDownloadUrl($this->baseUrl(), $release);
        try {
            $res = Http::withHeaders(['User-Agent' => self::USER_AGENT])
                ->withoutRedirecting()
                ->connectTimeout(self::CONNECT_TIMEOUT)
                ->timeout(15)
                ->get($tracking);
            $location = $res->header('Location');
            if ($res->status() >= 300 && $res->status() < 400 && $location !== '' && preg_match('#^https?://#i', $location)) {
                $resolved = self::encodeLocation($location);
                Trace::debug('moddb.download.resolved', ['status' => $res->status(), 'to' => Trace::safeUrl($resolved), 'encoded' => $resolved !== $location]);

                return $resolved;
            }
            Trace::warning('moddb.download.no_redirect', ['url' => Trace::safeUrl($tracking), 'status' => $res->status()]);
        } catch (\Throwable $e) {
            Trace::warning('moddb.download.resolve_failed', ['url' => Trace::safeUrl($tracking), 'error' => strtok($e->getMessage(), "\n")]);
        }

        return $tracking;
    }

    /** Percent-encode every byte that isn't legal in a URL (spaces, non-ASCII, quotes...). Already-encoded `%xx` and reserved characters stay. */
    public static function encodeLocation(string $url): string
    {
        return (string) preg_replace_callback(
            '/[^A-Za-z0-9\-._~:\/?#\[\]@!$&\'()*+,;=%]/',
            static fn (array $m) => rawurlencode($m[0]),
            $url,
        );
    }

    /**
     * Public ModDB page of a mod (normalised mod or catalogue entry). The site's /show/mod/{n} takes the
     * ASSET id, not the API modid (those differ: e.g. modid 7592 is not a page, assetid 44025 is).
     */
    public function modPageUrl(array $mod): string
    {
        return self::buildModPageUrl($this->baseUrl(), $mod);
    }

    // ---- pure helpers (unit-tested) -----------------------------------------------------------------

    /**
     * @param  array<string, mixed>  $body  decoded /api/mods response
     * @return array<int, array<string, mixed>>
     */
    public static function normaliseCatalogue(array $body): array
    {
        $out = [];
        foreach ((array) ($body['mods'] ?? []) as $m) {
            if (is_array($m) && isset($m['modid'])) {
                $out[] = self::normaliseCatalogueEntry($m);
            }
        }

        return $out;
    }

    /**
     * @param  array<string, mixed>  $m
     * @return array<string, mixed>
     */
    public static function normaliseCatalogueEntry(array $m): array
    {
        return [
            'modid' => (int) $m['modid'],                 // ModDB mod id (NOT the modinfo modid)
            'assetid' => (int) ($m['assetid'] ?? 0),
            'modidstrs' => array_values(array_filter(array_map('strval', (array) ($m['modidstrs'] ?? [])), static fn ($s) => $s !== '')),
            'name' => (string) ($m['name'] ?? ''),
            'summary' => (string) ($m['summary'] ?? ''),
            'author' => (string) ($m['author'] ?? ''),
            'downloads' => (int) ($m['downloads'] ?? 0),
            'follows' => (int) ($m['follows'] ?? 0),
            'trendingpoints' => (int) ($m['trendingpoints'] ?? 0),
            'comments' => (int) ($m['comments'] ?? 0),
            'side' => (string) ($m['side'] ?? 'both'),
            'type' => (string) ($m['type'] ?? 'mod'),
            'logo' => self::nullableString($m['logo'] ?? null),
            'tags' => self::cleanTags($m['tags'] ?? []),
            'lastreleased' => self::nullableString($m['lastreleased'] ?? null),
            'urlalias' => self::nullableString($m['urlalias'] ?? null),
        ];
    }

    /**
     * @param  array<string, mixed>  $body  decoded /api/mod/{x} response ({"mod": {...}, "statuscode": "200"})
     * @return array<string, mixed>|null
     */
    public static function normaliseMod(array $body): ?array
    {
        $m = $body['mod'] ?? null;
        if (! is_array($m) || ! isset($m['modid'])) {
            return null;
        }

        $releases = [];
        foreach ((array) ($m['releases'] ?? []) as $r) {
            if (is_array($r) && ($rel = self::normaliseRelease($r)) !== null) {
                $releases[] = $rel;
            }
        }

        return [
            'assetid' => (int) ($m['assetid'] ?? 0),
            'modid' => (int) $m['modid'],
            'name' => (string) ($m['name'] ?? ''),
            'text' => (string) ($m['text'] ?? ''),         // author HTML: sanitise before showing
            'author' => (string) ($m['author'] ?? ''),
            'urlalias' => self::nullableString($m['urlalias'] ?? null),
            'side' => (string) ($m['side'] ?? 'both'),
            'type' => (string) ($m['type'] ?? 'mod'),
            'logo' => self::nullableString($m['logofiledb'] ?? $m['logofile'] ?? $m['logofilename'] ?? null),
            'homepageurl' => self::nullableString($m['homepageurl'] ?? null),
            'sourcecodeurl' => self::nullableString($m['sourcecodeurl'] ?? null),
            'issuetrackerurl' => self::nullableString($m['issuetrackerurl'] ?? null),
            'downloads' => (int) ($m['downloads'] ?? 0),
            'follows' => (int) ($m['follows'] ?? 0),
            'tags' => self::cleanTags($m['tags'] ?? []),
            'releases' => $releases,
        ];
    }

    /**
     * A release without a usable file (no fileid or filename) is kept but marked by fileid = null.
     *
     * @param  array<string, mixed>  $r
     * @return array<string, mixed>|null
     */
    public static function normaliseRelease(array $r): ?array
    {
        if (! isset($r['releaseid'])) {
            return null;
        }

        return [
            'releaseid' => (int) $r['releaseid'],
            'fileid' => isset($r['fileid']) && $r['fileid'] !== '' ? (int) $r['fileid'] : null,
            'filename' => (string) ($r['filename'] ?? ''),
            'mainfile' => (string) ($r['mainfile'] ?? ''),   // direct CDN URL (doesn't count the download)
            'modidstr' => (string) ($r['modidstr'] ?? ''),
            'modversion' => (string) ($r['modversion'] ?? ''),
            'tags' => array_values(array_map('strval', (array) ($r['tags'] ?? []))),   // compatible game versions
            'created' => (string) ($r['created'] ?? ''),
            'downloads' => (int) ($r['downloads'] ?? 0),
            'changelog' => (string) ($r['changelog'] ?? ''),  // author HTML: sanitise before showing
        ];
    }

    /**
     * @param  array<string, mixed>  $body
     * @return array<int, string>
     */
    public static function normaliseTags(array $body): array
    {
        $out = [];
        foreach ((array) ($body['tags'] ?? []) as $t) {
            if (is_array($t) && isset($t['tagid'], $t['name']) && $t['name'] !== '') {
                $out[(int) $t['tagid']] = (string) $t['name'];
            }
        }

        return $out;
    }

    /**
     * The API lists them oldest first; we return newest first.
     *
     * @param  array<string, mixed>  $body
     * @return string[]
     */
    public static function normaliseGameVersions(array $body): array
    {
        $names = [];
        foreach ((array) ($body['gameversions'] ?? []) as $g) {
            if (is_array($g) && isset($g['name']) && Version::parse((string) $g['name']) !== null) {
                $names[] = (string) $g['name'];
            }
        }
        usort($names, static fn (string $a, string $b) => Version::compare($b, $a));

        return $names;
    }

    /**
     * stable.json is an object keyed by version ("1.22.7": {...}). Highest stable key.
     *
     * @param  array<string, mixed>  $json
     */
    public static function latestStableFrom(array $json): ?string
    {
        $best = null;
        foreach (array_keys($json) as $key) {
            $key = (string) $key;
            if (Version::parse($key) === null || Version::isPrerelease($key)) {
                continue;
            }
            if ($best === null || Version::compare($key, $best) > 0) {
                $best = $key;
            }
        }

        return $best;
    }

    /**
     * Raw v2 install-information body → map modid => result. Accepts the error body too
     * (a 400 with "data" when every id was malformed).
     *
     * @param  array<string, mixed>  $body
     * @return array<string, array<string, mixed>>
     */
    public static function normaliseInstallInformation(array $body): array
    {
        $out = [];
        foreach ((array) ($body['data'] ?? []) as $id => $res) {
            if (is_array($res)) {
                $out[(string) $id] = $res;
            }
        }

        return $out;
    }

    /** @param array<string, mixed> $release */
    public static function buildDownloadUrl(string $base, array $release): string
    {
        // The filename in the path is cosmetic, but keep it URL-safe.
        return rtrim($base, '/') . '/download/' . (int) ($release['fileid'] ?? 0) . '/' . rawurlencode((string) ($release['filename'] ?? ''));
    }

    /** @param array<string, mixed> $mod */
    public static function buildModPageUrl(string $base, array $mod): string
    {
        $base = rtrim($base, '/');
        $alias = $mod['urlalias'] ?? null;

        return is_string($alias) && $alias !== ''
            ? $base . '/' . rawurlencode($alias)
            : $base . '/show/mod/' . (int) ($mod['assetid'] ?? 0);
    }

    // ---- internals ----------------------------------------------------------------------------------

    private function baseUrl(): string
    {
        return rtrim((string) config('vs-mod-manager.moddb_url', self::DEFAULT_URL), '/');
    }

    private function ttl(string $key, int $default): int
    {
        return max(60, (int) config('vs-mod-manager.' . $key, $default));
    }

    private function http(): PendingRequest
    {
        return Http::withHeaders(['User-Agent' => self::USER_AGENT])->acceptJson()->connectTimeout(self::CONNECT_TIMEOUT);
    }

    /**
     * GET /api/{path} (v1). Returns the decoded body, or null for transport errors, non-JSON bodies
     * and statuscode != "200" (v1 reports "not found" that way).
     *
     * @return array<string, mixed>|null
     */
    private function getV1(string $path, int $timeout = 15, int $tries = 2): ?array
    {
        if ($this->isDown()) {
            $this->failed = true;

            return null;
        }

        $t0 = hrtime(true);
        try {
            $res = $this->http()->timeout($timeout)->retry($tries, 300, static fn (Throwable $e) => $e instanceof ConnectionException, throw: false)
                ->get($this->baseUrl() . '/api/' . $path);
        } catch (Throwable $e) {
            Trace::warning('moddb.api.failed', ['path' => $path, 'error' => strtok($e->getMessage(), "\n"), 'ms' => (int) round((hrtime(true) - $t0) / 1e6)]);
            $this->markDown();

            return null;
        }

        $json = $res->successful() ? $res->json() : null;
        if (! is_array($json)) {
            Trace::warning('moddb.api.bad_response', ['path' => $path, 'status' => $res->status(), 'ms' => (int) round((hrtime(true) - $t0) / 1e6)]);
            $this->markDown();

            return null;
        }
        Trace::debug('moddb.api', ['path' => $path, 'status' => $res->status(), 'statuscode' => $json['statuscode'] ?? null, 'ms' => (int) round((hrtime(true) - $t0) / 1e6)]);
        // statuscode is a STRING in v1. 404 for an unknown mod is expected, not worth a warning.
        if ((string) ($json['statuscode'] ?? '') !== '200') {
            return null;
        }

        return $json;
    }

    /** The ModDB failed a moment ago (any user, any server): answer "don't know" at once instead of waiting for timeouts again. */
    private function isDown(): bool
    {
        return cache()->has('vs-mod-manager:moddb:down');
    }

    private function markDown(): void
    {
        $this->failed = true;
        cache()->put('vs-mod-manager:moddb:down', 1, self::DOWN_TTL);
    }

    /** @return array<string, array<string, mixed>>|null null = request failed */
    private function fetchInstallInformation(string $gameVersion, array $ids): ?array
    {
        if ($this->isDown()) {
            $this->failed = true;

            return null;
        }

        try {
            $res = $this->http()->timeout(15)->retry(2, 300, static fn (Throwable $e) => $e instanceof ConnectionException, throw: false)
                ->get($this->baseUrl() . '/api/v2/mods/install-information', [
                    'gv' => $gameVersion,
                    'ids' => implode(',', $ids),
                ]);
        } catch (Throwable $e) {
            Trace::warning('moddb.install_information.failed', ['error' => strtok($e->getMessage(), "\n")]);
            $this->markDown();

            return null;
        }

        $json = $res->json();
        if (! is_array($json)) {
            return null;
        }
        // A 400 can still carry per-id error codes in "data" (all ids malformed); other errors have none.
        $data = self::normaliseInstallInformation($json);

        return ($res->successful() || $data !== []) ? $data : null;
    }

    /**
     * Stale-while-revalidate read (see SwrCache): fresh -> cached value; stale -> cached value now, refresh after the
     * response; cold -> compute inline. Failures (null) are never cached; $onFailure is returned instead ([] for
     * list-returning methods, null for the others). Empty results are only trusted for 5 minutes.
     */
    private function remember(string $key, int $ttl, callable $compute, mixed $onFailure = []): mixed
    {
        return $this->swr()->get('vs-mod-manager:moddb:' . $key, $ttl, \Closure::fromCallable($compute), $onFailure);
    }

    private ?SwrCache $swr = null;

    private function swr(): SwrCache
    {
        // Created lazily: cache() and app() don't exist in the framework-free unit tests.
        return $this->swr ??= new SwrCache(cache(), static fn (\Closure $refresh) => app()->terminating($refresh));
    }

    private static function nullableString(mixed $v): ?string
    {
        return is_string($v) && $v !== '' ? $v : null;
    }

    /**
     * The API uses [""] when a mod has no tags.
     *
     * @return string[]
     */
    private static function cleanTags(mixed $tags): array
    {
        return array_values(array_filter(array_map('strval', (array) $tags), static fn ($t) => $t !== ''));
    }
}
