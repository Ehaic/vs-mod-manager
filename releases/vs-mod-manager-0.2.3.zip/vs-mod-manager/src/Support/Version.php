<?php

declare(strict_types=1);

namespace Ehaic\VsModManager\Support;

/**
 * Vintage Story version parsing and comparison.
 *
 * Order (same as the ModDB's lib/version.php): 1.0.0-dev.1 < 1.0.0-pre.1 < 1.0.0-rc.1 < 1.0.0 < 1.0.1
 */
final class Version
{
    /** Rank of the pre-release kind inside one major.minor.patch; stable is highest. */
    private const KIND_RANK = ['dev' => 0, 'pre' => 1, 'rc' => 2];

    /**
     * Accepts "1.20.12", "v1.20.12", "1.2.0-rc.1", "1.2.0-pre.2", "1.2.0-dev.3", "1.20.12 (Stable)".
     * A missing patch ("1.2") counts as 0 (installed modinfo versions are often sloppy).
     *
     * @return array{major:int,minor:int,patch:int,pre:?string,preNum:int,raw:string}|null
     */
    public static function parse(string $v): ?array
    {
        $raw = trim($v);
        if (! preg_match('/^v?(\d+)\.(\d+)(?:\.(\d+))?(?:-(dev|pre|rc)(?:[.-]?(\d+))?)?(?:\s*\(.*\))?$/i', $raw, $m)) {
            return null;
        }

        $pre = isset($m[4]) && $m[4] !== '' ? strtolower($m[4]) : null;

        return [
            'major' => (int) $m[1],
            'minor' => (int) $m[2],
            'patch' => (int) ($m[3] ?? 0),
            'pre' => $pre,
            'preNum' => $pre !== null ? (int) ($m[5] ?? 0) : 0,
            'raw' => $raw,
        ];
    }

    /** Negative, 0 or positive. Unparseable versions sort lowest (two unparseable ones are equal). */
    public static function compare(string $a, string $b): int
    {
        $pa = self::parse($a);
        $pb = self::parse($b);

        if ($pa === null || $pb === null) {
            return ($pa === null ? 0 : 1) <=> ($pb === null ? 0 : 1);
        }

        foreach (['major', 'minor', 'patch'] as $k) {
            if ($pa[$k] !== $pb[$k]) {
                return $pa[$k] <=> $pb[$k];
            }
        }

        $ra = $pa['pre'] === null ? 3 : self::KIND_RANK[$pa['pre']];
        $rb = $pb['pre'] === null ? 3 : self::KIND_RANK[$pb['pre']];
        if ($ra !== $rb) {
            return $ra <=> $rb;
        }

        return $pa['preNum'] <=> $pb['preNum'];
    }

    public static function isPrerelease(string $v): bool
    {
        $p = self::parse($v);

        return $p !== null && $p['pre'] !== null;
    }

    /** "1.20" for "1.20.12", null if unparseable. */
    public static function majorMinor(string $v): ?string
    {
        $p = self::parse($v);

        return $p === null ? null : $p['major'] . '.' . $p['minor'];
    }

    /**
     * Game semantics for a dependency: "" or "*" accepts anything, otherwise actual >= min.
     * Unparseable input is treated as satisfied (we can't prove it isn't).
     */
    public static function satisfiesMin(string $min, string $actual): bool
    {
        $min = trim($min);
        if ($min === '' || $min === '*') {
            return true;
        }
        if (self::parse($min) === null || self::parse($actual) === null) {
            return true;
        }

        return self::compare($actual, $min) >= 0;
    }
}
