<?php

declare(strict_types=1);

namespace Ehaic\VsModManager\Support;

use ZipArchive;

/**
 * Reads mod identity from the places the game itself reads it: modinfo.json (zips, folders),
 * the [assembly: ModInfo(...)] attribute (.cs source), or, as a last resort, the file name.
 *
 * Every reader returns the same normalised shape (see emptyInfo()).
 */
final class ModInfoReader
{
    /** modinfo.json is tiny; refuse to read anything bigger from a zip. */
    private const MAX_MODINFO_BYTES = 1024 * 1024;

    /** @return array<string, mixed> */
    private static function emptyInfo(): array
    {
        return [
            'modid' => null, 'name' => null, 'version' => null, 'type' => null, 'side' => null,
            'requiredOnClient' => null, 'requiredOnServer' => null,
            'dependencies' => [], 'authors' => [], 'description' => null, 'website' => null, 'gameMin' => null,
        ];
    }

    /**
     * Lenient modinfo.json parse, like the game's Newtonsoft: BOM, // and /* comments, trailing commas,
     * case-insensitive keys. Returns the decoded top-level object with lower-cased keys, or null.
     *
     * @return array<string, mixed>|null
     */
    public static function parseJson(string $json): ?array
    {
        $json = preg_replace('/^\xEF\xBB\xBF/', '', $json) ?? $json;

        $data = json_decode($json, true);
        if (! is_array($data)) {
            // Strict parse failed: strip comments and trailing commas (outside strings) and retry.
            $data = json_decode(self::stripTrailingCommas(self::stripComments($json, false)), true);
        }
        if (! is_array($data) || ($data !== [] && array_is_list($data))) {
            return null;
        }

        return array_change_key_case($data, CASE_LOWER);
    }

    /** modinfo.json (any readable text) → normalised info, or null if it isn't a JSON object. */
    public static function fromJson(string $json): ?array
    {
        $raw = self::parseJson($json);

        return $raw === null ? null : self::normalise($raw);
    }

    /** modinfo.json at the zip root (case-insensitive name), from the raw bytes of the zip. */
    public static function fromZipBytes(string $bytes): ?array
    {
        // Smaller than an empty zip's end-of-directory record: can't be a zip (and PHP warns on empty files).
        if (strlen($bytes) < 22) {
            return null;
        }
        $tmp = tempnam(sys_get_temp_dir(), 'vsmm');
        if ($tmp === false) {
            return null;
        }

        try {
            if (file_put_contents($tmp, $bytes) === false) {
                return null;
            }
            $zip = new ZipArchive;
            if ($zip->open($tmp) !== true) {
                return null;
            }
            try {
                for ($i = 0; $i < $zip->numFiles; $i++) {
                    $stat = $zip->statIndex($i);
                    if ($stat === false || strcasecmp($stat['name'], 'modinfo.json') !== 0) {
                        continue; // the game only looks at the zip root
                    }
                    if ($stat['size'] > self::MAX_MODINFO_BYTES) {
                        return null;
                    }
                    $content = $zip->getFromIndex($i);

                    return $content === false ? null : self::fromJson($content);
                }
            } finally {
                $zip->close();
            }

            return null;
        } finally {
            @unlink($tmp);
        }
    }

    /**
     * C# source mod: [assembly: ModInfo("Name", "modid", Version = "1.0.0", Side = EnumAppSide.Server, ...)]
     * and optional [assembly: ModDependency("othermod", "1.2.0")] attributes.
     */
    public static function fromCsSource(string $src): ?array
    {
        $src = self::stripComments($src, true);

        $args = self::attributeArgs($src, 'ModInfo');
        if ($args === null) {
            return null;
        }

        $info = self::emptyInfo();
        $info['type'] = 'code';
        $positional = [];
        $named = [];
        foreach (self::splitTopLevel($args) as $arg) {
            if (preg_match('/^(\w+)\s*=(?!=)\s*(.*)$/s', $arg, $m)) {
                $named[strtolower($m[1])] = trim($m[2]);
            } else {
                $positional[] = trim($arg);
            }
        }

        $info['name'] = isset($positional[0]) ? self::csString($positional[0]) : null;
        $info['modid'] = isset($positional[1]) ? self::csString($positional[1]) : null;
        $info['version'] = isset($named['version']) ? self::csString($named['version']) : null;
        $info['description'] = isset($named['description']) ? self::csString($named['description']) : null;
        $info['website'] = isset($named['website']) ? self::csString($named['website']) : null;
        if (isset($named['side']) && preg_match('/(\w+)\s*$/', $named['side'], $m)) {
            $info['side'] = ucfirst(strtolower($m[1]));
        }
        foreach (['requiredonclient' => 'requiredOnClient', 'requiredonserver' => 'requiredOnServer'] as $k => $field) {
            if (isset($named[$k])) {
                $info[$field] = strtolower(trim($named[$k])) === 'true';
            }
        }
        if (isset($named['authors']) && preg_match_all('/"((?:[^"\\\\]|\\\\.)*)"/', $named['authors'], $m)) {
            $info['authors'] = array_map(stripcslashes(...), $m[1]);
        }
        if ($info['modid'] === null && $info['name'] !== null) {
            $info['modid'] = self::modidFromName($info['name']);
        }

        // [assembly: ModDependency("modid", "version")]
        if (preg_match_all('/\bModDependency\s*\(\s*"((?:[^"\\\\]|\\\\.)*)"\s*(?:,\s*"((?:[^"\\\\]|\\\\.)*)")?\s*\)/', $src, $m, PREG_SET_ORDER)) {
            foreach ($m as $dep) {
                $info['dependencies'][$dep[1]] = $dep[2] ?? '';
            }
            $info['gameMin'] = isset($info['dependencies']['game']) ? $info['dependencies']['game'] : null;
        }

        return $info;
    }

    /**
     * Best effort from a file name such as "carryon_1.8.0.zip" or "CarryOn-1.20.4_v1.9.3.zip".
     * Everything returned is a guess ('guessed' => true): never use it to decide updates on its own.
     */
    public static function guessFromFilename(string $filename): array
    {
        $info = self::emptyInfo();
        $info['guessed'] = true;

        $stem = preg_replace('/\.(zip|dll|cs)$/i', '', basename($filename)) ?? $filename;
        $name = $stem;
        // Last version-like token is the mod version: "<name>[-_ ]v?<1.2.3[-rc.1]>".
        if (preg_match('/^(.*?)[-_ ]?v?(\d+(?:\.\d+){1,3}(?:-[0-9A-Za-z.]+)?)$/', $stem, $m) && $m[1] !== '') {
            $info['version'] = $m[2];
            $name = $m[1];
            // Drop a game-version token left in front of it ("CarryOn-1.20.4").
            $name = preg_replace('/[-_ ]v?\d+(?:\.\d+)+$/', '', $name) ?? $name;
        }
        $name = trim($name, " -_.");
        if ($name !== '') {
            $info['name'] = $name;
            $info['modid'] = self::modidFromName($name);
        }

        return $info;
    }

    // ---- internals --------------------------------------------------------------------------------

    /** Raw, lower-cased-key modinfo → normalised shape. */
    private static function normalise(array $raw): array
    {
        $info = self::emptyInfo();

        $str = static fn (mixed $v): ?string => is_string($v) || is_int($v) || is_float($v) ? trim((string) $v) : null;
        $bool = static function (mixed $v): ?bool {
            if (is_bool($v)) {
                return $v;
            }
            if (is_string($v) && in_array(strtolower(trim($v)), ['true', 'false'], true)) {
                return strtolower(trim($v)) === 'true';
            }

            return null;
        };

        $info['name'] = $str($raw['name'] ?? null);
        $info['modid'] = $str($raw['modid'] ?? null);
        if (($info['modid'] === null || $info['modid'] === '') && $info['name'] !== null) {
            // The game derives a missing modid from the name (ModInfo.ToModID).
            $info['modid'] = self::modidFromName($info['name']);
        }
        $info['version'] = $str($raw['version'] ?? null);
        $type = $str($raw['type'] ?? null);
        $info['type'] = $type === null ? null : strtolower($type);
        $info['side'] = $str($raw['side'] ?? null);
        $info['requiredOnClient'] = $bool($raw['requiredonclient'] ?? null);
        $info['requiredOnServer'] = $bool($raw['requiredonserver'] ?? null);
        $info['description'] = $str($raw['description'] ?? null);
        $info['website'] = $str($raw['website'] ?? null);

        // Dependencies: { "modid": "minVersion" }. "" / "*" mean any version. Keys stay as written (case-sensitive in the game).
        if (isset($raw['dependencies']) && is_array($raw['dependencies'])) {
            foreach ($raw['dependencies'] as $id => $ver) {
                $info['dependencies'][(string) $id] = is_scalar($ver) ? trim((string) $ver) : '';
            }
        }
        $info['gameMin'] = $info['dependencies']['game'] ?? null;

        $authors = $raw['authors'] ?? [];
        if (is_string($authors)) {
            $authors = [$authors];
        }
        $info['authors'] = is_array($authors)
            ? array_values(array_filter(array_map(static fn ($a) => is_scalar($a) ? trim((string) $a) : '', $authors), static fn ($a) => $a !== ''))
            : [];

        return $info;
    }

    /** Same as the game's ModInfo.ToModID: keep [A-Za-z0-9], lowercase. */
    private static function modidFromName(string $name): ?string
    {
        $id = strtolower(preg_replace('/[^A-Za-z0-9]/', '', $name) ?? '');

        return $id === '' ? null : $id;
    }

    /**
     * Remove // and /* comments, leaving string literals alone.
     * $csharp: also treat 'x' as a char literal (so "'" doesn't confuse us); JSON has no single quotes.
     */
    private static function stripComments(string $s, bool $csharp): string
    {
        $out = '';
        $n = strlen($s);
        for ($i = 0; $i < $n; $i++) {
            $c = $s[$i];
            if ($c === '"' || ($csharp && $c === "'")) {
                $end = self::skipString($s, $i, $c);
                $out .= substr($s, $i, $end - $i);
                $i = $end - 1;
            } elseif ($c === '/' && ($s[$i + 1] ?? '') === '/') {
                while ($i < $n && $s[$i] !== "\n") {
                    $i++;
                }
                $out .= "\n";
            } elseif ($c === '/' && ($s[$i + 1] ?? '') === '*') {
                $close = strpos($s, '*/', $i + 2);
                $i = $close === false ? $n : $close + 1;
                $out .= ' ';
            } else {
                $out .= $c;
            }
        }

        return $out;
    }

    /** Remove commas that are directly followed by } or ] (ignoring whitespace), outside strings. */
    private static function stripTrailingCommas(string $s): string
    {
        $out = '';
        $n = strlen($s);
        for ($i = 0; $i < $n; $i++) {
            $c = $s[$i];
            if ($c === '"') {
                $end = self::skipString($s, $i, '"');
                $out .= substr($s, $i, $end - $i);
                $i = $end - 1;
            } elseif ($c === ',') {
                $j = $i + 1;
                while ($j < $n && ctype_space($s[$j])) {
                    $j++;
                }
                if ($j < $n && ($s[$j] === '}' || $s[$j] === ']')) {
                    continue; // drop the comma
                }
                $out .= $c;
            } else {
                $out .= $c;
            }
        }

        return $out;
    }

    /** Index just past the string literal that starts at $start (a quote char). */
    private static function skipString(string $s, int $start, string $quote): int
    {
        $n = strlen($s);
        for ($i = $start + 1; $i < $n; $i++) {
            if ($s[$i] === '\\') {
                $i++;
            } elseif ($s[$i] === $quote) {
                return $i + 1;
            }
        }

        return $n;
    }

    /** The text between the parentheses of `[assembly: <Name>(...)]`, or null. */
    private static function attributeArgs(string $src, string $name): ?string
    {
        if (! preg_match('/\[\s*assembly\s*:\s*(?:[\w.]+\.)?' . $name . '\s*\(/', $src, $m, PREG_OFFSET_CAPTURE)) {
            return null;
        }
        $start = $m[0][1] + strlen($m[0][0]);
        $depth = 1;
        $n = strlen($src);
        for ($i = $start; $i < $n; $i++) {
            $c = $src[$i];
            if ($c === '"' || $c === "'") {
                $i = self::skipString($src, $i, $c) - 1;
            } elseif ($c === '(') {
                $depth++;
            } elseif ($c === ')' && --$depth === 0) {
                return substr($src, $start, $i - $start);
            }
        }

        return null;
    }

    /** Split on commas that aren't inside strings, (), {} or []. @return string[] */
    private static function splitTopLevel(string $s): array
    {
        $parts = [];
        $depth = 0;
        $cur = '';
        $n = strlen($s);
        for ($i = 0; $i < $n; $i++) {
            $c = $s[$i];
            if ($c === '"' || $c === "'") {
                $end = self::skipString($s, $i, $c);
                $cur .= substr($s, $i, $end - $i);
                $i = $end - 1;
                continue;
            }
            if (str_contains('({[', $c)) {
                $depth++;
            } elseif (str_contains(')}]', $c)) {
                $depth--;
            }
            if ($c === ',' && $depth === 0) {
                $parts[] = $cur;
                $cur = '';
            } else {
                $cur .= $c;
            }
        }
        if (trim($cur) !== '') {
            $parts[] = $cur;
        }

        return array_values(array_filter(array_map('trim', $parts), static fn ($p) => $p !== ''));
    }

    /** A C# string literal ("text") → text; anything else → null. */
    private static function csString(string $lit): ?string
    {
        if (preg_match('/^"((?:[^"\\\\]|\\\\.)*)"$/s', trim($lit), $m)) {
            return stripcslashes($m[1]);
        }

        return null;
    }
}
