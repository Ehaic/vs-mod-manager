<?php

declare(strict_types=1);

namespace Ehaic\VsModManager\Support;

use Illuminate\Support\Facades\Log;

/**
 * One-line, grep-able log entries in the panel log (storage/logs/laravel-*.log):
 *
 *   vs-mod-manager: install.pull op=a1b2c3 server=15 user=1 mod=carryon host=moddbcdn.vintagestory.at ms=840
 *
 * `op` ties together every line of one change (install/update/remove...). Only ids, names, hosts and
 * timings are logged: never tokens, keys or full URLs with query strings.
 * debug() lines are written only when VSMM_DEBUG=true (Admin -> Plugins -> Vintage Story Mods -> Settings).
 */
final class Trace
{
    private static ?string $op = null;

    private static ?int $server = null;

    /** Start a new operation: later lines carry its op id and server id. */
    public static function begin(?int $serverId): string
    {
        self::$op = substr(bin2hex(random_bytes(4)), 0, 6);
        self::$server = $serverId;

        return self::$op;
    }

    public static function end(): void
    {
        self::$op = null;
        self::$server = null;
    }

    public static function debug(string $event, array $ctx = []): void
    {
        if ((bool) config('vs-mod-manager.debug', false)) {
            self::write('debug', $event, $ctx);
        }
    }

    public static function info(string $event, array $ctx = []): void
    {
        self::write('info', $event, $ctx);
    }

    public static function warning(string $event, array $ctx = []): void
    {
        self::write('warning', $event, $ctx);
    }

    public static function error(string $event, array $ctx = []): void
    {
        self::write('error', $event, $ctx);
    }

    /** scheme://host/path of a URL, without query or credentials. */
    public static function safeUrl(string $url): string
    {
        $p = parse_url($url);
        if (!is_array($p) || empty($p['host'])) {
            return '(unparseable)';
        }

        return ($p['scheme'] ?? 'https') . '://' . $p['host'] . ($p['path'] ?? '');
    }

    /** @param array<string, mixed> $ctx */
    public static function format(string $event, array $ctx, ?string $op = null, ?int $server = null, mixed $user = null): string
    {
        $head = ['op' => $op, 'server' => $server, 'user' => $user];
        $parts = [];
        foreach ([...$head, ...$ctx] as $k => $v) {
            if ($v === null || $v === '') {
                continue;
            }
            $v = is_bool($v) ? ($v ? 'true' : 'false') : (string) $v;
            $v = mb_strimwidth(preg_replace('/\s+/', ' ', $v) ?? $v, 0, 400, '…');
            $parts[] = $k . '=' . (preg_match('/[\s"=]/', $v) ? json_encode($v, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) : $v);
        }

        return 'vs-mod-manager: ' . $event . ($parts ? ' ' . implode(' ', $parts) : '');
    }

    /** @param array<string, mixed> $ctx */
    private static function write(string $level, string $event, array $ctx): void
    {
        try {
            $user = function_exists('auth') ? auth()->id() : null;
            Log::{$level}(self::format($event, $ctx, self::$op, self::$server, $user));
        } catch (\Throwable) {
            // logging must never break a mod change
        }
    }
}
