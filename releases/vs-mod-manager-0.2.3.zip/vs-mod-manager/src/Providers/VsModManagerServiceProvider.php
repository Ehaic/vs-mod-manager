<?php

declare(strict_types=1);

namespace Ehaic\VsModManager\Providers;

use Ehaic\VsModManager\Services\GameVersionService;
use Ehaic\VsModManager\Services\ModDbClient;
use Ehaic\VsModManager\Services\ModpackService;
use Ehaic\VsModManager\Services\ModStatusService;
use Ehaic\VsModManager\Services\ReleaseSelector;
use Illuminate\Support\ServiceProvider;

class VsModManagerServiceProvider extends ServiceProvider
{
    public function register(): void
    {
        // Stateless services. ServerModsService / ServerConfigEditor are per server (forServer()),
        // so they are resolved fresh each time and are deliberately not singletons.
        $this->app->singleton(ModDbClient::class);
        $this->app->singleton(ReleaseSelector::class);
        $this->app->singleton(GameVersionService::class);
        $this->app->singleton(ModStatusService::class);
        $this->app->singleton(ModpackService::class);
    }

    public function boot(): void
    {
        // No custom subuser permissions: viewing needs file.read; changing mods needs
        // file.create + file.update + file.delete (see DESIGN.md).
    }
}
