<?php

declare(strict_types=1);

namespace Ehaic\VsModManager\Services;

use App\Models\Server;
use App\Repositories\Daemon\DaemonFileRepository;
use Ehaic\VsModManager\Exceptions\ModManagerException;
use Illuminate\Contracts\Filesystem\FileNotFoundException;
use Illuminate\Http\Client\RequestException;
use stdClass;

/**
 * Reads and edits data/serverconfig.json (the game's own config) as a JSON tree.
 *
 * Only WorldConfig.DisabledMods is ever changed; every other key is decoded and re-encoded as-is
 * (objects stay objects, integers that don't fit in PHP's int64 are written back verbatim).
 * Nothing is written if the file does not decode.
 */
class ServerConfigEditor
{
    public const CONFIG_PATH = 'data/serverconfig.json';
    public const BACKUP_PATH = 'data/.vs-mod-manager/serverconfig.json.bak';

    private const BIGINT_MARK = '__vsmm_bigint_';

    private ?Server $server = null;

    public function forServer(Server $server): static
    {
        $new = clone $this;
        $new->server = $server;

        return $new;
    }

    /** @return string[] WorldConfig.DisabledMods (null or missing becomes []) */
    public function disabledMods(): array
    {
        $tree = $this->load();
        if ($tree === null) {
            return [];
        }

        $list = $tree->WorldConfig->DisabledMods ?? null;

        return is_array($list) ? array_values(array_filter($list, 'is_string')) : [];
    }

    /** @return string[] the ModPaths entries as written in serverconfig.json ([] when the file is missing) */
    public function modPaths(): array
    {
        $paths = $this->load()?->ModPaths ?? null;

        return is_array($paths) ? array_values(array_filter($paths, 'is_string')) : [];
    }

    /** Adds the bare modid to DisabledMods, or removes the modid and every modid@version entry. */
    public function setDisabled(string $modid, bool $disabled): void
    {
        $raw = $this->read();
        if ($raw === null) {
            throw new ModManagerException('serverconfig.json does not exist yet. Start the server once so the game creates it.');
        }

        $new = self::applyDisabled($raw, $modid, $disabled);
        if ($new === $raw) {
            return;
        }

        $repo = $this->repo();
        $this->ensureDir($repo);
        // Keep a copy of the file exactly as it was, then write the edited one.
        $repo->putContent('/' . self::BACKUP_PATH, $raw);
        if ((string) $repo->getContent('/' . self::BACKUP_PATH, 5 * 1024 * 1024) !== $raw) {
            throw new ModManagerException('Could not save a backup of serverconfig.json. Nothing was changed.');
        }

        $repo->putContent('/' . self::CONFIG_PATH, $new);

        // Wings overwrites in place (not atomically): read it back, and put the original back if it isn't what we wrote.
        $written = null;
        try {
            $written = (string) $repo->getContent('/' . self::CONFIG_PATH, 5 * 1024 * 1024);
        } catch (\Throwable) {
            // handled below
        }
        if ($written !== $new) {
            $repo->putContent('/' . self::CONFIG_PATH, $raw);

            throw new ModManagerException('serverconfig.json did not save correctly, so the original was put back. Nothing was changed.');
        }
    }

    /**
     * Pure: returns $json with $modid added to / removed from WorldConfig.DisabledMods.
     *
     * @throws ModManagerException if the JSON is invalid or has an unexpected shape
     */
    public static function applyDisabled(string $json, string $modid, bool $disabled): string
    {
        $tree = self::decode($json);

        if (!isset($tree->WorldConfig) || $tree->WorldConfig === null) {
            $tree->WorldConfig = new stdClass();
        }
        if (!$tree->WorldConfig instanceof stdClass) {
            throw new ModManagerException('serverconfig.json: WorldConfig is not an object, refusing to edit it.');
        }

        $list = $tree->WorldConfig->DisabledMods ?? null;
        if ($list === null) {
            $list = [];
        }
        if (!is_array($list)) {
            throw new ModManagerException('serverconfig.json: WorldConfig.DisabledMods is not a list, refusing to edit it.');
        }

        if ($disabled) {
            if (!in_array($modid, $list, true)) {
                $list[] = $modid;
            }
        } else {
            $list = array_values(array_filter(
                $list,
                fn ($entry) => !is_string($entry) || ($entry !== $modid && !str_starts_with($entry, $modid . '@')),
            ));
        }
        $tree->WorldConfig->DisabledMods = array_values($list);

        return self::encode($tree);
    }

    /** Decode to a tree (objects stay stdClass). Integers beyond int64 are swapped for a marker string first. */
    public static function decode(string $json): stdClass
    {
        $json = preg_replace('/^\xEF\xBB\xBF/', '', $json) ?? $json;

        // One pass over strings and numbers; strings are returned untouched so we never edit inside them.
        $json = preg_replace_callback(
            '/"(?:[^"\\\\]|\\\\.)*"|-?\d+(?:\.\d+)?(?:[eE][+-]?\d+)?/s',
            function (array $m): string {
                $token = $m[0];
                if ($token[0] === '"' || !preg_match('/^-?\d+$/', $token)) {
                    return $token;
                }

                return (string) (int) $token === $token ? $token : '"' . self::BIGINT_MARK . $token . '__"';
            },
            $json,
        );

        $tree = json_decode((string) $json, false, 512);
        if (!$tree instanceof stdClass) {
            throw new ModManagerException('serverconfig.json could not be parsed (' . json_last_error_msg() . '). Nothing was changed.');
        }

        return $tree;
    }

    public static function encode(stdClass $tree): string
    {
        $out = json_encode($tree, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_PRESERVE_ZERO_FRACTION);
        if ($out === false) {
            throw new ModManagerException('serverconfig.json could not be re-encoded (' . json_last_error_msg() . '). Nothing was changed.');
        }

        // The game writes 2-space indents; keep them so a diff of the file only shows the real change.
        // (Pretty-printed JSON never has a raw newline inside a string, so line starts are always indentation.)
        $out = preg_replace_callback('/^(?: {4})+/m', static fn (array $m): string => str_repeat('  ', intdiv(strlen($m[0]), 4)), $out) ?? $out;

        return preg_replace('/"' . self::BIGINT_MARK . '(-?\d+)__"/', '$1', $out) ?? $out;
    }

    private function load(): ?stdClass
    {
        $raw = $this->read();

        return $raw === null ? null : self::decode($raw);
    }

    /** Raw file contents, or null if the file doesn't exist. */
    private function read(): ?string
    {
        try {
            return (string) $this->repo()->getContent('/' . self::CONFIG_PATH, 5 * 1024 * 1024);
        } catch (FileNotFoundException) {
            return null;
        } catch (RequestException $e) {
            if ($e->response->status() === 404) {
                return null;
            }
            throw $e;
        }
    }

    private function repo(): DaemonFileRepository
    {
        if ($this->server === null) {
            throw new \LogicException('Call forServer() first.');
        }

        return (new DaemonFileRepository())->setServer($this->server);
    }

    private function ensureDir(DaemonFileRepository $repo): void
    {
        try {
            $repo->createDirectory('.vs-mod-manager', '/data');
        } catch (\Throwable) {
            // Already exists.
        }
    }
}
