<?php

declare(strict_types=1);

namespace Ehaic\VsModManager\Services;

use App\Models\Server;
use Ehaic\VsModManager\Support\Version;
use Illuminate\Support\Facades\Cache;

/** Works out which Vintage Story version a server runs, and says where the answer came from. */
class GameVersionService
{
    public static function cacheKey(Server $server): string
    {
        return 'vsmm.gameversion.' . $server->uuid;
    }

    /**
     * Order: the user's override (manifest) > last "Game Version:" line of data/Logs/server-main.log
     * > the egg's RELEASE_VERSION variable (unless it is "latest") > latest stable from the VS version API.
     *
     * @return array{version: ?string, source: 'override'|'log'|'variable'|'latest'|'unknown'}
     */
    public function detect(Server $server): array
    {
        $mods = app(ServerModsService::class)->forServer($server);

        // The override must take effect immediately, so it is read outside the cache.
        $override = $mods->manifest()['game_version_override'];
        if ($override !== null && Version::parse($override) !== null) {
            return ['version' => $override, 'source' => 'override'];
        }

        return Cache::remember(self::cacheKey($server), now()->addMinutes(10), function () use ($server, $mods) {
            $log = $mods->readServerLog();
            if ($log !== null && ($v = self::versionFromLog($log)) !== null) {
                return ['version' => $v, 'source' => 'log'];
            }

            $var = $server->variables()->where('env_variable', 'RELEASE_VERSION')->first()?->server_value;
            if (is_string($var) && strtolower(trim($var)) !== 'latest' && Version::parse(trim($var)) !== null) {
                return ['version' => ltrim(trim($var), 'vV'), 'source' => 'variable'];
            }

            try {
                $latest = app(ModDbClient::class)->latestStableGameVersion();
            } catch (\Throwable $e) {
                report($e);
                $latest = null;
            }

            return $latest !== null ? ['version' => $latest, 'source' => 'latest'] : ['version' => null, 'source' => 'unknown'];
        });
    }

    /** Last "Game Version: v1.20.12 (Stable)" line → "1.20.12". Pure. */
    public static function versionFromLog(string $log): ?string
    {
        if (preg_match_all('/Game Version: v?(\d+\.\d+\.\d+(?:-[0-9A-Za-z.]+)?)/', $log, $m) && $m[1] !== []) {
            return end($m[1]);
        }

        return null;
    }
}
