<?php

declare(strict_types=1);

namespace Ehaic\VsModManager\Services;

use App\Models\Server;
use Ehaic\VsModManager\Exceptions\ModManagerException;
use Ehaic\VsModManager\Exceptions\ServerNotStoppedException;
use Ehaic\VsModManager\Support\Version;

/** Export/import of a mod list: one "modid@version" per line (the VSModUpdater format). */
class ModpackService
{
    /** Lines read from a pasted list (each one is a ModDB lookup). */
    public const MAX_LINES = 200;
    /** Wall-clock seconds apply() may spend on installs before it stops and reports what is left. */
    private const APPLY_BUDGET_SECONDS = 100;

    /**
     * "modid@version\n" for mods ModDB knows, sorted; everything else as a "# not on ModDB: file" comment.
     *
     * @param  array<int, array<string, mixed>>  $installed  list() rows, ideally annotated by ModStatusService
     */
    public function export(array $installed): string
    {
        $lines = [];
        $comments = [];
        foreach ($installed as $row) {
            if (($row['kind'] ?? '') === 'ignored') {
                continue;
            }
            $known = !empty($row['modid']) && !empty($row['version']) && (
                !empty($row['moddb']) || in_array($row['moddbStatus'] ?? null, ['up_to_date', 'update'], true)
            );
            if ($known) {
                $lines[] = $row['modid'] . '@' . $row['version'];
            } else {
                $comments[] = '# not on ModDB: ' . $row['filename'];
            }
        }
        sort($lines, SORT_NATURAL | SORT_FLAG_CASE);
        sort($comments, SORT_NATURAL | SORT_FLAG_CASE);

        $all = array_merge($lines, $comments);

        return $all === [] ? '' : implode("\n", $all) . "\n";
    }

    /**
     * Accepts "modid", "modid@version" and ModDB URLs (https://mods.vintagestory.at/alias or /show/mod/123),
     * one per line. Blank lines and # comments are skipped. Lines that are none of these come back with
     * 'invalid' => true so the preview can report them.
     *
     * @return array<int, array{modid: string, version: ?string, line: string, invalid?: bool}>
     */
    public static function parse(string $text): array
    {
        $out = [];
        $seen = [];
        foreach (preg_split('/\R/', $text) ?: [] as $raw) {
            $line = trim(preg_replace('/^\xEF\xBB\xBF/', '', $raw) ?? $raw);
            if ($line === '' || $line[0] === '#') {
                continue;
            }
            if (count($out) >= self::MAX_LINES) {
                break;
            }

            $modid = null;
            $version = null;
            if (preg_match('#^https?://mods\.vintagestory\.at/(?:show/mod/)?([A-Za-z0-9_.\-]{1,100})/?(?:[?\#].*)?$#i', $line, $m)) {
                $modid = $m[1];
            } elseif (preg_match('/^([A-Za-z0-9_.\-]{1,100})(?:@([^\s@]{1,60}))?$/', $line, $m)) {
                $modid = $m[1];
                $version = $m[2] ?? null;
            }

            if ($modid === null) {
                $line = mb_substr($line, 0, 100);
                $out[] = ['modid' => $line, 'version' => null, 'line' => $line, 'invalid' => true];

                continue;
            }
            if (isset($seen[strtolower($modid)])) {
                continue; // first mention wins
            }
            $seen[strtolower($modid)] = true;
            $out[] = ['modid' => $modid, 'version' => $version, 'line' => $line];
        }

        return $out;
    }

    /**
     * What applying the list would do, per row:
     * ['modid','action'=>'install'|'update'|'same'|'not_found'|'incompatible','from','to','release','mod','installed']
     *
     * @param  array<int, array<string, mixed>>  $parsed  from parse()
     * @param  array<int, array<string, mixed>>  $installed  from ServerModsService::list()
     */
    public function preview(Server $server, array $parsed, array $installed, ?string $gameVersion): array
    {
        $client = app(ModDbClient::class);
        $selector = app(ReleaseSelector::class);
        $allowPre = (bool) config('vs-mod-manager.allow_prereleases', false);

        $byModid = [];
        foreach ($installed as $row) {
            if (!empty($row['modid']) && ($row['kind'] ?? '') !== 'ignored') {
                $id = strtolower((string) $row['modid']);
                // With duplicates, compare against the highest version (the one the game loads).
                if (!isset($byModid[$id]) || Version::compare((string) $row['version'], (string) $byModid[$id]['version']) > 0) {
                    $byModid[$id] = $row;
                }
            }
        }

        $rows = [];
        foreach ($parsed as $p) {
            $base = ['modid' => $p['modid'], 'action' => 'not_found', 'from' => null, 'to' => null, 'release' => null, 'mod' => null, 'installed' => null];
            if (!empty($p['invalid'])) {
                $rows[] = $base;

                continue;
            }

            try {
                $mod = $client->mod($p['modid']);
                if ($mod === null && ($id = self::idForAlias($client->catalogue(), $p['modid'])) !== null) {
                    // A ModDB page URL carries the url alias, which /api/mod/{x} doesn't accept.
                    $mod = $client->mod($id);
                }
            } catch (\Throwable $e) {
                report($e);
                $mod = null;
            }
            if ($mod === null) {
                $rows[] = $base;

                continue;
            }

            $releases = $mod['releases'] ?? [];
            // A page can host several modids; for a plain modid, only look at its own releases.
            $own = $selector->forModid($releases, $p['modid']);
            $releases = $own !== [] ? $own : $releases;
            $modid = (string) ($releases[0]['modidstr'] ?? $p['modid']);
            $base['modid'] = $modid;
            $base['mod'] = $mod;

            if ($p['version'] !== null) {
                $release = null;
                foreach ($releases as $r) {
                    if (Version::compare((string) $r['modversion'], $p['version']) === 0) {
                        $release = $r;
                        break;
                    }
                }
                if ($release === null) {
                    $rows[] = $base; // that version doesn't exist on ModDB

                    continue;
                }
                $compatible = $gameVersion === null || $selector->compatibility($release, $gameVersion) !== ReleaseSelector::OTHER;
            } else {
                $release = $gameVersion === null ? ($selector->sort($releases)[0] ?? null) : $selector->recommend($releases, $gameVersion, $allowPre);
                $compatible = $release !== null;
            }

            $have = $byModid[strtolower($modid)] ?? null;
            $base['release'] = $release;
            $base['to'] = $release['modversion'] ?? null;
            $base['from'] = $have['version'] ?? null;
            $base['installed'] = $have;

            $base['action'] = self::decideAction($release !== null && $compatible, $have['version'] ?? null, $have !== null, $release['modversion'] ?? null, $p['version'] !== null);
            $rows[] = $base;
        }

        return $rows;
    }

    /**
     * Preview action for one line. Pure.
     * Without an explicit version in the list, an installed version that is the same or newer than the
     * recommended release is kept ('same'): an import must never downgrade a mod the user didn't name a version for.
     */
    public static function decideAction(bool $usable, ?string $have, bool $installed, ?string $to, bool $explicitVersion): string
    {
        if (!$usable || $to === null) {
            return 'incompatible';
        }
        if (!$installed) {
            return 'install';
        }
        $cmp = Version::compare((string) $have, $to);
        if ($cmp === 0 || ($cmp > 0 && !$explicitVersion)) {
            return 'same';
        }

        return 'update';
    }

    /** Numeric ModDB mod id of the catalogue entry with this url alias (case-insensitive), or null. Pure. */
    public static function idForAlias(array $catalogue, string $alias): ?int
    {
        foreach ($catalogue as $m) {
            if (is_string($m['urlalias'] ?? null) && strcasecmp($m['urlalias'], $alias) === 0) {
                return (int) $m['modid'];
            }
        }

        return null;
    }

    /**
     * Installs/updates every 'install' and 'update' row of a preview, one after the other.
     * A failing row is reported and the rest carry on; a running server aborts the whole thing.
     *
     * @return array<int, array{modid: string, action: string, ok: bool, message: string}>
     */
    public function apply(Server $server, array $previewRows): array
    {
        $mods = app(ServerModsService::class)->forServer($server);
        $mods->assertStopped();

        $results = [];
        $deadline = microtime(true) + self::APPLY_BUDGET_SECONDS;
        foreach ($previewRows as $row) {
            $action = (string) ($row['action'] ?? '');
            if (!in_array($action, ['install', 'update'], true) || empty($row['release'])) {
                continue;
            }
            if (microtime(true) > $deadline) {
                // One web request can't run for ever: report the rest as not done so the user can preview and apply again.
                $results[] = ['modid' => $row['modid'], 'action' => $action, 'ok' => false, 'message' => 'Not done: stopped to avoid a timeout. Preview and apply the list again for the rest.'];

                continue;
            }

            try {
                $r = $action === 'install'
                    ? $mods->install($row['mod'] ?? [], $row['release'])
                    : $mods->update($row['installed'] ?? [], $row['release']);
                $results[] = ['modid' => $row['modid'], 'action' => $action, 'ok' => true, 'message' => $r['message']];
            } catch (ServerNotStoppedException $e) {
                // Someone started the server mid-import: stop here, but keep the results of what was already done.
                $results[] = ['modid' => $row['modid'], 'action' => $action, 'ok' => false, 'message' => $e->getMessage()];
                break;
            } catch (ModManagerException $e) {
                $results[] = ['modid' => $row['modid'], 'action' => $action, 'ok' => false, 'message' => $e->getMessage()];
            } catch (\Throwable $e) {
                report($e);
                $results[] = ['modid' => $row['modid'], 'action' => $action, 'ok' => false, 'message' => 'Unexpected error, see the panel log.'];
            }
        }

        return $results;
    }
}
