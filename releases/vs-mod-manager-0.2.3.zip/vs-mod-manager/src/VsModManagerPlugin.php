<?php

declare(strict_types=1);

namespace Ehaic\VsModManager;

use App\Contracts\Plugins\HasPluginSettings;
use App\Traits\EnvironmentWriterTrait;
use Filament\Contracts\Plugin;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\Toggle;
use Filament\Notifications\Notification;
use Filament\Panel;

class VsModManagerPlugin implements HasPluginSettings, Plugin
{
    use EnvironmentWriterTrait;

    public function getId(): string
    {
        return 'vs-mod-manager';
    }

    public function register(Panel $panel): void
    {
        // Only the server panel has pages; the admin panel is listed in plugin.json for the settings form.
        if ($panel->getId() !== 'server') {
            return;
        }

        $panel->discoverPages(
            plugin_path($this->getId(), 'src/Filament/Server/Pages'),
            'Ehaic\\VsModManager\\Filament\\Server\\Pages'
        );
    }

    public function boot(Panel $panel): void {}

    /** @return array<string, mixed> */
    public function getSettingsFormData(): array
    {
        return [
            // Stored in seconds, edited in minutes.
            'catalogue_ttl' => intdiv((int) config('vs-mod-manager.catalogue_ttl'), 60),
            'detail_ttl' => intdiv((int) config('vs-mod-manager.detail_ttl'), 60),
            'allow_prereleases' => config('vs-mod-manager.allow_prereleases'),
            'backups_per_mod' => config('vs-mod-manager.backups_per_mod'),
        ];
    }

    /** @return array<int, mixed> */
    public function getSettingsForm(): array
    {
        return [
            TextInput::make('catalogue_ttl')
                ->label(trans('vs-mod-manager::strings.settings.catalogue_ttl'))
                ->helperText(trans('vs-mod-manager::strings.settings.catalogue_ttl_hint'))
                ->numeric()->minValue(5)->maxValue(10080)->required()
                ->suffix(trans('vs-mod-manager::strings.settings.minutes'))
                ->default(fn () => intdiv((int) config('vs-mod-manager.catalogue_ttl'), 60)),
            TextInput::make('detail_ttl')
                ->label(trans('vs-mod-manager::strings.settings.detail_ttl'))
                ->helperText(trans('vs-mod-manager::strings.settings.detail_ttl_hint'))
                ->numeric()->minValue(1)->maxValue(1440)->required()
                ->suffix(trans('vs-mod-manager::strings.settings.minutes'))
                ->default(fn () => intdiv((int) config('vs-mod-manager.detail_ttl'), 60)),
            Toggle::make('allow_prereleases')
                ->label(trans('vs-mod-manager::strings.settings.allow_prereleases'))
                ->helperText(trans('vs-mod-manager::strings.settings.allow_prereleases_hint'))
                ->inline(false)
                ->default(fn () => config('vs-mod-manager.allow_prereleases')),
            TextInput::make('backups_per_mod')
                ->label(trans('vs-mod-manager::strings.settings.backups_per_mod'))
                ->helperText(trans('vs-mod-manager::strings.settings.backups_per_mod_hint'))
                ->numeric()->minValue(1)->maxValue(20)->required()
                ->default(fn () => config('vs-mod-manager.backups_per_mod')),
            Toggle::make('debug')
                ->label(trans('vs-mod-manager::strings.settings.debug'))
                ->helperText(trans('vs-mod-manager::strings.settings.debug_hint'))
                ->inline(false)
                ->default(fn () => config('vs-mod-manager.debug')),
        ];
    }

    /** @param array<string, mixed> $data */
    public function saveSettings(array $data): void
    {
        $this->writeToEnvironment([
            'VSMM_CATALOGUE_TTL' => (int) $data['catalogue_ttl'] * 60,
            'VSMM_DETAIL_TTL' => (int) $data['detail_ttl'] * 60,
            'VSMM_ALLOW_PRERELEASES' => $data['allow_prereleases'] ? 'true' : 'false',
            'VSMM_BACKUPS_PER_MOD' => (int) $data['backups_per_mod'],
            'VSMM_DEBUG' => !empty($data['debug']) ? 'true' : 'false',
        ]);

        Notification::make()
            ->title(trans('vs-mod-manager::strings.settings.saved'))
            ->success()
            ->send();
    }
}
