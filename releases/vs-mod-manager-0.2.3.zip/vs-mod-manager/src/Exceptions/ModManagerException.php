<?php

declare(strict_types=1);

namespace Ehaic\VsModManager\Exceptions;

use RuntimeException;

/**
 * Base class for errors whose message is safe and useful to show to the user.
 * The page turns these into danger notifications.
 */
class ModManagerException extends RuntimeException
{
}
