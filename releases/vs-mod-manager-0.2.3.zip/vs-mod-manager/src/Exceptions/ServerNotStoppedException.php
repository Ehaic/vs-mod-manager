<?php

declare(strict_types=1);

namespace Ehaic\VsModManager\Exceptions;

/** Thrown when a change to mods is attempted while the server is not offline. */
class ServerNotStoppedException extends ModManagerException
{
    public function __construct(public readonly string $state = 'unknown')
    {
        parent::__construct("The server must be stopped to change mods (current state: {$state}).");
    }
}
