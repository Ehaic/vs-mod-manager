<?php

declare(strict_types=1);

// Values can be changed on Admin -> Plugins -> Vintage Story Mods -> Settings (written to the panel's .env).
return [
    // ModDB site base (the client appends /api/...).
    'moddb_url' => env('VSMM_MODDB_URL', 'https://mods.vintagestory.at'),

    // Cache lifetimes, in seconds.
    'catalogue_ttl' => (int) env('VSMM_CATALOGUE_TTL', 21600),
    'detail_ttl' => (int) env('VSMM_DETAIL_TTL', 1800),

    // Offer pre-release (-rc/-pre/-dev) mod versions as updates and recommendations.
    'allow_prereleases' => (bool) env('VSMM_ALLOW_PRERELEASES', false),

    // Extra detail in the panel log (vs-mod-manager: ... lines). Info/warning/error lines are always written.
    'debug' => (bool) env('VSMM_DEBUG', false),

    // Replaced/removed files kept per mod for rollback.
    'backups_per_mod' => (int) env('VSMM_BACKUPS_PER_MOD', 3),
];
